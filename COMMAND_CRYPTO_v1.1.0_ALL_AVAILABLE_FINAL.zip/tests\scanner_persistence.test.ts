import * as fs from 'fs';
import * as path from 'path';
import { PersistentScanner } from '../src/scanner/persistent.scanner.js';
import { config } from '../src/config/index.js';

export async function testScannerPersistence(): Promise<{ name: string; passed: boolean; error?: string }[]> {
  const tests: { name: string; passed: boolean; error?: string }[] = [];
  const scanner = PersistentScanner.getInstance();

  scanner.resetAllUniverses();
  const initialState = scanner.getState();

  tests.push({
    name: 'Dual Scanner initializes with dedicated Bybit Crypto and TwelveData Extended universes',
    passed: initialState.crypto.totalMarkets >= 10 && initialState.extended.totalMarkets >= 20 && initialState.crypto.currentIndex === 0,
    error: `Expected >= 10 crypto and >= 20 extended markets, got ${initialState.crypto.totalMarkets} / ${initialState.extended.totalMarkets}`
  });

  // Run a small Crypto batch scan (2 instruments)
  const cryptoBatchResult = await scanner.scanCryptoBatch(2);
  const midState = scanner.getState();

  tests.push({
    name: 'Crypto scanner advances currentIndex and records processed instruments',
    passed: midState.crypto.currentIndex === 2 && cryptoBatchResult.processed === 2,
    error: `Expected currentIndex=2, got ${midState.crypto.currentIndex}`
  });

  // Verify checkpoint file exists on disk
  const checkpointFile = path.join(config.paths.checkpointsDir, 'scanner_checkpoint.json');
  const fileExists = fs.existsSync(checkpointFile);
  let savedCryptoIndex = 0;
  if (fileExists) {
    const raw = JSON.parse(fs.readFileSync(checkpointFile, 'utf-8'));
    savedCryptoIndex = raw.crypto.currentIndex;
  }

  tests.push({
    name: 'Dual scanner state is atomically persisted to disk checkpoint file',
    passed: fileExists && savedCryptoIndex === 2,
    error: `Checkpoint persistence failed: fileExists=${fileExists}, savedCryptoIndex=${savedCryptoIndex}`
  });

  return tests;
}
