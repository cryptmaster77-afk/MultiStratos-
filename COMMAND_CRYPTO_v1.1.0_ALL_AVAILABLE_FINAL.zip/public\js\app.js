// COMMAND CRYPTO — Frontend Controller
let opportunitiesData = [];
let positionsData = [];
let currentFilter = 'ALL';

document.addEventListener('DOMContentLoaded', () => {
  initSSE();
  fetchInitialData();
  bindEvents();
});

// SSE Connection for Zero-Polling Reactive Updates
function initSSE() {
  const eventSource = new EventSource('/api/events');
  
  eventSource.addEventListener('SCAN_UPDATE', (e) => {
    fetchStatus();
    fetchOpportunities();
  });

  eventSource.onerror = () => {
    console.warn('SSE stream disconnected, retrying in 5s...');
  };
}

async function fetchInitialData() {
  await Promise.all([
    fetchStatus(),
    fetchOpportunities(),
    fetchPositions(),
    fetchJournal()
  ]);
}

async function fetchStatus() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    
    // Account metrics
    document.getElementById('account-equity').textContent = `$${data.account.equity.toFixed(2)}`;
    document.getElementById('account-balance').textContent = `Balance: $${data.account.balance.toFixed(2)}`;
    
    const unPnl = data.account.unrealizedPnl;
    const pnlEl = document.getElementById('unrealized-pnl');
    pnlEl.textContent = `${unPnl >= 0 ? '+' : ''}$${unPnl.toFixed(2)}`;
    pnlEl.className = `metric-value ${unPnl > 0 ? 'text-emerald' : unPnl < 0 ? 'text-rose' : 'text-neutral'}`;
    document.getElementById('realized-pnl').textContent = `Realized: $${data.account.realizedPnl.toFixed(2)}`;

    // Drawdown
    const dd = data.account.dailyDrawdownPct;
    document.getElementById('daily-drawdown').textContent = `${dd.toFixed(2)}% / 3.0% Max`;
    document.getElementById('drawdown-status').textContent = dd >= 3.0 ? 'HALTED (Daily Limit)' : 'Hard Limit Safe';

    // Exposure
    document.getElementById('portfolio-exposure').textContent = `${data.account.totalExposurePct.toFixed(1)}% / 20.0% Cap`;
    document.getElementById('positions-count').textContent = `${data.openPositionsCount} Open Positions`;

    // Quotas
    const tdQuota = data.quotas.find(q => q.providerName === 'twelvedata');
    if (tdQuota) {
      document.getElementById('twelvedata-quota').textContent = `${tdQuota.remainingDailyBudget} / ${tdQuota.dailyBudget} left (Reserve: ${tdQuota.reservedSafetyBuffer})`;
    }
    const bybitEl = document.getElementById('bybit-status');
    if (bybitEl) {
      bybitEl.textContent = `Bybit: Continuous (${data.scanner.crypto?.completedCycles || 0} cycles)`;
    }

    // Scanner Checkpoint
    if (data.scanner.crypto && data.scanner.extended) {
      document.getElementById('scanner-checkpoint').textContent = `Bybit: ${data.scanner.crypto.currentIndex}/${data.scanner.crypto.totalMarkets} | TwelveData: ${data.scanner.extended.currentIndex}/${data.scanner.extended.totalMarkets}`;
    }

    // Global Universe Breakdown & Statistics
    const breakdown = data.scanner.universeBreakdown;
    if (breakdown) {
      const modeText = breakdown.universeMode || 'ALL AVAILABLE';
      const modeBadge = document.getElementById('universe-mode-badge');
      if (modeBadge) modeBadge.textContent = `UNIVERSE: ${modeText}`;
      const curMode = document.getElementById('current-universe-mode');
      if (curMode) curMode.textContent = modeText;

      document.getElementById('stat-discovered').textContent = breakdown.totalDiscovered;
      document.getElementById('stat-eligible').textContent = breakdown.totalEligible;
      document.getElementById('stat-queued').textContent = breakdown.totalQueued;
      document.getElementById('stat-scanned').textContent = breakdown.totalScanned;
      document.getElementById('stat-pending').textContent = breakdown.totalPending;
      document.getElementById('stat-closed').textContent = breakdown.totalSkippedClosed;

      // Update filter pills with dynamic counts
      const pillAll = document.getElementById('pill-ALL');
      if (pillAll) pillAll.textContent = `ALL MARKETS (${breakdown.totalDiscovered})`;

      const byAsset = breakdown.byAssetClass || {};
      const assetKeys = ['CRYPTO', 'FOREX', 'METALS', 'INDICES', 'STOCKS', 'COMMODITIES'];
      const cardsContainer = document.getElementById('asset-universe-cards');

      if (cardsContainer) {
        cardsContainer.innerHTML = assetKeys.map(key => {
          const info = byAsset[key];
          if (!info) return '';
          return `
            <div class="asset-card-mini">
              <div class="asset-card-title">
                <span>${key}</span>
                <span class="badge badge-alpha" style="font-size:0.65rem; padding:1px 4px;">${info.provider.toUpperCase()}</span>
              </div>
              <div class="asset-card-count">${info.discovered} Markets</div>
              <div class="asset-card-status">${info.sessionStatus}</div>
            </div>
          `;
        }).join('');
      }

      for (const key of assetKeys) {
        const pill = document.getElementById(`pill-${key}`);
        if (pill && byAsset[key]) {
          pill.textContent = `${key} (${byAsset[key].discovered})`;
        }
      }
    }

    // Autopilot Button State
    const btnAuto = document.getElementById('btn-toggle-autopilot');
    btnAuto.textContent = data.autopilot.isRunning ? '⏸ Autopilot: ON' : '▶ Autopilot: OFF';
    btnAuto.className = data.autopilot.isRunning ? 'btn btn-primary' : 'btn btn-toggle';

  } catch (err) {
    console.error('Error fetching status:', err);
  }
}

async function fetchOpportunities() {
  try {
    const res = await fetch('/api/scanner/opportunities');
    const data = await res.json();
    opportunitiesData = data.opportunities || [];
    renderOpportunities();
  } catch (err) {
    console.error('Error fetching opportunities:', err);
  }
}

async function fetchPositions() {
  try {
    const res = await fetch('/api/positions');
    const data = await res.json();
    positionsData = data.positions || [];
    renderPositions();
  } catch (err) {
    console.error('Error fetching positions:', err);
  }
}

async function fetchJournal() {
  try {
    const res = await fetch('/api/journal');
    const data = await res.json();
    renderJournal(data);
  } catch (err) {
    console.error('Error fetching journal:', err);
  }
}

function renderOpportunities() {
  const tbody = document.getElementById('opportunities-body');
  const filtered = currentFilter === 'ALL' 
    ? opportunitiesData 
    : opportunitiesData.filter(o => o.assetClass === currentFilter);

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="11" class="text-center text-muted">No opportunities for ${currentFilter}. Click "Scan Next Batch" to evaluate.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(opp => {
    let decClass = 'decision-wait';
    if (opp.decision === 'TRADE') decClass = 'decision-trade';
    else if (opp.decision === 'REQUIRE_CONFIRMATION') decClass = 'decision-confirm';
    else if (opp.decision === 'REJECT') decClass = 'decision-reject';

    return `
      <tr>
        <td><strong>${opp.symbol}</strong></td>
        <td><span class="badge badge-alpha">${opp.assetClass}</span></td>
        <td class="${opp.direction === 'BUY' ? 'text-emerald' : 'text-rose'}"><strong>${opp.direction}</strong></td>
        <td>$${opp.entryPrice.toFixed(4)}</td>
        <td>$${opp.stopLoss.toFixed(4)}</td>
        <td>$${opp.takeProfit.toFixed(4)}</td>
        <td>1:${opp.riskReward.toFixed(2)}</td>
        <td>${opp.reasoning.strategyName}</td>
        <td>
          <span class="score-badge ${opp.scores.strategyScore >= 75 ? 'score-high' : 'score-med'}">${opp.scores.strategyScore}</span> /
          <span class="score-badge ${opp.scores.memoryScore >= 60 ? 'score-high' : 'score-med'}">${opp.scores.memoryScore}</span> /
          <span class="score-badge ${opp.scores.compositeScore >= 75 ? 'score-high' : 'score-med'}">${opp.scores.compositeScore}</span>
        </td>
        <td><span class="decision-badge ${decClass}">${opp.decision}</span></td>
        <td><button class="btn btn-outline" style="padding:2px 6px; font-size:0.75rem;" onclick="showExplain('${opp.id}')">View</button></td>
      </tr>
    `;
  }).join('');
}

function renderPositions() {
  const tbody = document.getElementById('positions-body');
  if (positionsData.length === 0) {
    tbody.innerHTML = `<tr><td colspan="9" class="text-center text-muted">No open positions.</td></tr>`;
    return;
  }

  tbody.innerHTML = positionsData.map(pos => {
    const pnlClass = pos.unrealizedPnl >= 0 ? 'text-emerald' : 'text-rose';
    return `
      <tr>
        <td><strong>${pos.symbol}</strong></td>
        <td class="${pos.direction === 'BUY' ? 'text-emerald' : 'text-rose'}"><strong>${pos.direction}</strong></td>
        <td>$${pos.entryPrice.toFixed(4)}</td>
        <td>$${pos.currentPrice.toFixed(4)}</td>
        <td>$${pos.stopLoss.toFixed(4)} ${pos.trailingStopActive ? '🎯' : ''}</td>
        <td>$${pos.takeProfit.toFixed(4)}</td>
        <td class="${pnlClass}">${pos.unrealizedPnl >= 0 ? '+' : ''}$${pos.unrealizedPnl.toFixed(2)}</td>
        <td class="${pnlClass}">${pos.unrealizedR >= 0 ? '+' : ''}${pos.unrealizedR.toFixed(2)} R</td>
        <td><button class="btn-danger-sm" onclick="closePosition('${pos.id}')">Close</button></td>
      </tr>
    `;
  }).join('');
}

function renderJournal(data) {
  const perf = data.performance;
  document.getElementById('journal-stats').textContent = `Total: ${perf.totalTrades} | Win Rate: ${perf.winRatePct.toFixed(1)}% | Profit Factor: ${perf.profitFactor.toFixed(2)} | Avg R: ${perf.averageR.toFixed(2)}`;

  // Adaptive Intel
  const b = data.baselineComparison;
  document.getElementById('intel-value-add').textContent = `${b.valueAddR >= 0 ? '+' : ''}${b.valueAddR.toFixed(2)} R`;
  document.getElementById('intel-avoided-bad').textContent = `${b.avoidedBadTradesCount} Avoided Losses`;
  document.getElementById('intel-win-rate').textContent = `${b.adaptiveWinRatePct.toFixed(1)}% vs ${b.baselineWinRatePct.toFixed(1)}%`;
  document.getElementById('intel-recommendation').textContent = b.recommendation;

  const tbody = document.getElementById('journal-body');
  const list = data.closedPositions || [];

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="9" class="text-center text-muted">No completed trades recorded in journal.</td></tr>`;
    return;
  }

  tbody.innerHTML = list.slice(0, 15).map(p => {
    const pnlClass = p.realizedPnl >= 0 ? 'text-emerald' : 'text-rose';
    return `
      <tr>
        <td style="font-size:0.75rem; color:#94a3b8;">${p.id.slice(-8)}</td>
        <td><strong>${p.symbol}</strong></td>
        <td class="${p.direction === 'BUY' ? 'text-emerald' : 'text-rose'}">${p.direction}</td>
        <td>$${p.entryPrice.toFixed(4)}</td>
        <td>$${(p.exitPrice || p.currentPrice).toFixed(4)}</td>
        <td class="${pnlClass}">${p.realizedPnl >= 0 ? '+' : ''}$${p.realizedPnl.toFixed(2)}</td>
        <td><span class="badge badge-alpha">${p.exitReason || 'MANUAL'}</span></td>
        <td>MAE: ${p.mae.toFixed(2)}R / MFE: ${p.mfe.toFixed(2)}R</td>
        <td style="font-size:0.75rem; color:#94a3b8;">${p.strategyId}</td>
      </tr>
    `;
  }).join('');
}

function bindEvents() {
  // Asset Filter Pills
  document.querySelectorAll('.filter-pills .pill').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.filter-pills .pill').forEach(p => p.classList.remove('active'));
      e.target.classList.add('active');
      currentFilter = e.target.getAttribute('data-class');
      renderOpportunities();
    });
  });

  // Manual Scan
  document.getElementById('btn-scan-batch').addEventListener('click', async () => {
    const btn = document.getElementById('btn-scan-batch');
    btn.disabled = true;
    btn.textContent = 'Scanning...';
    try {
      await fetch('/api/scanner/scan', { method: 'POST' });
      await fetchInitialData();
    } catch (err) {
      console.error(err);
    } finally {
      btn.disabled = false;
      btn.textContent = '🔍 Scan Next Batch';
    }
  });

  // Reset Scanner
  document.getElementById('btn-reset-scanner').addEventListener('click', async () => {
    await fetch('/api/scanner/reset', { method: 'POST' });
    await fetchInitialData();
  });

  // Dynamic Live Discovery
  const btnDiscover = document.getElementById('btn-discover-live');
  if (btnDiscover) {
    btnDiscover.addEventListener('click', async () => {
      btnDiscover.textContent = '⏳ Discovering...';
      try {
        const res = await fetch('/api/universe/discover', { method: 'POST' });
        const data = await res.json();
        if (data.success) {
          btnDiscover.textContent = '✅ Discovered!';
        } else {
          btnDiscover.textContent = '❌ Failed';
        }
      } catch {
        btnDiscover.textContent = '❌ Error';
      }
      setTimeout(() => { btnDiscover.textContent = '⚡ Discover Live'; }, 3000);
      await fetchInitialData();
    });
  }

  // Toggle Autopilot
  document.getElementById('btn-toggle-autopilot').addEventListener('click', async () => {
    const isRunning = document.getElementById('btn-toggle-autopilot').textContent.includes('ON');
    const endpoint = isRunning ? '/api/autopilot/stop' : '/api/autopilot/start';
    await fetch(endpoint, { method: 'POST' });
    await fetchStatus();
  });

  // Emergency Stop
  document.getElementById('btn-emergency-stop').addEventListener('click', async () => {
    if (confirm('ARM EMERGENCY STOP? All open positions will be closed immediately.')) {
      await fetch('/api/risk/emergency-stop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ arm: true })
      });
      await fetchInitialData();
    }
  });

  // Reset Paper Account
  document.getElementById('btn-reset-paper').addEventListener('click', async () => {
    if (confirm('Reset paper balance to $100.00?')) {
      await fetch('/api/risk/reset-paper', { method: 'POST' });
      await fetchInitialData();
    }
  });

  // Close All
  document.getElementById('btn-close-all').addEventListener('click', async () => {
    await fetch('/api/positions/close-all', { method: 'POST' });
    await fetchInitialData();
  });

  // Export CSV
  document.getElementById('btn-export-journal').addEventListener('click', () => {
    window.location.href = '/api/journal/export';
  });

  // Modal Close
  document.getElementById('modal-close-btn').addEventListener('click', () => {
    document.getElementById('explain-modal').classList.remove('active');
  });
}

window.closePosition = async function(id) {
  await fetch(`/api/positions/${id}/close`, { method: 'POST' });
  await fetchInitialData();
};

window.showExplain = function(id) {
  const opp = opportunitiesData.find(o => o.id === id);
  if (!opp) return;

  const modal = document.getElementById('explain-modal');
  const body = document.getElementById('modal-body');
  document.getElementById('modal-title').textContent = `Decision Autopsy: ${opp.symbol} (${opp.direction})`;

  body.innerHTML = `
    <div style="display:flex; flex-direction:column; gap:14px;">
      <div style="background:#0f172a; padding:12px; border-radius:6px;">
        <strong>Final Decision:</strong> <span class="decision-badge decision-${opp.decision.toLowerCase()}">${opp.decision}</span>
        <p style="margin-top:6px; color:#94a3b8;">${opp.decisionReason}</p>
      </div>

      <div style="display:grid; grid-template-columns: repeat(3, 1fr); gap:8px;">
        <div style="background:#1e293b; padding:8px; border-radius:4px; text-align:center;">
          <div style="font-size:0.75rem; color:#94a3b8;">Strategy Score</div>
          <div style="font-size:1.2rem; font-weight:700;">${opp.scores.strategyScore}/100</div>
        </div>
        <div style="background:#1e293b; padding:8px; border-radius:4px; text-align:center;">
          <div style="font-size:0.75rem; color:#94a3b8;">Memory Score</div>
          <div style="font-size:1.2rem; font-weight:700;">${opp.scores.memoryScore}/100</div>
        </div>
        <div style="background:#1e293b; padding:8px; border-radius:4px; text-align:center;">
          <div style="font-size:0.75rem; color:#94a3b8;">Composite Score</div>
          <div style="font-size:1.2rem; font-weight:700;">${opp.scores.compositeScore}/100</div>
        </div>
      </div>

      <div>
        <strong>🧠 Adaptive Trade Memory Insights:</strong>
        <p style="color:#94a3b8; font-size:0.85rem; margin-top:4px;">${opp.memoryReason || 'No memory notes recorded.'}</p>
      </div>

      <div>
        <strong>📈 Multi-Timeframe Context:</strong>
        <p style="color:#94a3b8; font-size:0.85rem; margin-top:4px;">
          Higher Trend: <strong>${opp.reasoning.timeframeContext.higherTrend}</strong> |
          Medium Structure: <strong>${opp.reasoning.timeframeContext.mediumStructure}</strong> |
          Lower Trigger: <strong>${opp.reasoning.timeframeContext.lowerTrigger}</strong>
        </p>
      </div>

      <div>
        <strong>✅ Conditions Satisfied:</strong>
        <ul style="padding-left:20px; color:#10b981; font-size:0.85rem; margin-top:4px;">
          ${opp.reasoning.conditionsSatisfied.map(c => `<li>${c.name}: ${c.actual}</li>`).join('')}
        </ul>
      </div>

      ${opp.reasoning.conditionsFailed.length > 0 ? `
        <div>
          <strong>❌ Conditions Failed:</strong>
          <ul style="padding-left:20px; color:#f43f5e; font-size:0.85rem; margin-top:4px;">
            ${opp.reasoning.conditionsFailed.map(c => `<li>${c.name} (Expected: ${c.expected}, Got: ${c.actual})</li>`).join('')}
          </ul>
        </div>
      ` : ''}
    </div>
  `;

  modal.classList.add('active');
};
