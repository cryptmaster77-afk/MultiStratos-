import { Position, PositionExitReason } from '../types/risk.js';
import { Quote } from '../types/market.js';
import { RiskManager } from '../risk/risk.manager.js';
import { TradeJournal } from './journal.js';
import { TradeAutopsyEngine } from '../memory/autopsy.engine.js';
import { ExperienceStore } from '../memory/experience.store.js';

export class PositionManager {
  private static instance: PositionManager;
  private openPositions: Map<string, Position> = new Map();
  private riskManager = RiskManager.getInstance();
  private journal = TradeJournal.getInstance();
  private experienceStore = ExperienceStore.getInstance();

  private constructor() {}

  public static getInstance(): PositionManager {
    if (!this.instance) {
      this.instance = new PositionManager();
    }
    return this.instance;
  }

  public addPosition(pos: Position): void {
    this.openPositions.set(pos.id, pos);
    this.riskManager.updatePositions(this.getOpenPositions());
  }

  public getOpenPositions(): Position[] {
    return Array.from(this.openPositions.values());
  }

  public getPosition(id: string): Position | undefined {
    return this.openPositions.get(id);
  }

  /**
   * Updates an open position with current live quote and executes SL, TP, or Trailing Stop exits.
   */
  public updatePrice(id: string, quote: Quote): { closed: boolean; exitReason?: PositionExitReason } {
    const pos = this.openPositions.get(id);
    if (!pos || pos.status !== 'OPEN') return { closed: false };

    const currentPrice = quote.last;
    pos.currentPrice = currentPrice;

    // Update Extreme prices
    pos.highestPriceSinceEntry = Math.max(pos.highestPriceSinceEntry, currentPrice);
    pos.lowestPriceSinceEntry = Math.min(pos.lowestPriceSinceEntry, currentPrice);

    // Calculate Unrealized PnL
    const priceDiff = pos.direction === 'BUY' ? (currentPrice - pos.entryPrice) : (pos.entryPrice - currentPrice);
    pos.unrealizedPnl = priceDiff * pos.sizeUnits - pos.feesPaid;
    pos.unrealizedPnlPct = pos.notionalValue > 0 ? (pos.unrealizedPnl / pos.notionalValue) * 100 : 0;

    const initialRiskPerUnit = Math.abs(pos.entryPrice - pos.initialStopLoss);
    pos.unrealizedR = initialRiskPerUnit > 0 ? priceDiff / initialRiskPerUnit : 0;

    // Track MAE & MFE
    if (pos.direction === 'BUY') {
      const maxAdverse = Math.max(0, pos.entryPrice - pos.lowestPriceSinceEntry);
      const maxFavorable = Math.max(0, pos.highestPriceSinceEntry - pos.entryPrice);
      pos.mae = initialRiskPerUnit > 0 ? maxAdverse / initialRiskPerUnit : 0;
      pos.mfe = initialRiskPerUnit > 0 ? maxFavorable / initialRiskPerUnit : 0;
    } else {
      const maxAdverse = Math.max(0, pos.highestPriceSinceEntry - pos.entryPrice);
      const maxFavorable = Math.max(0, pos.entryPrice - pos.lowestPriceSinceEntry);
      pos.mae = initialRiskPerUnit > 0 ? maxAdverse / initialRiskPerUnit : 0;
      pos.mfe = initialRiskPerUnit > 0 ? maxFavorable / initialRiskPerUnit : 0;
    }

    // Trailing Stop Logic: Activate once trade reaches >= 1.0R profit
    if (pos.unrealizedR >= 1.0 && !pos.trailingStopActive) {
      pos.trailingStopActive = true;
      // Move stop loss to Breakeven + small buffer
      if (pos.direction === 'BUY') {
        pos.stopLoss = Math.max(pos.stopLoss, pos.entryPrice + (initialRiskPerUnit * 0.1));
      } else {
        pos.stopLoss = Math.min(pos.stopLoss, pos.entryPrice - (initialRiskPerUnit * 0.1));
      }
    }

    // If Trailing Stop is active, lock in 50% of peak R gains
    if (pos.trailingStopActive && pos.mfe >= 1.5) {
      const lockInR = pos.mfe * 0.5;
      if (pos.direction === 'BUY') {
        const trailingSl = pos.entryPrice + (initialRiskPerUnit * lockInR);
        pos.stopLoss = Math.max(pos.stopLoss, trailingSl);
      } else {
        const trailingSl = pos.entryPrice - (initialRiskPerUnit * lockInR);
        pos.stopLoss = Math.min(pos.stopLoss, trailingSl);
      }
    }

    // Check Exit Conditions
    let exitReason: PositionExitReason | undefined;

    if (pos.direction === 'BUY') {
      if (currentPrice <= pos.stopLoss) {
        exitReason = pos.trailingStopActive ? 'TRAILING_STOP' : 'STOP_LOSS';
      } else if (currentPrice >= pos.takeProfit) {
        exitReason = 'TAKE_PROFIT';
      }
    } else {
      if (currentPrice >= pos.stopLoss) {
        exitReason = pos.trailingStopActive ? 'TRAILING_STOP' : 'STOP_LOSS';
      } else if (currentPrice <= pos.takeProfit) {
        exitReason = 'TAKE_PROFIT';
      }
    }

    if (exitReason) {
      this.closePosition(id, currentPrice, exitReason);
      return { closed: true, exitReason };
    }

    this.riskManager.updatePositions(this.getOpenPositions());
    return { closed: false };
  }

  public closePosition(id: string, exitPrice: number, reason: PositionExitReason): Position | undefined {
    const pos = this.openPositions.get(id);
    if (!pos) return undefined;

    pos.status = 'CLOSED';
    pos.exitPrice = exitPrice;
    pos.exitReason = reason;
    pos.closedAt = Date.now();

    const priceDiff = pos.direction === 'BUY' ? (exitPrice - pos.entryPrice) : (pos.entryPrice - exitPrice);
    const grossPnl = priceDiff * pos.sizeUnits;
    const exitFee = pos.notionalValue * 0.0005; // 5 bps exit fee
    pos.feesPaid += exitFee;
    pos.realizedPnl = grossPnl - pos.feesPaid;

    const initialRisk = Math.abs(pos.entryPrice - pos.initialStopLoss) * pos.sizeUnits;
    const realizedR = initialRisk > 0 ? pos.realizedPnl / initialRisk : 0;

    // Record into risk manager
    this.riskManager.recordRealizedTrade(grossPnl, pos.feesPaid);
    this.openPositions.delete(id);
    this.riskManager.updatePositions(this.getOpenPositions());

    // Record into trade journal
    this.journal.recordClosedTrade(pos);

    // Perform Automated Post-Trade Autopsy & Feed Memory
    const autopsy = TradeAutopsyEngine.performAutopsy(pos);
    this.experienceStore.updateOutcome(pos.opportunityId, {
      realizedPnl: pos.realizedPnl,
      realizedR,
      durationMs: pos.closedAt - pos.openedAt,
      exitPrice: pos.exitPrice,
      exitReason: pos.exitReason,
      mae: pos.mae,
      mfe: pos.mfe,
      tpHit: reason === 'TAKE_PROFIT' || reason === 'TAKE_PROFIT_2',
      slHit: reason === 'STOP_LOSS',
      trailingActivated: pos.trailingStopActive,
      autopsySummary: autopsy.memoryEngineLesson
    });

    return pos;
  }

  public closeAllPositions(reason: PositionExitReason = 'MANUAL_CLOSE'): void {
    for (const [id, pos] of this.openPositions.entries()) {
      this.closePosition(id, pos.currentPrice, reason);
    }
  }
}
