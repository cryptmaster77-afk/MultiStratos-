import { MarketDiscoveryService } from '../src/market/discovery.js';
import { AssetClass } from '../src/types/market.js';
import { config } from '../src/config/index.js';

export function testDiscoveryUniverse(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];
  const universe = MarketDiscoveryService.getUniverse();
  const breakdown = MarketDiscoveryService.getUniverseBreakdown();

  // 1. Default Universe Mode
  tests.push({
    name: 'Default market universe mode is ALL AVAILABLE',
    passed: breakdown.universeMode === 'ALL AVAILABLE' && config.scanner.universeMode === 'ALL',
    error: `Expected ALL AVAILABLE, got ${breakdown.universeMode}`
  });

  // 2. All 6 Asset Classes Present
  const requiredClasses: AssetClass[] = ['CRYPTO', 'FOREX', 'METALS', 'INDICES', 'STOCKS', 'COMMODITIES'];
  const presentClasses = new Set(universe.map(u => u.assetClass));
  const missing = requiredClasses.filter(c => !presentClasses.has(c));

  tests.push({
    name: 'Universe contains all 6 required asset classes without artificial exclusion',
    passed: missing.length === 0,
    error: `Missing asset classes: ${missing.join(', ')}`
  });

  // 3. Provider Mapping Integrity
  const cryptoItems = universe.filter(u => u.assetClass === 'CRYPTO');
  const nonCryptoItems = universe.filter(u => u.assetClass !== 'CRYPTO');
  const invalidCryptoProvider = cryptoItems.find(u => u.provider !== 'bybit');
  const invalidExtendedProvider = nonCryptoItems.find(u => u.provider !== 'twelvedata' && u.symbol !== 'PAXG/USDT');

  tests.push({
    name: 'Provider mapping routes CRYPTO to Bybit and traditional assets to TwelveData',
    passed: !invalidCryptoProvider && !invalidExtendedProvider,
    error: `Invalid provider detected: crypto=${invalidCryptoProvider?.symbol}, extended=${invalidExtendedProvider?.symbol}`
  });

  // 4. Broad Market Coverage (No Arbitrary TOP-10/20 Slices)
  const totalCount = universe.length;
  tests.push({
    name: 'Broad market discovery discovers full multi-asset catalog (>= 50 instruments)',
    passed: totalCount >= 50,
    error: `Expected >= 50 discovered instruments, got ${totalCount}`
  });

  // 5. Asset Class Specific Coverage
  const forexCount = universe.filter(u => u.assetClass === 'FOREX').length;
  const stocksCount = universe.filter(u => u.assetClass === 'STOCKS').length;
  const metalsCount = universe.filter(u => u.assetClass === 'METALS').length;
  const indicesCount = universe.filter(u => u.assetClass === 'INDICES').length;
  const commoditiesCount = universe.filter(u => u.assetClass === 'COMMODITIES').length;

  tests.push({
    name: 'Broad coverage verified across individual asset classes (Forex >= 20, Stocks >= 20, Metals >= 4, Indices >= 8, Commodities >= 5)',
    passed: forexCount >= 20 && stocksCount >= 20 && metalsCount >= 4 && indicesCount >= 8 && commoditiesCount >= 5,
    error: `Counts: Forex=${forexCount}, Stocks=${stocksCount}, Metals=${metalsCount}, Indices=${indicesCount}, Commodities=${commoditiesCount}`
  });

  // 6. Breakdown Accuracy
  tests.push({
    name: 'Universe breakdown tracks discovered, eligible, queued, scanned, and pending counts',
    passed: breakdown.totalDiscovered === totalCount && breakdown.totalEligible === totalCount && breakdown.totalPending >= 0,
    error: `Breakdown discrepancy: totalDiscovered=${breakdown.totalDiscovered}, totalEligible=${breakdown.totalEligible}`
  });

  return tests;
}
