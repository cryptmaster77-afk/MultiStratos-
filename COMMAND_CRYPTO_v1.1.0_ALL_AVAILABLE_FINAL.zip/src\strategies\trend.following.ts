import { Candle, Instrument, MarketRegime } from '../types/market.js';
import { MTFAnalysisResult } from '../analysis/mtf.analyzer.js';
import { StrategyCondition, StrategyReasoning } from '../types/strategy.js';
import { IStrategy } from './base.strategy.js';
import { TechnicalIndicators } from '../analysis/indicators.js';

export class TrendFollowingStrategy implements IStrategy {
  public readonly id = 'STRAT_TREND_FOLLOWING';
  public readonly name = 'Multi-Timeframe Trend Pullback';
  public readonly version = '1.2.0';
  public readonly description = 'Trades pullbacks in the direction of higher timeframe trend with ATR risk/reward';

  public evaluate(
    instrument: Instrument,
    candles: Candle[],
    regime: MarketRegime,
    mtf: MTFAnalysisResult
  ): StrategyReasoning {
    const closes = candles.map(c => c.close);
    const lastClose = closes[closes.length - 1];
    const atrSeries = TechnicalIndicators.atr(candles, 14);
    const atr = atrSeries[atrSeries.length - 1] || (lastClose * 0.01);

    const conditionsSatisfied: StrategyCondition[] = [];
    const conditionsFailed: StrategyCondition[] = [];

    // Condition 1: Higher Timeframe Trend Alignment
    const isHtfBull = mtf.higherTimeframe.trend === 'BULLISH';
    const isHtfBear = mtf.higherTimeframe.trend === 'BEARISH';
    if (isHtfBull || isHtfBear) {
      conditionsSatisfied.push({
        name: 'Higher Timeframe Trend',
        expected: 'BULLISH or BEARISH',
        actual: mtf.higherTimeframe.trend,
        satisfied: true,
        weight: 30
      });
    } else {
      conditionsFailed.push({
        name: 'Higher Timeframe Trend',
        expected: 'BULLISH or BEARISH',
        actual: mtf.higherTimeframe.trend,
        satisfied: false,
        weight: 30
      });
    }

    // Condition 2: Medium Timeframe Structure
    const isMtfPullback = mtf.mediumTimeframe.structure === 'PULLBACK' || mtf.mediumTimeframe.structure === 'BREAKOUT';
    if (isMtfPullback) {
      conditionsSatisfied.push({
        name: 'MTF Structure Condition',
        expected: 'PULLBACK or BREAKOUT',
        actual: mtf.mediumTimeframe.structure,
        satisfied: true,
        weight: 25
      });
    } else {
      conditionsFailed.push({
        name: 'MTF Structure Condition',
        expected: 'PULLBACK or BREAKOUT',
        actual: mtf.mediumTimeframe.structure,
        satisfied: false,
        weight: 25
      });
    }

    // Condition 3: Lower Timeframe Execution Trigger
    const isLtfTrigger = mtf.lowerTimeframe.trigger === 'CONFIRMED';
    if (isLtfTrigger) {
      conditionsSatisfied.push({
        name: 'LTF Trigger Confirmation',
        expected: 'CONFIRMED',
        actual: mtf.lowerTimeframe.trigger,
        satisfied: true,
        weight: 25
      });
    } else {
      conditionsFailed.push({
        name: 'LTF Trigger Confirmation',
        expected: 'CONFIRMED',
        actual: mtf.lowerTimeframe.trigger,
        satisfied: false,
        weight: 25
      });
    }

    // Condition 4: Volume confirmation
    const hasVolume = mtf.lowerTimeframe.volumeMultiplier >= 0.8;
    if (hasVolume) {
      conditionsSatisfied.push({
        name: 'Volume Expansion',
        expected: '>= 0.8x 20-period avg',
        actual: `${mtf.lowerTimeframe.volumeMultiplier.toFixed(2)}x`,
        satisfied: true,
        weight: 20
      });
    } else {
      conditionsFailed.push({
        name: 'Volume Expansion',
        expected: '>= 0.8x 20-period avg',
        actual: `${mtf.lowerTimeframe.volumeMultiplier.toFixed(2)}x`,
        satisfied: false,
        weight: 20
      });
    }

    // Direction & Levels
    const isBullish = isHtfBull && mtf.lowerTimeframe.trigger === 'CONFIRMED';
    const isBearish = isHtfBear && mtf.lowerTimeframe.trigger === 'CONFIRMED';

    const direction = isBullish ? 'BUY' : isBearish ? 'SELL' : 'NEUTRAL';
    const stopDistance = atr * 1.5;
    const targetDistance = atr * 3.0; // 1:2 R:R

    const stopLoss = isBullish ? lastClose - stopDistance : isBearish ? lastClose + stopDistance : lastClose * 0.98;
    const takeProfit = isBullish ? lastClose + targetDistance : isBearish ? lastClose - targetDistance : lastClose * 1.04;
    const takeProfit2 = isBullish ? lastClose + (targetDistance * 1.5) : isBearish ? lastClose - (targetDistance * 1.5) : undefined;
    const invalidationPrice = isBullish ? lastClose - stopDistance * 1.1 : lastClose + stopDistance * 1.1;

    const riskReward = stopDistance > 0 ? targetDistance / stopDistance : 2.0;

    // Technical Score calculation
    const totalWeightSatisfied = conditionsSatisfied.reduce((acc, c) => acc + c.weight, 0);
    const technicalScore = Math.min(100, Math.max(0, totalWeightSatisfied));

    let setupQuality: 'A+' | 'A' | 'B' | 'C' | 'INVALID' = 'INVALID';
    if (technicalScore >= 90) setupQuality = 'A+';
    else if (technicalScore >= 75) setupQuality = 'A';
    else if (technicalScore >= 60) setupQuality = 'B';
    else if (technicalScore >= 40) setupQuality = 'C';

    const isRegimeCompatible = regime.regime === 'TRENDING_BULL' || regime.regime === 'TRENDING_BEAR' || regime.regime === 'EXPANSION';
    const regimeCompatibilityScore = isRegimeCompatible ? 90 : (regime.regime === 'RANGING' ? 30 : 50);

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      direction,
      setupQuality,
      technicalScore,
      conditionsSatisfied,
      conditionsFailed,
      suggestedEntry: lastClose,
      stopLoss,
      takeProfit,
      takeProfit2,
      invalidationPrice,
      riskReward,
      timeframeContext: {
        higherTrend: mtf.higherTimeframe.trend,
        mediumStructure: mtf.mediumTimeframe.structure,
        lowerTrigger: mtf.lowerTimeframe.trigger
      },
      regimeCompatibility: {
        currentRegime: regime.regime,
        isCompatible: isRegimeCompatible,
        compatibilityScore: regimeCompatibilityScore,
        notes: isRegimeCompatible ? 'Optimal trending regime' : 'Sub-optimal regime for trend following'
      }
    };
  }
}
