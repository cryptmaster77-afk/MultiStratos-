import { ChronologicalWalkForwardEngine } from '../src/learning/walkforward.js';
import { Candle } from '../src/types/market.js';

export function testWalkForwardAntiLeakage(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];

  const candles: Candle[] = [];
  let price = 100;
  for (let i = 0; i < 100; i++) {
    price += (Math.sin(i * 0.1) * 1.5) + 0.2;
    candles.push({
      timestamp: 1700000000000 + i * 900000,
      open: price - 0.2,
      high: price + 0.8,
      low: price - 0.8,
      close: price,
      volume: 1500
    });
  }

  const result = ChronologicalWalkForwardEngine.validate(candles);
  tests.push({
    name: 'Walk-forward engine enforces strict chronological separation (anti-leakage)',
    passed: result.antiLeakageVerified === true && result.inSampleTrades >= 0,
    error: `Anti-leakage test failed: verified=${result.antiLeakageVerified}`
  });

  return tests;
}
