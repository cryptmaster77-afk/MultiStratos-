import { TechnicalIndicators } from '../src/analysis/indicators.js';
import { Candle } from '../src/types/market.js';

export function testIndicators(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];

  // 1. SMA test
  const prices = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
  const sma5 = TechnicalIndicators.sma(prices, 5);
  const lastSma = sma5[sma5.length - 1]; // (16+17+18+19+20)/5 = 18
  tests.push({
    name: 'SMA calculation precision',
    passed: Math.abs(lastSma - 18) < 0.0001,
    error: `Expected SMA 18, got ${lastSma}`
  });

  // 2. EMA test
  const ema5 = TechnicalIndicators.ema(prices, 5);
  const lastEma = ema5[ema5.length - 1];
  tests.push({
    name: 'EMA calculation is responsive and non-NaN',
    passed: !isNaN(lastEma) && lastEma > 17 && lastEma < 20,
    error: `EMA invalid: ${lastEma}`
  });

  // 3. RSI test
  const upPrices = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25];
  const rsi = TechnicalIndicators.rsi(upPrices, 14);
  const lastRsi = rsi[rsi.length - 1];
  tests.push({
    name: 'RSI strongly bullish on continuous uptrend',
    passed: lastRsi >= 90,
    error: `Expected RSI >= 90 for pure uptrend, got ${lastRsi}`
  });

  // 4. ATR test
  const candles: Candle[] = [];
  for (let i = 0; i < 20; i++) {
    candles.push({
      timestamp: i * 60000,
      open: 100 + i,
      high: 105 + i,
      low: 98 + i,
      close: 102 + i,
      volume: 1000
    });
  }
  const atr = TechnicalIndicators.atr(candles, 14);
  const lastAtr = atr[atr.length - 1];
  tests.push({
    name: 'ATR calculation is accurate',
    passed: lastAtr >= 6.5 && lastAtr <= 7.5,
    error: `Expected ATR ~7.0, got ${lastAtr}`
  });

  // 5. Bollinger Bands test
  const bb = TechnicalIndicators.bollingerBands(prices, 5, 2.0);
  const lastUpper = bb.upper[bb.upper.length - 1];
  const lastLower = bb.lower[bb.lower.length - 1];
  const lastMiddle = bb.middle[bb.middle.length - 1];
  tests.push({
    name: 'Bollinger Bands upper > middle > lower',
    passed: lastUpper > lastMiddle && lastMiddle > lastLower,
    error: `BB bounds inconsistent: U=${lastUpper}, M=${lastMiddle}, L=${lastLower}`
  });

  return tests;
}
