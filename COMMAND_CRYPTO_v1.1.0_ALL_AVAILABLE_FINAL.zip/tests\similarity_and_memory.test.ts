import { SimilarityEngine } from '../src/memory/similarity.engine.js';
import { ExperienceStore } from '../src/memory/experience.store.js';

export function testSimilarityAndMemory(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];
  const store = ExperienceStore.getInstance();
  const similarityEngine = SimilarityEngine.getInstance();

  // Test 1: Insufficient sample size fallback (no fake confidence)
  store.clear();
  const query = {
    symbol: 'BTC/USDT',
    assetClass: 'CRYPTO' as const,
    strategyId: 'STRAT_TREND_FOLLOWING',
    strategyVersion: '1.2.0',
    direction: 'BUY' as const,
    regime: 'TRENDING_BULL' as const,
    session: 'OPEN',
    timeframe: '15m' as const,
    strategyScore: 85,
    atrPct: 1.2,
    riskReward: 2.0
  };

  const emptyResult = similarityEngine.evaluateSimilarity(query);
  tests.push({
    name: 'Zero historical samples returns hasSufficientData: false & neutral score 50',
    passed: emptyResult.hasSufficientData === false && emptyResult.memoryScore === 50,
    error: `Expected neutral score 50 and false sufficient data, got score ${emptyResult.memoryScore}`
  });

  // Test 2: Populate repeated failure pattern
  for (let i = 0; i < 4; i++) {
    store.recordOpportunity({
      id: `HIST_FAIL_${i}`,
      timestamp: Date.now() - (i * 3600 * 1000),
      symbol: 'BTC/USDT',
      assetClass: 'CRYPTO',
      provider: 'bybit',
      strategyId: 'STRAT_TREND_FOLLOWING',
      strategyVersion: '1.2.0',
      direction: 'BUY',
      regime: 'TRENDING_BULL',
      session: 'OPEN',
      timeframe: '15m',
      strategyScore: 85,
      memoryScore: 50,
      regimeScore: 80,
      sentimentScore: 60,
      executionScore: 90,
      riskScore: 100,
      compositeScore: 80,
      entryPrice: 60000,
      stopLoss: 59000,
      takeProfit: 62000,
      plannedRiskReward: 2.0,
      slMethod: 'ATR',
      tpMethod: 'TRAILING',
      atr: 500,
      atrPct: 1.2,
      spreadBps: 1.0,
      decision: 'TRADE',
      baselineDecision: 'TRADE',
      lifecycleStatus: 'TRADED',
      outcomePopulated: true,
      realizedR: -1.0, // Consecutive losses
      realizedPnl: -5.0,
      exitReason: 'STOP_LOSS'
    });
  }

  // Add 2 more to satisfy min sample size (6 total)
  for (let i = 4; i < 6; i++) {
    store.recordOpportunity({
      id: `HIST_EXTRA_${i}`,
      timestamp: Date.now() - (i * 86400 * 1000),
      symbol: 'BTC/USDT',
      assetClass: 'CRYPTO',
      provider: 'bybit',
      strategyId: 'STRAT_TREND_FOLLOWING',
      strategyVersion: '1.2.0',
      direction: 'BUY',
      regime: 'TRENDING_BULL',
      session: 'OPEN',
      timeframe: '15m',
      strategyScore: 85,
      memoryScore: 50,
      regimeScore: 80,
      sentimentScore: 60,
      executionScore: 90,
      riskScore: 100,
      compositeScore: 80,
      entryPrice: 60000,
      stopLoss: 59000,
      takeProfit: 62000,
      plannedRiskReward: 2.0,
      slMethod: 'ATR',
      tpMethod: 'TRAILING',
      atr: 500,
      atrPct: 1.2,
      spreadBps: 1.0,
      decision: 'TRADE',
      baselineDecision: 'TRADE',
      lifecycleStatus: 'TRADED',
      outcomePopulated: true,
      realizedR: -1.0,
      realizedPnl: -5.0,
      exitReason: 'STOP_LOSS'
    });
  }

  const failureResult = similarityEngine.evaluateSimilarity(query);
  tests.push({
    name: 'Repeated failure pattern detector catches consecutive losses',
    passed: failureResult.repeatedFailureDetected === true && failureResult.recommendedConfidenceMultiplier <= 0.7,
    error: `Failure pattern not triggered: detected=${failureResult.repeatedFailureDetected}, mult=${failureResult.recommendedConfidenceMultiplier}`
  });

  return tests;
}
