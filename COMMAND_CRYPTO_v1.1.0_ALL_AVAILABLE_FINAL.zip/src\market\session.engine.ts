import { AssetClass, MarketHours, MarketSession } from '../types/market.js';
import { ASSET_CLASS_CONFIG } from '../config/constants.js';

export class SessionEngine {
  /**
   * Evaluates the current market session for a given asset class or custom market hours.
   */
  public static getSessionStatus(assetClass: AssetClass, customHours?: MarketHours, referenceTimeMs: number = Date.now()): {
    status: MarketSession;
    isOpen: boolean;
    isPreMarket: boolean;
    isPostMarket: boolean;
    timeUntilOpenMinutes: number;
    timeUntilCloseMinutes: number;
    sessionDescription: string;
  } {
    const config = ASSET_CLASS_CONFIG[assetClass];
    const hours = customHours || config.session;
    
    // 24/7 Crypto markets are always open
    if (hours.is24x7) {
      return {
        status: 'OPEN',
        isOpen: true,
        isPreMarket: false,
        isPostMarket: false,
        timeUntilOpenMinutes: 0,
        timeUntilCloseMinutes: Infinity,
        sessionDescription: '24/7 Continuous Trading'
      };
    }

    const date = new Date(referenceTimeMs);
    const dayOfWeek = date.getUTCDay(); // 0 = Sun, 1 = Mon, ..., 6 = Sat
    const utcHour = date.getUTCHours();
    const utcMinute = date.getUTCMinutes();
    const currentUtcMinutes = utcHour * 60 + utcMinute;

    // Forex Market Schedule: Opens Sunday 22:00 UTC, Closes Friday 22:00 UTC
    if (assetClass === 'FOREX') {
      if (dayOfWeek === 6) { // Saturday closed
        const minUntilSunOpen = (24 - utcHour) * 60 - utcMinute + 22 * 60;
        return {
          status: 'WEEKEND',
          isOpen: false,
          isPreMarket: false,
          isPostMarket: false,
          timeUntilOpenMinutes: minUntilSunOpen,
          timeUntilCloseMinutes: 0,
          sessionDescription: 'Weekend Closed (Opens Sun 22:00 UTC)'
        };
      }
      if (dayOfWeek === 0 && currentUtcMinutes < 22 * 60) { // Sunday before 22:00 UTC
        const minUntilOpen = 22 * 60 - currentUtcMinutes;
        return {
          status: 'CLOSED',
          isOpen: false,
          isPreMarket: minUntilOpen <= 60,
          isPostMarket: false,
          timeUntilOpenMinutes: minUntilOpen,
          timeUntilCloseMinutes: 0,
          sessionDescription: `Pre-Market (Opens in ${minUntilOpen}m)`
        };
      }
      if (dayOfWeek === 5 && currentUtcMinutes >= 22 * 60) { // Friday after 22:00 UTC
        return {
          status: 'WEEKEND',
          isOpen: false,
          isPreMarket: false,
          isPostMarket: false,
          timeUntilOpenMinutes: 48 * 60 - (currentUtcMinutes - 22 * 60),
          timeUntilCloseMinutes: 0,
          sessionDescription: 'Weekend Closed (Closes Fri 22:00 UTC)'
        };
      }
      return {
        status: 'OPEN',
        isOpen: true,
        isPreMarket: false,
        isPostMarket: false,
        timeUntilOpenMinutes: 0,
        timeUntilCloseMinutes: 60,
        sessionDescription: 'Forex Global Session Active'
      };
    }

    // US Stock / Index Schedule: Regular hours 13:30 - 20:00 UTC (09:30 - 16:00 EST)
    if (assetClass === 'STOCKS' || assetClass === 'INDICES') {
      if (dayOfWeek === 0 || dayOfWeek === 6) {
        return {
          status: 'WEEKEND',
          isOpen: false,
          isPreMarket: false,
          isPostMarket: false,
          timeUntilOpenMinutes: 0,
          timeUntilCloseMinutes: 0,
          sessionDescription: 'Weekend Closed'
        };
      }

      const openMin = 13 * 60 + 30; // 13:30 UTC
      const closeMin = 20 * 60;     // 20:00 UTC
      const preMarketStartMin = 8 * 60; // 04:00 EST / 08:00 UTC
      const postMarketEndMin = 24 * 60; // 20:00 EST / 00:00 UTC

      if (currentUtcMinutes >= openMin && currentUtcMinutes < closeMin) {
        return {
          status: 'OPEN',
          isOpen: true,
          isPreMarket: false,
          isPostMarket: false,
          timeUntilOpenMinutes: 0,
          timeUntilCloseMinutes: closeMin - currentUtcMinutes,
          sessionDescription: 'US Regular Trading Session'
        };
      }

      if (currentUtcMinutes >= preMarketStartMin && currentUtcMinutes < openMin) {
        return {
          status: 'PRE_MARKET',
          isOpen: false,
          isPreMarket: true,
          isPostMarket: false,
          timeUntilOpenMinutes: openMin - currentUtcMinutes,
          timeUntilCloseMinutes: 0,
          sessionDescription: `Pre-Market Trading (${openMin - currentUtcMinutes}m to regular open)`
        };
      }

      if (currentUtcMinutes >= closeMin && currentUtcMinutes < postMarketEndMin) {
        return {
          status: 'POST_MARKET',
          isOpen: false,
          isPreMarket: false,
          isPostMarket: true,
          timeUntilOpenMinutes: (24 * 60 - currentUtcMinutes) + openMin,
          timeUntilCloseMinutes: 0,
          sessionDescription: 'After-Hours / Post-Market Trading'
        };
      }

      return {
        status: 'CLOSED',
        isOpen: false,
        isPreMarket: false,
        isPostMarket: false,
        timeUntilOpenMinutes: openMin > currentUtcMinutes ? openMin - currentUtcMinutes : (24 * 60 - currentUtcMinutes) + openMin,
        timeUntilCloseMinutes: 0,
        sessionDescription: 'Market Closed'
      };
    }

    // Metals & Commodities Schedule (Daily break 22:00 - 23:00 UTC, Weekend closed Fri 22:00 - Sun 23:00 UTC)
    if (assetClass === 'METALS' || assetClass === 'COMMODITIES') {
      if (dayOfWeek === 6 || (dayOfWeek === 0 && currentUtcMinutes < 23 * 60) || (dayOfWeek === 5 && currentUtcMinutes >= 22 * 60)) {
        return {
          status: 'WEEKEND',
          isOpen: false,
          isPreMarket: false,
          isPostMarket: false,
          timeUntilOpenMinutes: 0,
          timeUntilCloseMinutes: 0,
          sessionDescription: 'Commodity/Metals Weekend Closed'
        };
      }

      if (currentUtcMinutes >= 22 * 60 && currentUtcMinutes < 23 * 60) {
        return {
          status: 'CLOSED',
          isOpen: false,
          isPreMarket: false,
          isPostMarket: false,
          timeUntilOpenMinutes: 23 * 60 - currentUtcMinutes,
          timeUntilCloseMinutes: 0,
          sessionDescription: 'Daily CME Settlement Break (22:00 - 23:00 UTC)'
        };
      }

      return {
        status: 'OPEN',
        isOpen: true,
        isPreMarket: false,
        isPostMarket: false,
        timeUntilOpenMinutes: 0,
        timeUntilCloseMinutes: (22 * 60 - currentUtcMinutes + 24 * 60) % (24 * 60),
        sessionDescription: 'Active Futures Session'
      };
    }

    return {
      status: 'OPEN',
      isOpen: true,
      isPreMarket: false,
      isPostMarket: false,
      timeUntilOpenMinutes: 0,
      timeUntilCloseMinutes: 0,
      sessionDescription: 'Standard Trading Hours'
    };
  }
}
