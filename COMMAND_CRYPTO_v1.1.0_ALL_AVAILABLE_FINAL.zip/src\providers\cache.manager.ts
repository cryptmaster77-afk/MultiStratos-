import { Candle, Quote, Timeframe } from '../types/market.js';

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttlMs: number;
}

export class CacheManager {
  private static instance: CacheManager;
  private memoryCache = new Map<string, CacheEntry<any>>();

  // Cache hit/miss metrics
  public hits: number = 0;
  public misses: number = 0;

  private constructor() {}

  public static getInstance(): CacheManager {
    if (!this.instance) {
      this.instance = new CacheManager();
    }
    return this.instance;
  }

  /**
   * Returns optimal TTL based on timeframe to avoid redundant API requests.
   */
  public static getTimeframeTtlMs(timeframe: Timeframe): number {
    switch (timeframe) {
      case '1m': return 45 * 1000;         // 45s
      case '5m': return 3 * 60 * 1000;     // 3 min
      case '15m': return 8 * 60 * 1000;    // 8 min
      case '30m': return 15 * 60 * 1000;   // 15 min
      case '1h': return 30 * 60 * 1000;    // 30 min
      case '4h': return 2 * 3600 * 1000;   // 2 hours
      case '1d': return 6 * 3600 * 1000;   // 6 hours
      case '1w': return 24 * 3600 * 1000;  // 24 hours
      default: return 5 * 60 * 1000;
    }
  }

  public getCandles(provider: string, symbol: string, timeframe: Timeframe): Candle[] | null {
    const key = `candles:${provider}:${symbol}:${timeframe}`;
    const entry = this.memoryCache.get(key);
    
    if (entry && (Date.now() - entry.timestamp) < entry.ttlMs) {
      this.hits++;
      return entry.data;
    }

    this.misses++;
    return null;
  }

  public setCandles(provider: string, symbol: string, timeframe: Timeframe, candles: Candle[], customTtlMs?: number): void {
    const key = `candles:${provider}:${symbol}:${timeframe}`;
    const ttlMs = customTtlMs || CacheManager.getTimeframeTtlMs(timeframe);
    this.memoryCache.set(key, {
      data: candles,
      timestamp: Date.now(),
      ttlMs
    });
  }

  public getQuote(provider: string, symbol: string): Quote | null {
    const key = `quote:${provider}:${symbol}`;
    const entry = this.memoryCache.get(key);

    if (entry && (Date.now() - entry.timestamp) < entry.ttlMs) {
      this.hits++;
      return entry.data;
    }

    this.misses++;
    return null;
  }

  public setQuote(provider: string, symbol: string, quote: Quote, ttlMs: number = 30000): void {
    const key = `quote:${provider}:${symbol}`;
    this.memoryCache.set(key, {
      data: quote,
      timestamp: Date.now(),
      ttlMs
    });
  }

  public getMetrics(): { hits: number; misses: number; hitRatio: number; entries: number } {
    const total = this.hits + this.misses;
    return {
      hits: this.hits,
      misses: this.misses,
      hitRatio: total > 0 ? (this.hits / total) * 100 : 0,
      entries: this.memoryCache.size
    };
  }

  public clear(): void {
    this.memoryCache.clear();
    this.hits = 0;
    this.misses = 0;
  }
}
