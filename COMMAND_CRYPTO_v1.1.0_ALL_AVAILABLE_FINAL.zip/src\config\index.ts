import * as dotenv from 'dotenv';
import * as path from 'path';

// Load .env file
dotenv.config();

export interface AppConfig {
  systemMode: 'PAPER' | 'LIVE';
  paper: {
    initialBalance: number;
    leverage: number;
    slippageBps: number;
    feeBps: number;
  };
  liveGates: {
    acknowledged: boolean;
    confirmationPhrase: string;
    maxDrawdownKillPct: number;
  };
  risk: {
    maxRiskPerTradePct: number;
    maxDailyLossPct: number;
    maxPortfolioExposurePct: number;
    maxConcurrentPositions: number;
    maxCorrelatedExposurePct: number;
    defaultLeverage: number;
  };
  scanner: {
    universeMode: 'ALL' | 'CUSTOM';
    autopilotEnabled: boolean;
    cryptoBatchSize: number;
    cryptoBatchDelayMs: number;
    extendedIntervalMinutes: number;
    extendedBatchSize: number;
    extendedRequestDelayMs: number;
    scanCrypto: boolean;
    scanForex: boolean;
    scanMetals: boolean;
    scanIndices: boolean;
    scanStocks: boolean;
    scanCommodities: boolean;
  };
  providers: {
    bybit: {
      apiKey: string;
      apiSecret: string;
    };
    twelvedata: {
      apiKey: string;
      dailyBudget: number;
      burstPerMinute: number;
      reservedSafetyBuffer: number;
    };
    alphavantage: {
      apiKey: string;
    };
  };
  sentiment: {
    enabled: boolean;
    cacheTtlMinutes: number;
  };
  memory: {
    enabled: boolean;
    similarityThreshold: number;
    minSamplesForMemory: number;
    recencyHalfLifeDays: number;
    repeatedFailureThreshold: number;
    learningAlphaMode: boolean;
  };
  notifications: {
    telegramBotToken: string;
    telegramChatId: string;
    webhookUrl: string;
    throttleSeconds: number;
  };
  server: {
    port: number;
    host: string;
    authToken: string;
  };
  paths: {
    rootDir: string;
    dataDir: string;
    checkpointsDir: string;
    memoryDir: string;
    learningDir: string;
  };
}

const rootDir = process.cwd();
const dataDir = path.join(rootDir, 'data');

export const config: AppConfig = {
  systemMode: (process.env.SYSTEM_MODE?.toUpperCase() === 'LIVE' ? 'LIVE' : 'PAPER') as 'PAPER' | 'LIVE',
  paper: {
    initialBalance: parseFloat(process.env.PAPER_INITIAL_BALANCE || '100.00'),
    leverage: parseInt(process.env.PAPER_LEVERAGE || '1', 10),
    slippageBps: parseInt(process.env.PAPER_SLIPPAGE_BPS || '3', 10),
    feeBps: parseInt(process.env.PAPER_FEE_BPS || '5', 10)
  },
  liveGates: {
    acknowledged: process.env.LIVE_SAFETY_ACKNOWLEDGED === 'true',
    confirmationPhrase: process.env.LIVE_CONFIRMATION_PHRASE || '',
    maxDrawdownKillPct: parseFloat(process.env.MAX_DRAWDOWN_KILL_PCT || '5.0')
  },
  risk: {
    maxRiskPerTradePct: parseFloat(process.env.MAX_RISK_PER_TRADE_PCT || '0.5'),
    maxDailyLossPct: parseFloat(process.env.MAX_DAILY_LOSS_PCT || '3.0'),
    maxPortfolioExposurePct: parseFloat(process.env.MAX_PORTFOLIO_EXPOSURE_PCT || '20.0'),
    maxConcurrentPositions: parseInt(process.env.MAX_CONCURRENT_POSITIONS || '5', 10),
    maxCorrelatedExposurePct: parseFloat(process.env.MAX_CORRELATED_EXPOSURE_PCT || '10.0'),
    defaultLeverage: parseInt(process.env.DEFAULT_LEVERAGE || '1', 10)
  },
  scanner: {
    universeMode: (process.env.MARKET_UNIVERSE_MODE?.toUpperCase() === 'CUSTOM' ? 'CUSTOM' : 'ALL') as 'ALL' | 'CUSTOM',
    autopilotEnabled: process.env.AUTOPILOT_ENABLED === 'true',
    cryptoBatchSize: parseInt(process.env.CRYPTO_BATCH_SIZE || '4', 10),
    cryptoBatchDelayMs: parseInt(process.env.CRYPTO_BATCH_DELAY_MS || '1500', 10),
    extendedIntervalMinutes: parseInt(process.env.EXTENDED_SCAN_INTERVAL_MINUTES || '30', 10),
    extendedBatchSize: parseInt(process.env.EXTENDED_BATCH_SIZE || '4', 10),
    extendedRequestDelayMs: parseInt(process.env.EXTENDED_REQUEST_DELAY_MS || '2000', 10),
    scanCrypto: process.env.SCAN_CRYPTO !== 'false',
    scanForex: process.env.SCAN_FOREX !== 'false',
    scanMetals: process.env.SCAN_METALS !== 'false',
    scanIndices: process.env.SCAN_INDICES !== 'false',
    scanStocks: process.env.SCAN_STOCKS !== 'false',
    scanCommodities: process.env.SCAN_COMMODITIES !== 'false'
  },
  providers: {
    bybit: {
      apiKey: process.env.BYBIT_API_KEY || '',
      apiSecret: process.env.BYBIT_API_SECRET || ''
    },
    twelvedata: {
      apiKey: process.env.TWELVEDATA_API_KEY || '',
      dailyBudget: parseInt(process.env.TWELVEDATA_DAILY_BUDGET || '800', 10),
      burstPerMinute: parseInt(process.env.TWELVEDATA_BURST_PER_MIN || '8', 10),
      reservedSafetyBuffer: parseInt(process.env.TWELVEDATA_SAFETY_BUFFER || '80', 10)
    },
    alphavantage: {
      apiKey: process.env.ALPHAVANTAGE_API_KEY || ''
    }
  },
  sentiment: {
    enabled: process.env.ENABLE_SENTIMENT !== 'false',
    cacheTtlMinutes: parseInt(process.env.SENTIMENT_CACHE_TTL_MINUTES || '30', 10)
  },
  memory: {
    enabled: process.env.ENABLE_ADAPTIVE_MEMORY !== 'false',
    similarityThreshold: parseFloat(process.env.SIMILARITY_THRESHOLD || '0.72'),
    minSamplesForMemory: parseInt(process.env.MIN_SAMPLES_FOR_MEMORY || '5', 10),
    recencyHalfLifeDays: parseInt(process.env.MEMORY_RECENCY_HALFLIFE_DAYS || '30', 10),
    repeatedFailureThreshold: parseInt(process.env.REPEATED_FAILURE_THRESHOLD || '3', 10),
    learningAlphaMode: process.env.LEARNING_ALPHA_MODE === 'true'
  },
  notifications: {
    telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || '',
    telegramChatId: process.env.TELEGRAM_CHAT_ID || '',
    webhookUrl: process.env.WEBHOOK_URL || '',
    throttleSeconds: parseInt(process.env.NOTIFICATION_THROTTLE_SECONDS || '60', 10)
  },
  server: {
    port: parseInt(process.env.PORT || '3000', 10),
    host: process.env.HOST || '0.0.0.0',
    authToken: process.env.AUTH_TOKEN || ''
  },
  paths: {
    rootDir,
    dataDir,
    checkpointsDir: path.join(dataDir, 'checkpoints'),
    memoryDir: path.join(dataDir, 'memory'),
    learningDir: path.join(dataDir, 'learning')
  }
};
