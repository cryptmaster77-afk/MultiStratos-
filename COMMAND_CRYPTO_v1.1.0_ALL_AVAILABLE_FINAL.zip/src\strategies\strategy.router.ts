import { Candle, Instrument, MarketRegime } from '../types/market.js';
import { MTFAnalysisResult } from '../analysis/mtf.analyzer.js';
import { StrategyReasoning } from '../types/strategy.js';
import { IStrategy } from './base.strategy.js';
import { TrendFollowingStrategy } from './trend.following.js';
import { MeanReversionStrategy } from './mean.reversion.js';
import { VolatilityBreakoutStrategy } from './breakout.js';
import { MomentumSupportResistanceStrategy } from './momentum.sr.js';

export class StrategyRouter {
  private static instance: StrategyRouter;
  private strategies: IStrategy[] = [];

  private constructor() {
    this.strategies = [
      new TrendFollowingStrategy(),
      new VolatilityBreakoutStrategy(),
      new MeanReversionStrategy(),
      new MomentumSupportResistanceStrategy()
    ];
  }

  public static getInstance(): StrategyRouter {
    if (!this.instance) {
      this.instance = new StrategyRouter();
    }
    return this.instance;
  }

  /**
   * Evaluates all strategies and selects the candidate setup with the best regime-adjusted technical score.
   */
  public evaluateAll(
    instrument: Instrument,
    candles: Candle[],
    regime: MarketRegime,
    mtf: MTFAnalysisResult
  ): {
    bestReasoning: StrategyReasoning;
    allEvaluations: StrategyReasoning[];
  } {
    const evaluations = this.strategies.map(s => s.evaluate(instrument, candles, regime, mtf));

    // Sort by regime-weighted technical score
    const scored = evaluations.map(ev => {
      const regimeWeight = ev.regimeCompatibility.compatibilityScore / 100;
      const effectiveScore = ev.technicalScore * (0.6 + 0.4 * regimeWeight);
      return { ev, effectiveScore };
    });

    scored.sort((a, b) => b.effectiveScore - a.effectiveScore);

    return {
      bestReasoning: scored[0].ev,
      allEvaluations: evaluations
    };
  }
}
