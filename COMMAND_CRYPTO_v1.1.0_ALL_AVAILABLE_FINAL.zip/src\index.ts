import { WebServer } from './server/app.js';
import { AutopilotEngine } from './scanner/autopilot.js';
import { config } from './config/index.js';

async function bootstrap() {
  const server = new WebServer();
  await server.start();

  const autopilot = AutopilotEngine.getInstance();
  if (config.scanner.autopilotEnabled) {
    autopilot.start();
  }

  // Graceful shutdown handling
  const shutdown = async () => {
    console.log('\n[System] Gracefully shutting down...');
    autopilot.stop();
    await server.stop();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

bootstrap().catch(err => {
  console.error('[System] Fatal bootstrap error:', err);
  process.exit(1);
});
