import { ScoringEngine } from '../src/decision/scoring.engine.js';
import { DecisionEngine } from '../src/decision/decision.engine.js';
import { StrategyReasoning } from '../src/types/strategy.js';
import { SetupSimilarityResult } from '../src/types/memory.js';
import { SentimentSnapshot } from '../src/sentiment/sentiment.types.js';
import { AccountState } from '../src/types/risk.js';
import { Instrument, Quote } from '../src/types/market.js';
import { MarketDiscoveryService } from '../src/market/discovery.js';

export function testScoringAndDecision(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];

  const mockReasoning: StrategyReasoning = {
    strategyId: 'STRAT_TREND_FOLLOWING',
    strategyName: 'Trend Pullback',
    strategyVersion: '1.2.0',
    direction: 'BUY',
    setupQuality: 'A',
    technicalScore: 88,
    conditionsSatisfied: [{ name: 'Trend', expected: 'BULL', actual: 'BULL', satisfied: true, weight: 50 }],
    conditionsFailed: [],
    suggestedEntry: 100,
    stopLoss: 98,
    takeProfit: 104,
    invalidationPrice: 97,
    riskReward: 2.0,
    timeframeContext: { higherTrend: 'BULLISH', mediumStructure: 'PULLBACK', lowerTrigger: 'CONFIRMED' },
    regimeCompatibility: { currentRegime: 'TRENDING_BULL', isCompatible: true, compatibilityScore: 90, notes: 'Optimal' }
  };

  const mockSimilarity: SetupSimilarityResult = {
    hasSufficientData: true,
    sampleCount: 10,
    averageSimilarity: 0.85,
    historicalWinRate: 0.70,
    historicalExpectancyR: 0.65,
    historicalProfitFactor: 2.3,
    historicalAvgMae: 0.4,
    historicalAvgMfe: 1.8,
    repeatedFailureDetected: false,
    failurePatternCount: 0,
    recommendedConfidenceMultiplier: 1.0,
    memoryScore: 85,
    notes: 'Strong historical performance',
    topMatches: []
  };

  const mockSentiment: SentimentSnapshot = {
    source: 'Crypto F&G',
    assetClass: 'CRYPTO',
    sentimentScore: 65,
    sentimentLabel: 'GREED',
    confidence: 80,
    timestamp: Date.now(),
    ttlMs: 300000,
    isStale: false,
    notes: 'Greed'
  };

  const mockAccount: AccountState = {
    mode: 'PAPER',
    currency: 'USD',
    initialBalance: 100,
    balance: 100,
    equity: 100,
    unrealizedPnl: 0,
    realizedPnl: 0,
    dailyStartingEquity: 100,
    dailyRealizedPnl: 0,
    dailyUnrealizedPnl: 0,
    dailyDrawdownPct: 0,
    maxDrawdownPct: 0,
    openPositionsCount: 0,
    totalExposure: 0,
    totalExposurePct: 0,
    emergencyStop: false,
    lastUpdated: Date.now()
  };

  const mockQuote: Quote = {
    symbol: 'BTC/USDT',
    bid: 100,
    ask: 100.02,
    last: 100.01,
    spread: 0.02,
    spreadBps: 2.0,
    timestamp: Date.now()
  };

  // 1. Compute Scores
  const scores = ScoringEngine.computeScores(mockReasoning, mockSimilarity, mockSentiment, mockAccount, mockQuote);
  tests.push({
    name: 'Scoring engine outputs 6 distinct explainable pillars',
    passed: scores.strategyScore === 88 &&
            scores.memoryScore === 85 &&
            scores.regimeScore === 90 &&
            scores.sentimentScore === 65 &&
            scores.compositeScore >= 80,
    error: `Scores mismatch: Strat=${scores.strategyScore}, Mem=${scores.memoryScore}, Comp=${scores.compositeScore}`
  });

  // 2. Qualified Trade Decision
  const inst = MarketDiscoveryService.getUniverse()[0];
  inst.sessionStatus = 'OPEN';
  const decision = DecisionEngine.evaluateDecision(inst, mockReasoning, scores, mockSimilarity, mockSentiment, mockAccount);
  tests.push({
    name: 'Decision engine qualifies valid high-conviction setup for TRADE',
    passed: decision.decision === 'TRADE' && decision.decisionReason.includes('Technical score'),
    error: `Expected TRADE, got ${decision.decision}: ${decision.decisionReason}`
  });

  // 3. Repeated Failure Override
  const failedSimilarity: SetupSimilarityResult = {
    ...mockSimilarity,
    repeatedFailureDetected: true,
    failurePatternCount: 3,
    memoryScore: 30
  };
  const failDecision = DecisionEngine.evaluateDecision(inst, mockReasoning, scores, failedSimilarity, mockSentiment, mockAccount);
  tests.push({
    name: 'Adaptive decision suppresses TRADE to WAIT when repeated failure detected',
    passed: failDecision.decision === 'WAIT' && failDecision.decisionReason.includes('consecutive historical failures'),
    error: `Expected WAIT on repeated failures, got ${failDecision.decision}`
  });

  return tests;
}
