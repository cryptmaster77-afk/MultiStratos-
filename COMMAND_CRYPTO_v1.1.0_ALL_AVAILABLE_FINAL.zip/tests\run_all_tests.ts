import { testClassification } from './classification.test.js';
import { testSessions } from './sessions.test.js';
import { testIndicators } from './indicators.test.js';
import { testRegimeAndStrategies } from './regime_and_strategies.test.js';
import { testSimilarityAndMemory } from './similarity_and_memory.test.js';
import { testScoringAndDecision } from './scoring_and_decision.test.js';
import { testRiskAndSizing } from './risk_and_sizing.test.js';
import { testLiveSafetyGates } from './live_safety_gates.test.js';
import { testExecutionAndTrailing } from './execution_and_trailing.test.js';
import { testScannerPersistence } from './scanner_persistence.test.js';
import { testProviderQuota } from './provider_quota.test.js';
import { testWalkForwardAntiLeakage } from './walkforward_anti_leakage.test.js';
import { testDiscoveryUniverse } from './discovery_universe.test.js';

interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

async function runTestSuite() {
  console.log('\n===============================================================');
  console.log('🧪 RUNNING MULTI-ASSET QUANTITATIVE TRADING CENTER TEST SUITE');
  console.log('===============================================================\n');

  const allResults: { suite: string; results: TestResult[] }[] = [];

  // 1. Classification
  allResults.push({ suite: 'Asset Discovery & Classification', results: testClassification() });

  // 2. Sessions
  allResults.push({ suite: 'Market Session Schedules (24/7, Hours, Weekend)', results: testSessions() });

  // 3. Technical Indicators
  allResults.push({ suite: 'Mathematical Technical Indicators (SMA, EMA, RSI, ATR, BB)', results: testIndicators() });

  // 4. Regime & Strategies
  allResults.push({ suite: 'Regime Detection & Multi-Timeframe Strategies', results: testRegimeAndStrategies() });

  // 5. Similarity & Memory
  allResults.push({ suite: 'Adaptive Trade Memory & 10D Setup Similarity', results: testSimilarityAndMemory() });

  // 6. Scoring & Decision
  allResults.push({ suite: '6-Factor Scoring & Explainable Decisions (TRADE/WAIT/REJECT)', results: testScoringAndDecision() });

  // 7. Risk & Sizing
  allResults.push({ suite: 'Quantitative Position Sizing & Portfolio Exposure Caps', results: testRiskAndSizing() });

  // 8. LIVE Safety Gates
  allResults.push({ suite: 'Strict LIVE Safety Gates & Rejection Reasoning', results: testLiveSafetyGates() });

  // 9. Execution & Trailing
  allResults.push({ suite: 'Execution Engine & Trailing Stop Activation', results: testExecutionAndTrailing() });

  // 10. Scanner Persistence
  allResults.push({ suite: 'Persistent Scanner Checkpoints & Resumability', results: await testScannerPersistence() });

  // 11. Provider Quotas
  allResults.push({ suite: 'Provider Quota Budgets & Minute Burst Limits', results: testProviderQuota() });

  // 12. Walk-Forward Anti-Leakage
  allResults.push({ suite: 'Chronological Walk-Forward & Anti-Leakage Protection', results: testWalkForwardAntiLeakage() });

  // 13. Global Market Universe & Discovery
  allResults.push({ suite: 'Global Market Universe Discovery & 6-Asset Coverage', results: testDiscoveryUniverse() });

  let totalTests = 0;
  let passedTests = 0;
  let failedTests = 0;

  for (const group of allResults) {
    console.log(`\n📌 [SUITE] ${group.suite}`);
    for (const r of group.results) {
      totalTests++;
      if (r.passed) {
        passedTests++;
        console.log(`  ✅ PASS: ${r.name}`);
      } else {
        failedTests++;
        console.log(`  ❌ FAIL: ${r.name}`);
        if (r.error) console.log(`     👉 Reason: ${r.error}`);
      }
    }
  }

  console.log('\n===============================================================');
  console.log(`📊 TEST SUITE SUMMARY: ${passedTests}/${totalTests} PASSED (${((passedTests / totalTests) * 100).toFixed(1)}%)`);
  console.log('===============================================================\n');

  if (failedTests > 0) {
    process.exit(1);
  }
}

runTestSuite().catch(err => {
  console.error('Fatal test execution error:', err);
  process.exit(1);
});
