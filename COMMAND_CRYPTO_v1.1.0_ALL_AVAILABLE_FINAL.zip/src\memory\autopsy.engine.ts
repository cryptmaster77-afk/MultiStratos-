import { Position } from '../types/risk.js';
import { TradeAutopsy } from '../types/memory.js';

export class TradeAutopsyEngine {
  /**
   * Performs an automated forensic post-trade autopsy to extract actionable intelligence.
   */
  public static performAutopsy(position: Position): TradeAutopsy {
    const outcomeR = position.realizedPnl !== 0 
      ? position.realizedPnl / Math.max(0.01, (Math.abs(position.entryPrice - position.initialStopLoss) * position.sizeUnits))
      : 0;

    const holdingTimeMs = (position.closedAt || Date.now()) - position.openedAt;
    const holdingTimeMinutes = Math.round(holdingTimeMs / 60000);

    // Stop Loss Tightness Analysis: Did price barely hit SL and then reverse in the planned direction?
    const wasSlTooTight = position.exitReason === 'STOP_LOSS' && position.mae <= (Math.abs(position.entryPrice - position.initialStopLoss) * 1.05);

    // Take Profit Realism: Did price reach >= 1.5R favorable excursion but fail to reach ambitious TP?
    const wasTpTooAmbitious = position.mfe >= 1.5 && (position.exitReason === 'STOP_LOSS' || position.exitReason === 'TRAILING_STOP') && outcomeR < 0.5;

    // Trailing Stop effectiveness
    const didTrailingHelp = position.trailingStopActive && outcomeR > 0.5;

    // Diagnose Root Cause
    let varianceOrError: 'NORMAL_STATISTICAL_VARIANCE' | 'EXECUTION_SLIPPAGE' | 'REGIME_CHANGE' | 'BAD_TIMING' | 'OVER_LEVERAGED' = 'NORMAL_STATISTICAL_VARIANCE';
    let lesson = 'Execution behaved within normal statistical variance parameters.';

    if (wasSlTooTight) {
      varianceOrError = 'BAD_TIMING';
      lesson = 'Stop loss was set too tightly within market noise band. Recommend increasing ATR buffer multiplier from 1.5x to 1.8x.';
    } else if (wasTpTooAmbitious) {
      varianceOrError = 'REGIME_CHANGE';
      lesson = 'Target was overly ambitious in a compressing regime. Trade reached >1.5R MFE before reversal. Recommend partial profit lock at 1.0R.';
    } else if (position.exitReason === 'TAKE_PROFIT' || position.exitReason === 'TAKE_PROFIT_2') {
      varianceOrError = 'NORMAL_STATISTICAL_VARIANCE';
      lesson = `Target reached successfully (+${outcomeR.toFixed(2)}R) following strategy rules.`;
    }

    return {
      tradeId: position.id,
      symbol: position.symbol,
      strategyId: position.strategyId,
      outcomeR,
      realizedPnl: position.realizedPnl,
      holdingTimeMinutes,
      exitReason: position.exitReason || 'MANUAL_CLOSE',
      wasSetupValidAtEntry: true,
      wasRegimeCorrectlyIdentified: true,
      wasEntryTimingOptimal: !wasSlTooTight,
      wasSlTooTight,
      wasTpTooAmbitious,
      didTrailingHelp,
      varianceOrError,
      memoryEngineLesson: lesson
    };
  }
}
