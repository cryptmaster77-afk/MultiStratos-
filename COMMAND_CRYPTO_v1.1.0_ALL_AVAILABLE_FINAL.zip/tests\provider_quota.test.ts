import { QuotaManager } from '../src/providers/quota.manager.js';
import { CacheManager } from '../src/providers/cache.manager.js';

export function testProviderQuota(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];

  // 1. Quota Burst Limit Test
  const quota = QuotaManager.getInstance({
    providerName: 'test_provider_burst',
    dailyBudget: 100,
    burstLimitPerMinute: 3,
    reservedSafetyBuffer: 10
  });

  // Record 3 requests
  quota.recordRequest();
  quota.recordRequest();
  quota.recordRequest();

  const fourthCheck = quota.canMakeRequest('STANDARD_SCAN');
  tests.push({
    name: 'Quota Manager enforces minute burst limit (e.g. 8/min)',
    passed: fourthCheck.allowed === false && (fourthCheck.reason?.includes('burst limit') ?? false),
    error: `Burst limit not enforced: allowed=${fourthCheck.allowed}`
  });

  // 2. Safety Reserve Buffer Test
  const reserveQuota = QuotaManager.getInstance({
    providerName: 'test_provider_reserve',
    dailyBudget: 20,
    burstLimitPerMinute: 100,
    reservedSafetyBuffer: 5
  });

  // Consume 16 requests (leaving 4, which is <= 5 safety reserve)
  for (let i = 0; i < 16; i++) {
    reserveQuota.recordRequest();
  }

  const scanCheck = reserveQuota.canMakeRequest('STANDARD_SCAN');
  const posCheck = reserveQuota.canMakeRequest('HIGH_PRIORITY_POSITION');

  tests.push({
    name: 'Quota Manager preserves safety reserve buffer by blocking scans while allowing priority positions',
    passed: scanCheck.allowed === false && posCheck.allowed === true,
    error: `Reserve check failed: scanAllowed=${scanCheck.allowed}, posAllowed=${posCheck.allowed}`
  });

  // 3. Cache TTL & Hit Metrics Test
  const cache = CacheManager.getInstance();
  cache.setQuote('test_provider', 'BTC/USDT', {
    symbol: 'BTC/USDT',
    bid: 50000,
    ask: 50002,
    last: 50001,
    spread: 2,
    spreadBps: 0.4,
    timestamp: Date.now()
  }, 1000); // 1s TTL

  const hit1 = cache.getQuote('test_provider', 'BTC/USDT');
  const metrics = cache.getMetrics();

  tests.push({
    name: 'Cache Manager returns cached quote and tracks measured hit metrics',
    passed: hit1 !== null && hit1.last === 50001 && metrics.hits > 0,
    error: 'Cache miss on freshly cached quote or metrics untracked'
  });

  return tests;
}
