import * as fs from 'fs';
import * as path from 'path';
import { Position } from '../types/risk.js';
import { config } from '../config/index.js';

export interface PerformanceSummary {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  breakEvenTrades: number;
  winRatePct: number;
  totalRealizedPnl: number;
  profitFactor: number;
  averageR: number;
  expectancyR: number;
  averageHoldingTimeMinutes: number;
  maxDrawdownPct: number;
  totalFeesPaid: number;
}

export class TradeJournal {
  private static instance: TradeJournal;
  private filePath: string;
  private closedPositions: Position[] = [];

  private constructor() {
    this.filePath = path.join(config.paths.dataDir, 'trade_journal.json');
    this.ensureDirectory();
    this.load();
  }

  public static getInstance(): TradeJournal {
    if (!this.instance) {
      this.instance = new TradeJournal();
    }
    return this.instance;
  }

  private ensureDirectory(): void {
    if (!fs.existsSync(config.paths.dataDir)) {
      fs.mkdirSync(config.paths.dataDir, { recursive: true });
    }
  }

  private load(): void {
    try {
      if (fs.existsSync(this.filePath)) {
        const data = fs.readFileSync(this.filePath, 'utf-8');
        this.closedPositions = JSON.parse(data);
      }
    } catch (err) {
      console.error('[TradeJournal] Error loading trade journal:', err);
    }
  }

  private save(): void {
    try {
      this.ensureDirectory();
      const tempPath = `${this.filePath}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(this.closedPositions, null, 2), 'utf-8');
      fs.renameSync(tempPath, this.filePath);
    } catch (err) {
      console.error('[TradeJournal] Error saving trade journal:', err);
    }
  }

  public recordClosedTrade(position: Position): void {
    this.closedPositions.unshift(position);
    this.save();
  }

  public getClosedPositions(): Position[] {
    return [...this.closedPositions];
  }

  public getPerformanceSummary(): PerformanceSummary {
    const totalTrades = this.closedPositions.length;
    if (totalTrades === 0) {
      return {
        totalTrades: 0,
        winningTrades: 0,
        losingTrades: 0,
        breakEvenTrades: 0,
        winRatePct: 0,
        totalRealizedPnl: 0,
        profitFactor: 0,
        averageR: 0,
        expectancyR: 0,
        averageHoldingTimeMinutes: 0,
        maxDrawdownPct: 0,
        totalFeesPaid: 0
      };
    }

    const wins = this.closedPositions.filter(p => p.realizedPnl > 0.0001);
    const losses = this.closedPositions.filter(p => p.realizedPnl < -0.0001);
    const breakEvens = this.closedPositions.filter(p => Math.abs(p.realizedPnl) <= 0.0001);

    const grossProfit = wins.reduce((sum, p) => sum + p.realizedPnl, 0);
    const grossLoss = Math.abs(losses.reduce((sum, p) => sum + p.realizedPnl, 0));
    const totalPnl = this.closedPositions.reduce((sum, p) => sum + p.realizedPnl, 0);
    const totalFees = this.closedPositions.reduce((sum, p) => sum + p.feesPaid, 0);

    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : (grossProfit > 0 ? 10.0 : 1.0);
    const winRatePct = (wins.length / totalTrades) * 100;

    const totalR = this.closedPositions.reduce((sum, p) => {
      const riskPerUnit = Math.abs(p.entryPrice - p.initialStopLoss);
      const r = riskPerUnit > 0 ? p.realizedPnl / (riskPerUnit * p.sizeUnits) : 0;
      return sum + r;
    }, 0);

    const averageR = totalR / totalTrades;
    const expectancyR = averageR;

    const totalDurationMs = this.closedPositions.reduce((sum, p) => sum + ((p.closedAt || Date.now()) - p.openedAt), 0);
    const averageHoldingTimeMinutes = Math.round((totalDurationMs / totalTrades) / 60000);

    return {
      totalTrades,
      winningTrades: wins.length,
      losingTrades: losses.length,
      breakEvenTrades: breakEvens.length,
      winRatePct,
      totalRealizedPnl: totalPnl,
      profitFactor,
      averageR,
      expectancyR,
      averageHoldingTimeMinutes,
      maxDrawdownPct: 0,
      totalFeesPaid: totalFees
    };
  }

  public exportCsv(): string {
    const headers = [
      'ID',
      'Symbol',
      'AssetClass',
      'Direction',
      'Mode',
      'EntryPrice',
      'ExitPrice',
      'Size',
      'RealizedPnL',
      'FeesPaid',
      'ExitReason',
      'MAE',
      'MFE',
      'OpenedAt',
      'ClosedAt'
    ].join(',');

    const rows = this.closedPositions.map(p => [
      p.id,
      p.symbol,
      p.assetClass,
      p.direction,
      p.mode,
      p.entryPrice,
      p.exitPrice || p.currentPrice,
      p.sizeUnits,
      p.realizedPnl.toFixed(4),
      p.feesPaid.toFixed(4),
      p.exitReason || 'UNKNOWN',
      p.mae.toFixed(4),
      p.mfe.toFixed(4),
      new Date(p.openedAt).toISOString(),
      p.closedAt ? new Date(p.closedAt).toISOString() : ''
    ].join(','));

    return [headers, ...rows].join('\n');
  }

  public clear(): void {
    this.closedPositions = [];
    this.save();
  }
}
