import { Instrument } from '../types/market.js';
import { AccountState, PositionSizeResult } from '../types/risk.js';
import { RISK_LIMITS } from '../config/constants.js';

export class PositionSizer {
  /**
   * Calculates safe, risk-controlled position size based on exact stop distance, equity, and leverage.
   */
  public static calculateSize(
    instrument: Instrument,
    entryPrice: number,
    stopLossPrice: number,
    account: AccountState,
    customLeverage?: number
  ): PositionSizeResult {
    const stopDistance = Math.abs(entryPrice - stopLossPrice);
    if (stopDistance <= 0 || entryPrice <= 0) {
      return {
        allowed: false,
        rejectReason: 'Invalid stop distance or entry price (stopDistance <= 0)',
        sizeUnits: 0,
        notionalValue: 0,
        riskAmount: 0,
        riskPct: 0,
        leverage: 1,
        marginRequired: 0,
        estimatedFee: 0,
        estimatedSlippage: 0
      };
    }

    const stopPct = stopDistance / entryPrice;
    const maxRiskPct = RISK_LIMITS.MAX_RISK_PER_TRADE_PCT / 100; // 0.005 (0.5%)
    const targetRiskAmount = account.equity * maxRiskPct;

    // Base position size in units: RiskAmount / StopDistance
    let rawSizeUnits = targetRiskAmount / stopDistance;
    let leverage = customLeverage || 1;

    // Apply lot size quantization
    if (instrument.lotSize > 0) {
      const step = instrument.lotSize;
      rawSizeUnits = Math.floor(rawSizeUnits / step) * step;
      // Round to precision of lot size
      const precision = step.toString().split('.')[1]?.length || 0;
      rawSizeUnits = parseFloat(rawSizeUnits.toFixed(precision));
    }

    const notionalValue = rawSizeUnits * entryPrice;

    // Check minimum notional
    if (notionalValue < instrument.minNotional) {
      // If paper balance is small ($100), adjust to min lot if risk remains under 1.5%
      const minUnits = instrument.lotSize || (instrument.minNotional / entryPrice);
      const adjustedNotional = minUnits * entryPrice;
      const adjustedRisk = minUnits * stopDistance;
      const adjustedRiskPct = (adjustedRisk / account.equity) * 100;

      if (adjustedRiskPct <= 1.5) {
        rawSizeUnits = minUnits;
      } else {
        return {
          allowed: false,
          rejectReason: `Position notional $${notionalValue.toFixed(2)} is below instrument minimum $${instrument.minNotional.toFixed(2)} and min size risk (${adjustedRiskPct.toFixed(2)}%) exceeds risk tolerance.`,
          sizeUnits: 0,
          notionalValue: 0,
          riskAmount: 0,
          riskPct: 0,
          leverage: 1,
          marginRequired: 0,
          estimatedFee: 0,
          estimatedSlippage: 0
        };
      }
    }

    const finalNotional = rawSizeUnits * entryPrice;
    const actualRiskAmount = rawSizeUnits * stopDistance;
    const actualRiskPct = (actualRiskAmount / account.equity) * 100;
    const marginRequired = finalNotional / leverage;

    // Estimate realistic fees and slippage
    const estimatedFee = finalNotional * 0.0005; // 5 bps
    const estimatedSlippage = finalNotional * 0.0002; // 2 bps

    // Check if margin required exceeds available balance
    if (marginRequired > account.balance) {
      return {
        allowed: false,
        rejectReason: `Required margin $${marginRequired.toFixed(2)} exceeds available balance $${account.balance.toFixed(2)}`,
        sizeUnits: 0,
        notionalValue: 0,
        riskAmount: 0,
        riskPct: 0,
        leverage,
        marginRequired,
        estimatedFee,
        estimatedSlippage
      };
    }

    return {
      allowed: true,
      sizeUnits: rawSizeUnits,
      notionalValue: finalNotional,
      riskAmount: actualRiskAmount,
      riskPct: actualRiskPct,
      leverage,
      marginRequired,
      estimatedFee,
      estimatedSlippage
    };
  }
}
