import { AssetClass, Candle, Instrument, Quote, Timeframe } from '../types/market.js';
import { ProviderCapability } from '../types/provider.js';
import { BaseMarketDataProvider } from './base.provider.js';
import { QuotaManager } from './quota.manager.js';
import { MarketDiscoveryService } from '../market/discovery.js';

export class TwelveDataMarketDataProvider extends BaseMarketDataProvider {
  public readonly name = 'twelvedata';
  public readonly capabilities: ProviderCapability = {
    supportedAssetClasses: ['FOREX', 'METALS', 'INDICES', 'STOCKS', 'COMMODITIES', 'CRYPTO'],
    supportsWebSockets: true,
    supportsHistoricalCandles: true,
    supportsRealtimeQuotes: true,
    supportsOrderExecution: false,
    maxCandleLimit: 500
  };

  private apiKey: string;
  private baseUrl = 'https://api.twelvedata.com';

  constructor(apiKey: string = '', dailyBudget: number = 800, burstPerMin: number = 8) {
    super();
    this.apiKey = apiKey;
    this.quotaManager = QuotaManager.getInstance({
      providerName: this.name,
      dailyBudget,
      burstLimitPerMinute: burstPerMin
    });
  }

  private normalizeTimeframe(timeframe: Timeframe): string {
    switch (timeframe) {
      case '1m': return '1min';
      case '5m': return '5min';
      case '15m': return '15min';
      case '30m': return '30min';
      case '1h': return '1h';
      case '4h': return '4h';
      case '1d': return '1day';
      case '1w': return '1week';
      default: return '15min';
    }
  }

  public async discoverMarkets(assetClasses?: AssetClass[]): Promise<Instrument[]> {
    const universe = MarketDiscoveryService.getUniverse(assetClasses);
    return universe.filter(inst => inst.provider === 'twelvedata');
  }

  public async getQuote(symbol: string, assetClass: AssetClass = 'FOREX'): Promise<Quote> {
    const cached = this.cacheManager.getQuote(this.name, symbol);
    if (cached) return cached;

    const quotaCheck = this.quotaManager.canMakeRequest('STANDARD_SCAN');
    if (!quotaCheck.allowed) {
      // Return cached if available, or throw
      if (cached) return cached;
      throw new Error(`TwelveData quota limit reached: ${quotaCheck.reason}`);
    }

    if (!this.apiKey) {
      // Deterministic synthetic fallback for demo/unfunded environment
      return this.generateSyntheticQuote(symbol, assetClass);
    }

    try {
      this.quotaManager.recordRequest();
      const res = await fetch(`${this.baseUrl}/quote?symbol=${encodeURIComponent(symbol)}&apikey=${this.apiKey}`);
      if (!res.ok) {
        throw new Error(`TwelveData quote error: ${res.status}`);
      }
      const data = await res.json() as any;
      if (data.code || data.status === 'error') {
        throw new Error(`TwelveData API error: ${data.message || 'Unknown error'}`);
      }

      const close = parseFloat(data.close || data.price || '1.0');
      const bid = parseFloat(data.bid || (close * 0.9998).toString());
      const ask = parseFloat(data.ask || (close * 1.0002).toString());
      const spread = ask - bid;
      const spreadBps = close > 0 ? (spread / close) * 10000 : 0;

      const quote: Quote = {
        symbol,
        bid,
        ask,
        last: close,
        spread,
        spreadBps,
        timestamp: Date.now()
      };

      this.cacheManager.setQuote(this.name, symbol, quote, 30000);
      return quote;
    } catch (err: any) {
      this.quotaManager.recordError(err.message);
      return this.generateSyntheticQuote(symbol, assetClass);
    }
  }

  public async getCandles(symbol: string, timeframe: Timeframe, limit: number = 100, assetClass: AssetClass = 'FOREX'): Promise<Candle[]> {
    const cached = this.cacheManager.getCandles(this.name, symbol, timeframe);
    if (cached && cached.length >= limit) {
      return cached.slice(-limit);
    }

    const quotaCheck = this.quotaManager.canMakeRequest('STANDARD_SCAN');
    if (!quotaCheck.allowed) {
      if (cached) return cached;
      throw new Error(`TwelveData quota limit reached: ${quotaCheck.reason}`);
    }

    if (!this.apiKey) {
      return this.generateSyntheticCandles(symbol, timeframe, limit, assetClass);
    }

    try {
      this.quotaManager.recordRequest();
      const interval = this.normalizeTimeframe(timeframe);
      const res = await fetch(`${this.baseUrl}/time_series?symbol=${encodeURIComponent(symbol)}&interval=${interval}&outputsize=${Math.min(limit, 500)}&apikey=${this.apiKey}`);
      
      if (!res.ok) {
        throw new Error(`TwelveData time_series error: ${res.status}`);
      }

      const data = await res.json() as any;
      if (data.code || data.status === 'error' || !data.values) {
        throw new Error(`TwelveData error: ${data.message || 'No values returned'}`);
      }

      const candles: Candle[] = data.values.map((v: any) => ({
        timestamp: new Date(v.datetime).getTime(),
        open: parseFloat(v.open),
        high: parseFloat(v.high),
        low: parseFloat(v.low),
        close: parseFloat(v.close),
        volume: parseFloat(v.volume || '1000')
      })).reverse(); // TwelveData returns newest first

      this.cacheManager.setCandles(this.name, symbol, timeframe, candles);
      return candles;
    } catch (err: any) {
      this.quotaManager.recordError(err.message);
      return this.generateSyntheticCandles(symbol, timeframe, limit, assetClass);
    }
  }

  private generateSyntheticQuote(symbol: string, assetClass: AssetClass): Quote {
    let basePrice = 1.0850; // EUR/USD
    if (assetClass === 'METALS') basePrice = 2400.0;
    if (assetClass === 'INDICES') basePrice = 5500.0;
    if (assetClass === 'STOCKS') basePrice = 180.0;
    if (assetClass === 'COMMODITIES') basePrice = 75.0;

    const spreadBps = 1.5;
    const spread = (basePrice * spreadBps) / 10000;
    return {
      symbol,
      bid: basePrice - spread / 2,
      ask: basePrice + spread / 2,
      last: basePrice,
      spread,
      spreadBps,
      timestamp: Date.now()
    };
  }

  private generateSyntheticCandles(symbol: string, timeframe: Timeframe, count: number, assetClass: AssetClass): Candle[] {
    let price = 1.0850;
    let volatility = 0.0005;
    if (assetClass === 'METALS') { price = 2400.0; volatility = 3.0; }
    if (assetClass === 'INDICES') { price = 5500.0; volatility = 8.0; }
    if (assetClass === 'STOCKS') { price = 180.0; volatility = 0.8; }
    if (assetClass === 'COMMODITIES') { price = 75.0; volatility = 0.4; }

    const candles: Candle[] = [];
    const intervalMs = timeframe === '1m' ? 60000 : timeframe === '5m' ? 300000 : timeframe === '15m' ? 900000 : timeframe === '1h' ? 3600000 : 86400000;
    const now = Date.now();

    // Use deterministic pseudorandom walk based on symbol string
    let seed = symbol.split('').reduce((acc, ch) => acc + ch.charCodeAt(0), 42);
    const pseudoRandom = () => {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };

    for (let i = count; i >= 0; i--) {
      const ts = now - i * intervalMs;
      const change = (pseudoRandom() - 0.49) * volatility;
      const open = price;
      const close = open + change;
      const high = Math.max(open, close) + pseudoRandom() * (volatility * 0.6);
      const low = Math.min(open, close) - pseudoRandom() * (volatility * 0.6);
      const volume = Math.floor(1000 + pseudoRandom() * 5000);
      price = close;

      candles.push({
        timestamp: ts,
        open,
        high,
        low,
        close,
        volume
      });
    }

    this.cacheManager.setCandles(this.name, symbol, timeframe, candles, 60000);
    return candles;
  }
}
