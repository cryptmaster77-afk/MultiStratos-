import { AssetClass } from '../types/market.js';
import { AccountState, Position } from '../types/risk.js';
import { RISK_LIMITS } from '../config/constants.js';

export class PortfolioRiskEngine {
  /**
   * Validates portfolio-wide risk capacity, asset class concentration, and correlation limits.
   */
  public static validatePortfolioCapacity(
    candidateAssetClass: AssetClass,
    candidateNotional: number,
    openPositions: Position[],
    account: AccountState
  ): {
    allowed: boolean;
    reason?: string;
  } {
    // 1. Max Concurrent Positions Check
    if (openPositions.length >= RISK_LIMITS.MAX_CONCURRENT_POSITIONS) {
      return {
        allowed: false,
        reason: `Maximum concurrent positions limit (${RISK_LIMITS.MAX_CONCURRENT_POSITIONS}) reached`
      };
    }

    // 2. Max Portfolio Exposure Check (Total Notional / Equity <= 20%)
    const currentTotalExposure = openPositions.reduce((sum, p) => sum + p.notionalValue, 0);
    const newTotalExposure = currentTotalExposure + candidateNotional;
    const newExposurePct = (newTotalExposure / account.equity) * 100;

    if (newExposurePct > RISK_LIMITS.MAX_PORTFOLIO_EXPOSURE_PCT) {
      return {
        allowed: false,
        reason: `Total portfolio exposure (${newExposurePct.toFixed(1)}%) would exceed maximum cap (${RISK_LIMITS.MAX_PORTFOLIO_EXPOSURE_PCT}%)`
      };
    }

    // 3. Asset Class Correlated Exposure Check (Max 10% per asset class)
    const sameClassPositions = openPositions.filter(p => p.assetClass === candidateAssetClass);
    const sameClassExposure = sameClassPositions.reduce((sum, p) => sum + p.notionalValue, 0);
    const newSameClassExposurePct = ((sameClassExposure + candidateNotional) / account.equity) * 100;

    if (newSameClassExposurePct > RISK_LIMITS.MAX_CORRELATED_EXPOSURE_PCT) {
      return {
        allowed: false,
        reason: `Correlated ${candidateAssetClass} exposure (${newSameClassExposurePct.toFixed(1)}%) would exceed asset-class limit (${RISK_LIMITS.MAX_CORRELATED_EXPOSURE_PCT}%)`
      };
    }

    return { allowed: true };
  }
}
