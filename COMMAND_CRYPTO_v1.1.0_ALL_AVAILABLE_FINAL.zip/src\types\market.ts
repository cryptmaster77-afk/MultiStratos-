export type AssetClass = 'CRYPTO' | 'FOREX' | 'METALS' | 'INDICES' | 'STOCKS' | 'COMMODITIES';

export type MarketSession = 'OPEN' | 'CLOSED' | 'PRE_MARKET' | 'POST_MARKET' | 'WEEKEND' | 'HOLIDAY';

export type Timeframe = '1m' | '5m' | '15m' | '30m' | '1h' | '4h' | '1d' | '1w';

export interface Candle {
  timestamp: number; // Unix epoch in ms
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Quote {
  symbol: string;
  bid: number;
  ask: number;
  last: number;
  spread: number;
  spreadBps: number;
  timestamp: number;
}

export interface MarketHours {
  timezone: string;
  is24x7: boolean;
  openUtcHour: number;
  openUtcMinute: number;
  closeUtcHour: number;
  closeUtcMinute: number;
  tradingDays: number[]; // 0 = Sun, 1 = Mon, ..., 6 = Sat
}

export interface Instrument {
  symbol: string;               // Normalized symbol e.g., 'BTC/USDT', 'EUR/USD', 'XAU/USD', 'SPX', 'AAPL', 'USOIL'
  rawSymbol: string;            // Provider native symbol e.g., 'BTCUSDT', 'EUR/USD'
  displayName: string;
  assetClass: AssetClass;
  provider: string;
  exchange?: string;
  baseAsset?: string;
  quoteAsset?: string;
  tickSize: number;
  lotSize: number;
  minNotional: number;
  supportedTimeframes: Timeframe[];
  marketHours: MarketHours;
  sessionStatus: MarketSession;
  dataQuality: 'EXCELLENT' | 'GOOD' | 'DEGRADED' | 'STALE' | 'UNAVAILABLE';
  lastUpdated: number;
  isLiveSupported: boolean;     // Whether live execution is verified for this asset/provider
  notes?: string;
}

export type MarketRegimeType = 
  | 'TRENDING_BULL'
  | 'TRENDING_BEAR'
  | 'RANGING'
  | 'HIGH_VOLATILITY'
  | 'LOW_VOLATILITY'
  | 'EXPANSION'
  | 'CONTRACTION'
  | 'UNCERTAIN';

export interface MarketRegime {
  regime: MarketRegimeType;
  confidence: number;          // 0 - 100
  adx: number;
  atr: number;
  atrPct: number;              // ATR / Price * 100
  volatilityState: 'HIGH' | 'NORMAL' | 'LOW' | 'EXPANDING' | 'COMPRESSING';
  trendStrength: number;       // -100 (Strong Bear) to +100 (Strong Bull)
  description: string;
}
