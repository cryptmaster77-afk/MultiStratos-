import { AssetClass, Candle, Instrument, Quote, Timeframe } from './market.js';

export type ProviderHealthStatus = 'HEALTHY' | 'DEGRADED' | 'RATE_LIMITED' | 'OFFLINE';

export interface ProviderQuotaState {
  providerName: string;
  requestsUsedToday: number;
  dailyBudget: number;
  remainingDailyBudget: number;
  reservedSafetyBuffer: number;
  availableScanBudget: number;
  requestsLastMinute: number;
  burstLimitPerMinute: number;
  lastRequestTimestamp: number;
  totalErrorsToday: number;
  lastError?: string;
  health: ProviderHealthStatus;
}

export interface ProviderCapability {
  supportedAssetClasses: AssetClass[];
  supportsWebSockets: boolean;
  supportsHistoricalCandles: boolean;
  supportsRealtimeQuotes: boolean;
  supportsOrderExecution: boolean;
  maxCandleLimit: number;
}

export interface IMarketDataProvider {
  readonly name: string;
  readonly capabilities: ProviderCapability;
  
  getQuotaState(): ProviderQuotaState;
  checkHealth(): Promise<ProviderHealthStatus>;
  
  discoverMarkets(assetClasses?: AssetClass[]): Promise<Instrument[]>;
  getQuote(symbol: string, assetClass: AssetClass): Promise<Quote>;
  getCandles(symbol: string, timeframe: Timeframe, limit?: number, assetClass?: AssetClass): Promise<Candle[]>;
}
