import * as fs from 'fs';
import * as path from 'path';
import { TradeExperienceRecord } from '../types/memory.js';
import { config } from '../config/index.js';

export class ExperienceStore {
  private static instance: ExperienceStore;
  private filePath: string;
  private records: Map<string, TradeExperienceRecord> = new Map();

  private constructor() {
    this.filePath = path.join(config.paths.memoryDir, 'trade_memory.json');
    this.ensureDirectory();
    this.loadFromDisk();
  }

  public static getInstance(): ExperienceStore {
    if (!this.instance) {
      this.instance = new ExperienceStore();
    }
    return this.instance;
  }

  private ensureDirectory(): void {
    if (!fs.existsSync(config.paths.memoryDir)) {
      fs.mkdirSync(config.paths.memoryDir, { recursive: true });
    }
  }

  private loadFromDisk(): void {
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, 'utf-8');
        const parsed = JSON.parse(raw) as TradeExperienceRecord[];
        this.records.clear();
        for (const record of parsed) {
          this.records.set(record.id, record);
        }
      }
    } catch (err) {
      console.error('[ExperienceStore] Error loading memory file:', err);
    }
  }

  private saveToDisk(): void {
    try {
      this.ensureDirectory();
      const tempPath = `${this.filePath}.tmp`;
      const data = JSON.stringify(Array.from(this.records.values()), null, 2);
      fs.writeFileSync(tempPath, data, 'utf-8');
      fs.renameSync(tempPath, this.filePath);
    } catch (err) {
      console.error('[ExperienceStore] Error saving memory file:', err);
    }
  }

  public recordOpportunity(record: TradeExperienceRecord): void {
    this.records.set(record.id, record);
    this.saveToDisk();
  }

  public updateOutcome(id: string, outcome: Partial<TradeExperienceRecord>): void {
    const existing = this.records.get(id);
    if (existing) {
      const updated: TradeExperienceRecord = {
        ...existing,
        ...outcome,
        outcomePopulated: true
      };
      this.records.set(id, updated);
      this.saveToDisk();
    }
  }

  public getAll(): TradeExperienceRecord[] {
    return Array.from(this.records.values());
  }

  public getCompletedTrades(): TradeExperienceRecord[] {
    return this.getAll().filter(r => r.outcomePopulated && r.realizedR !== undefined);
  }

  public clear(): void {
    this.records.clear();
    this.saveToDisk();
  }
}
