import { AssetClassifier } from '../src/market/classifier.js';

export function testClassification(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];

  const testCases: { symbol: string; provider?: string; expectedClass: string; expectedBase: string }[] = [
    // Crypto (Bybit)
    { symbol: 'BTCUSDT', provider: 'bybit', expectedClass: 'CRYPTO', expectedBase: 'BTC' },
    { symbol: 'ETH/USDT', provider: 'bybit', expectedClass: 'CRYPTO', expectedBase: 'ETH' },
    { symbol: 'SOLUSDC', provider: 'bybit', expectedClass: 'CRYPTO', expectedBase: 'SOL' },
    { symbol: 'DOGEUSDT', provider: 'bybit', expectedClass: 'CRYPTO', expectedBase: 'DOGE' },
    
    // Forex (TwelveData)
    { symbol: 'EUR/USD', provider: 'twelvedata', expectedClass: 'FOREX', expectedBase: 'EUR' },
    { symbol: 'GBP/USD', provider: 'twelvedata', expectedClass: 'FOREX', expectedBase: 'GBP' },
    { symbol: 'USD/JPY', provider: 'twelvedata', expectedClass: 'FOREX', expectedBase: 'USD' },
    { symbol: 'EURGBP', provider: 'twelvedata', expectedClass: 'FOREX', expectedBase: 'EUR' },
    { symbol: 'AUD_CAD', provider: 'twelvedata', expectedClass: 'FOREX', expectedBase: 'AUD' },

    // Metals (TwelveData / Bybit tokenized)
    { symbol: 'XAU/USD', provider: 'twelvedata', expectedClass: 'METALS', expectedBase: 'XAU' },
    { symbol: 'XAGUSD', provider: 'twelvedata', expectedClass: 'METALS', expectedBase: 'XAG' },
    { symbol: 'PAXGUSDT', provider: 'bybit', expectedClass: 'METALS', expectedBase: 'PAXG' },

    // Indices (TwelveData)
    { symbol: 'SPX', provider: 'twelvedata', expectedClass: 'INDICES', expectedBase: 'SPX' },
    { symbol: 'NDX', provider: 'twelvedata', expectedClass: 'INDICES', expectedBase: 'NDX' },
    { symbol: 'DJI', provider: 'twelvedata', expectedClass: 'INDICES', expectedBase: 'DJI' },
    { symbol: 'DAX', provider: 'twelvedata', expectedClass: 'INDICES', expectedBase: 'DAX' },

    // Stocks (TwelveData)
    { symbol: 'AAPL', provider: 'twelvedata', expectedClass: 'STOCKS', expectedBase: 'AAPL' },
    { symbol: 'NVDA', provider: 'twelvedata', expectedClass: 'STOCKS', expectedBase: 'NVDA' },
    { symbol: 'MSFT', provider: 'twelvedata', expectedClass: 'STOCKS', expectedBase: 'MSFT' },
    { symbol: 'TSLA', provider: 'twelvedata', expectedClass: 'STOCKS', expectedBase: 'TSLA' },

    // Commodities (TwelveData)
    { symbol: 'USOIL', provider: 'twelvedata', expectedClass: 'COMMODITIES', expectedBase: 'USOIL' },
    { symbol: 'NATGAS', provider: 'twelvedata', expectedClass: 'COMMODITIES', expectedBase: 'NATGAS' }
  ];

  for (const tc of testCases) {
    const result = AssetClassifier.classify(tc.symbol, tc.provider);
    const passed = result.assetClass === tc.expectedClass && (result.baseAsset === tc.expectedBase || result.normalizedSymbol.startsWith(tc.expectedBase));
    tests.push({
      name: `Classify ${tc.symbol} (${tc.provider}) -> ${tc.expectedClass}`,
      passed,
      error: passed ? undefined : `Expected ${tc.expectedClass} (${tc.expectedBase}), got ${result.assetClass} (${result.baseAsset})`
    });
  }

  return tests;
}
