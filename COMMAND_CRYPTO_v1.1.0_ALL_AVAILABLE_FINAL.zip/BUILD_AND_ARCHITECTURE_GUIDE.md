# MULTI-ASSET INTELLIGENT QUANTITATIVE TRADING COMMAND CENTER
## Architecture, System Documentation & Complete Build Guide

---

## 1. Executive Summary & Engineering Philosophy

The **Multi-Asset Intelligent Quantitative Trading Command Center** is an institutional-grade automated trading engine and real-time dashboard designed for multi-asset market scanning, regime detection, adaptive trade memory, quantitative risk management, and explainable decision routing.

The system is built upon a strict quantitative engineering hierarchy:
**Correctness -> Reliability -> Risk Control -> Persistence -> Explainability -> Efficiency -> Adaptive Intelligence -> Performance**

---

## 2. Core Architectural Pillars

### 2.1 Provider Architecture
* **CRYPTO -> Bybit (V5 API):** Public spot market feeds and private order execution via Bybit V5 endpoints (/v5/market/kline, /v5/market/tickers, /v5/market/instruments-info).
* **TRADITIONAL ASSETS -> Twelve Data:**
  * **FOREX:** Interbank currency pairs (EUR/USD, GBP/USD, USD/JPY, AUD/USD, etc.)
  * **METALS:** Spot precious metals (XAU/USD Gold, XAG/USD Silver, XPT/USD Platinum, XPD/USD Palladium, PAXG/USDT)
  * **INDICES:** Benchmark indices (SPX, NDX, DJI, DAX, FTSE, NIKKEI, CAC, ASX, STOXX, RUT)
  * **STOCKS:** Broad US equities (AAPL, NVDA, MSFT, TSLA, AMZN, GOOGL, META, AMD, etc.)
  * **COMMODITIES:** Energy & agriculture (USOIL, UKOIL, NATGAS, COPPER, WHEAT, CORN, SOYBEAN)
* **Zero Silent Mock Fallback:** When a real provider fails or hits limits, explicit errors are raised rather than silently substituting synthetic data.

### 2.2 Global Market Universe (MARKET_UNIVERSE_MODE=ALL)
* **All Available by Default:** Discovers the full universe across all 6 asset classes (137+ instruments in baseline catalog + live dynamic discovery).
* **Decoupled Architecture:** Full discovery is decoupled from scanning. Quotas and rate limits pace scan frequency and batching without artificially restricting universe size.
* **Fair Rotation:** The scanner processes markets sequentially in round-robin batches, marking unscanned markets as PENDING rather than excluding them.
* **Session Filtering:** Traditional markets check session hours (SessionEngine). Closed or weekend markets are marked SKIPPED_MARKET_CLOSED and consume zero TwelveData API quota.

### 2.3 Quota Management & Safety Reserve Buffer
* **Twelve Data Budget:** Configured for 800 requests/day, 8 requests/min burst limit.
* **Safety Reserve Buffer:** 80 requests/day (10%) are strictly reserved for position monitoring (HIGH_PRIORITY_POSITION). Standard market scans are automatically halted when remaining budget <= 80.
* **Bybit Rate Limiting:** Budgeted for 100,000 requests/day with 600 req/min burst limits.
* **Live Cache Tracking:** Timeframe-aware in-memory cache tracking real-time hit/miss metrics exposed via /api/status.

### 2.4 Autonomous Dual-Cadence Scanner
* **Bybit Crypto Loop:** Runs continuous controlled batch scans (2-4 instruments per batch) with a 1,500ms inter-batch delay via non-blocking setTimeout chains.
* **Twelve Data Extended Loop:** Runs scheduled quota-aware batches at a 30-minute cadence.
* **Position Monitor Loop:** Dedicated 10-second interval tracking open positions and trailing stops.
* **Dual Checkpoint Persistence:** State atomically saved to data/checkpoints/scanner_checkpoint.json.

### 2.5 Multi-Timeframe Strategy & 6-Factor Decision Engine
* **Multi-Timeframe Alignment:** Synthesizes Higher (4h Trend), Medium (1h Structure), and Lower (15m Execution Trigger) timeframes.
* **Market Regime Detection:** Classifies market conditions into Trending Bull, Trending Bear, Ranging, High Volatility, Low Volatility, Expansion, and Contraction.
* **6-Factor Scoring:** Technical Strategy (25%), MTF Alignment (20%), Regime Compatibility (15%), Sentiment Context (15%), Adaptive Memory (15%), Risk/Reward (10%).
* **Decision Types:** TRADE (>= 75), REQUIRE_CONFIRMATION (65-74), WAIT (50-64), REJECT (< 50).

### 2.6 Adaptive Trade Memory & 10D Similarity
* **10-Dimensional Feature Vector:** Normalizes ATR%, RSI, Trend Strength, ADX, MTF Alignment, Regime Code, Volatility Code, Spread BPS, Sentiment, and Direction.
* **Euclidean Distance & Exponential Recency Decay:** Applies 30-day half-life decay weights to historical trade experiences.
* **Failure Suppression:** Suppresses new trades when 3+ consecutive losses occur under identical market regimes.

### 2.7 Quantitative Risk Management & LIVE Gates
* **Paper Initial Balance:** $100.00 starting equity.
* **Position Sizing:** Exact 0.5% risk per trade ($0.50 risk on $100 balance) calculated via ATR stop-loss distance.
* **Portfolio Exposure Cap:** Maximum 20.0% total portfolio exposure across all open positions.
* **Daily Drawdown Halt:** Hard kill-switch triggering emergency halt if daily drawdown reaches 3.0%.
* **7-Point LIVE Execution Gate:** Strict pre-flight checks validating Mode, Daily Drawdown, API Keys, Provider Health, Spread BPS, Max Open Positions, and Exposure.
* **Execution & Trailing Stops:** Automatic trailing stop activation when positions reach >= 1.0R unrealized profit.

---

## 3. Step-by-Step Instructions to Build and Run

### Step 1: Install Dependencies
`ash
npm install
`

### Step 2: Configure Environment (.env)
`ash
cp .env.example .env
`

### Step 3: Build TypeScript Code
`ash
npm run build
`
*(Compiles cleanly with 0 errors to dist/)*

### Step 4: Run Automated Tests
`ash
npm test
`
*(Validates all 61 unit tests across 13 suites with 100% pass rate)*

### Step 5: Start the Command Center
`ash
npm start
`
Open browser at: **http://localhost:3000**