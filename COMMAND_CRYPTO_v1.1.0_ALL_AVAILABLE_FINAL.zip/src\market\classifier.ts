import { AssetClass } from '../types/market.js';

const METALS_LIST = ['XAU', 'XAG', 'XPT', 'XPD', 'GOLD', 'SILVER', 'PLATINUM', 'PALLADIUM'];
const COMMODITIES_LIST = ['USOIL', 'UKOIL', 'BRENT', 'WTI', 'NGAS', 'NATGAS', 'COPPER', 'CORN', 'WHEAT', 'SOYBEAN', 'CL', 'NG'];
const INDICES_LIST = ['SPX', 'SP500', 'NDX', 'NAS100', 'DJI', 'US30', 'RUT', 'RUSSELL2000', 'FTSE', 'UK100', 'DAX', 'GER40', 'NIKKEI', 'JP225', 'CAC', 'CAC40', 'ASX', 'ASX200', 'STOXX', 'STOXX50', 'VIX', 'DXY', 'HSI', 'SMI', 'IBEX'];
const MAJOR_FOREX_CURRENCIES = ['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'NZD'];
const MINOR_FOREX_CURRENCIES = ['SGD', 'HKD', 'NOK', 'SEK', 'TRY', 'ZAR', 'MXN', 'PLN', 'CNH', 'THB', 'INR'];
const ALL_FOREX_CURRENCIES = [...MAJOR_FOREX_CURRENCIES, ...MINOR_FOREX_CURRENCIES];

export class AssetClassifier {
  /**
   * Normalizes a raw symbol into standardized notation and identifies its asset class.
   */
  public static classify(rawSymbol: string, providerHint?: string): {
    normalizedSymbol: string;
    assetClass: AssetClass;
    baseAsset?: string;
    quoteAsset?: string;
    confidence: number;
  } {
    const clean = rawSymbol.trim().toUpperCase().replace(/[\^]/g, '');
    const cleanNoSlash = clean.replace(/[\/\-_:]/g, '');

    // 1. Provider Explicit Clues
    if (providerHint === 'bybit' || clean.includes('USDT') || clean.includes('BUSD') || clean.includes('USDC')) {
      if (cleanNoSlash.endsWith('USDT') || cleanNoSlash.endsWith('BUSD') || cleanNoSlash.endsWith('USDC')) {
        const quote = cleanNoSlash.endsWith('USDT') ? 'USDT' : cleanNoSlash.endsWith('BUSD') ? 'BUSD' : 'USDC';
        const base = cleanNoSlash.substring(0, cleanNoSlash.length - quote.length);
        // Check if base is a metal token (e.g., PAXG)
        if (base === 'PAXG' || base === 'XAUT') {
          return { normalizedSymbol: `${base}/${quote}`, assetClass: 'METALS', baseAsset: base, quoteAsset: quote, confidence: 95 };
        }
        return { normalizedSymbol: `${base}/${quote}`, assetClass: 'CRYPTO', baseAsset: base, quoteAsset: quote, confidence: 95 };
      }
    }

    // 2. Metals Matching
    for (const metal of METALS_LIST) {
      if (clean.startsWith(metal) || cleanNoSlash.startsWith(metal)) {
        let quote = 'USD';
        if (clean.includes('/') || clean.includes('-') || clean.includes('_')) {
          const parts = clean.split(/[\/\-_]/);
          if (parts[1]) quote = parts[1];
        } else if (cleanNoSlash.length > metal.length) {
          quote = cleanNoSlash.substring(metal.length);
        }
        return {
          normalizedSymbol: `${metal}/${quote}`,
          assetClass: 'METALS',
          baseAsset: metal,
          quoteAsset: quote,
          confidence: 99
        };
      }
    }

    // 3. Commodities Matching
    for (const comm of COMMODITIES_LIST) {
      if (clean === comm || cleanNoSlash === comm || clean.startsWith(`${comm}/`) || clean.startsWith(`${comm}_`) || clean.startsWith(`${comm}-`)) {
        return {
          normalizedSymbol: comm,
          assetClass: 'COMMODITIES',
          baseAsset: comm,
          confidence: 95
        };
      }
    }

    // 4. Indices Matching
    for (const idx of INDICES_LIST) {
      if (clean === idx || cleanNoSlash === idx || clean.startsWith(`${idx}:`) || clean.endsWith(`:${idx}`)) {
        return {
          normalizedSymbol: idx,
          assetClass: 'INDICES',
          baseAsset: idx,
          confidence: 95
        };
      }
    }

    // 5. Forex Currency Pairs Matching (e.g., EUR/USD, EURUSD, USD_JPY, GBP-CAD)
    if (clean.includes('/') || clean.includes('_') || clean.includes('-')) {
      const parts = clean.split(/[\/\-_]/);
      if (parts.length === 2 && parts[0].length === 3 && parts[1].length === 3) {
        const base = parts[0];
        const quote = parts[1];
        if (ALL_FOREX_CURRENCIES.includes(base) && ALL_FOREX_CURRENCIES.includes(quote)) {
          return {
            normalizedSymbol: `${base}/${quote}`,
            assetClass: 'FOREX',
            baseAsset: base,
            quoteAsset: quote,
            confidence: 99
          };
        }
      }
    } else if (cleanNoSlash.length === 6) {
      const base = cleanNoSlash.substring(0, 3);
      const quote = cleanNoSlash.substring(3, 6);
      if (ALL_FOREX_CURRENCIES.includes(base) && ALL_FOREX_CURRENCIES.includes(quote)) {
        return {
          normalizedSymbol: `${base}/${quote}`,
          assetClass: 'FOREX',
          baseAsset: base,
          quoteAsset: quote,
          confidence: 95
        };
      }
    }

    // 6. Common Crypto Pairs
    const KNOWN_CRYPTO_BASES = ['BTC', 'ETH', 'SOL', 'BNB', 'XRP', 'ADA', 'DOGE', 'AVAX', 'LINK', 'DOT', 'NEAR', 'SUI', 'APT', 'MATIC', 'POL', 'LTC', 'BCH', 'UNI', 'SHIB', 'PEPE', 'RENDER', 'FET', 'TAO', 'INJ', 'TIA', 'ARB', 'OP'];
    for (const cryptoBase of KNOWN_CRYPTO_BASES) {
      if (clean === cryptoBase || cleanNoSlash.startsWith(cryptoBase)) {
        let quote = 'USDT';
        if (clean.includes('/')) {
          const parts = clean.split('/');
          quote = parts[1] || 'USDT';
        } else if (cleanNoSlash.length > cryptoBase.length) {
          quote = cleanNoSlash.substring(cryptoBase.length);
        }
        return {
          normalizedSymbol: `${cryptoBase}/${quote}`,
          assetClass: 'CRYPTO',
          baseAsset: cryptoBase,
          quoteAsset: quote,
          confidence: 90
        };
      }
    }

    // 7. Equities / Stocks Fallback (1-5 character ticker e.g., AAPL, MSFT, TSLA, NVDA, GOOGL, AMZN)
    if (/^[A-Z]{1,5}$/.test(clean)) {
      return {
        normalizedSymbol: clean,
        assetClass: 'STOCKS',
        baseAsset: clean,
        quoteAsset: 'USD',
        confidence: 80
      };
    }

    // Default fallback
    return {
      normalizedSymbol: clean,
      assetClass: 'CRYPTO',
      baseAsset: clean,
      quoteAsset: 'USD',
      confidence: 50
    };
  }
}
