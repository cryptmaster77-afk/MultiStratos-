import { AssetClass, MarketRegimeType, Timeframe } from './market.js';
import { DecisionAction, SignalDirection, StrategyReasoning } from './strategy.js';
import { PositionExitReason } from './risk.js';

export type OpportunityLifecycleStatus = 
  | 'TRADED'
  | 'REJECTED_BY_SCORE'
  | 'REJECTED_BY_REGIME'
  | 'REJECTED_BY_MEMORY'
  | 'REJECTED_BY_RISK'
  | 'REJECTED_BY_SESSION'
  | 'WAITING_CONFIRMATION'
  | 'INVALIDATED'
  | 'EXPIRED';

export interface TradeExperienceRecord {
  id: string;
  timestamp: number;
  symbol: string;
  assetClass: AssetClass;
  provider: string;
  strategyId: string;
  strategyVersion: string;
  direction: SignalDirection;
  regime: MarketRegimeType;
  session: string;
  timeframe: Timeframe;
  
  // Technical setup snapshot
  strategyScore: number;
  memoryScore: number;
  regimeScore: number;
  sentimentScore: number;
  executionScore: number;
  riskScore: number;
  compositeScore: number;
  
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  plannedRiskReward: number;
  slMethod: 'ATR' | 'STRUCTURE' | 'FIXED_PCT';
  tpMethod: 'FIXED_R' | 'STRUCTURE' | 'TRAILING';
  
  atr: number;
  atrPct: number;
  volume24h?: number;
  spreadBps: number;
  fundingRate?: number;
  sentimentValue?: number;
  
  // Sizing & Decision
  decision: DecisionAction;
  baselineDecision: DecisionAction;
  lifecycleStatus: OpportunityLifecycleStatus;
  positionSize?: number;
  leverage?: number;
  
  // Outcome (Populated once position exits or opportunity expires)
  outcomePopulated: boolean;
  realizedPnl?: number;
  realizedR?: number;
  durationMs?: number;
  exitPrice?: number;
  exitReason?: PositionExitReason;
  mae?: number;
  mfe?: number;
  tpHit?: boolean;
  slHit?: boolean;
  trailingActivated?: boolean;
  autopsySummary?: string;
}

export interface SimilarityMatch {
  record: TradeExperienceRecord;
  similarityScore: number; // 0 - 1.0 (1.0 = identical)
  dimensionBreakdown: {
    strategySimilarity: number;
    regimeSimilarity: number;
    assetClassSimilarity: number;
    volatilitySimilarity: number;
    scoreSimilarity: number;
    sessionSimilarity: number;
    recencyWeight: number;
  };
}

export interface SetupSimilarityResult {
  hasSufficientData: boolean;
  sampleCount: number;
  averageSimilarity: number;
  historicalWinRate: number;      // 0 - 1.0
  historicalExpectancyR: number;   // Expected value in R units
  historicalProfitFactor: number;
  historicalAvgMae: number;
  historicalAvgMfe: number;
  repeatedFailureDetected: boolean;
  failurePatternCount: number;
  recommendedConfidenceMultiplier: number; // e.g. 0.5 for poor history, 1.0 for normal, 1.2 for stellar
  memoryScore: number;             // 0 - 100
  notes: string;
  topMatches: SimilarityMatch[];
}

export interface TradeAutopsy {
  tradeId: string;
  symbol: string;
  strategyId: string;
  outcomeR: number;
  realizedPnl: number;
  holdingTimeMinutes: number;
  exitReason: PositionExitReason;
  
  // Diagnostic evaluations
  wasSetupValidAtEntry: boolean;
  wasRegimeCorrectlyIdentified: boolean;
  wasEntryTimingOptimal: boolean;
  wasSlTooTight: boolean;          // MAE pierced SL then reversed strongly toward TP
  wasTpTooAmbitious: boolean;      // MFE reached > 1.5R but failed before TP
  didTrailingHelp: boolean;
  varianceOrError: 'NORMAL_STATISTICAL_VARIANCE' | 'EXECUTION_SLIPPAGE' | 'REGIME_CHANGE' | 'BAD_TIMING' | 'OVER_LEVERAGED';
  memoryEngineLesson: string;
}
