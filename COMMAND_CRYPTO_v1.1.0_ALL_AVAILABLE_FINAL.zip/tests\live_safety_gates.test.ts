import { LiveGateValidator } from '../src/risk/live.gate.js';
import { MarketDiscoveryService } from '../src/market/discovery.js';
import { AccountState } from '../src/types/risk.js';

export function testLiveSafetyGates(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];
  const inst = MarketDiscoveryService.getUniverse()[0];

  const account: AccountState = {
    mode: 'PAPER',
    currency: 'USD',
    initialBalance: 100,
    balance: 100,
    equity: 100,
    unrealizedPnl: 0,
    realizedPnl: 0,
    dailyStartingEquity: 100,
    dailyRealizedPnl: 0,
    dailyUnrealizedPnl: 0,
    dailyDrawdownPct: 0,
    maxDrawdownPct: 0,
    openPositionsCount: 0,
    totalExposure: 0,
    totalExposurePct: 0,
    emergencyStop: false,
    lastUpdated: Date.now()
  };

  // 1. In default PAPER mode, LIVE gates must fail with Gate 1 message
  const result = LiveGateValidator.validate(inst, account);
  tests.push({
    name: 'Live Gate safely blocks live execution when SYSTEM_MODE is PAPER',
    passed: result.isPassed === false && result.rejectionReasons.some(r => r.includes('Gate 1 Failed')),
    error: `Live Gate did not reject paper mode: isPassed=${result.isPassed}`
  });

  // 2. Emergency stop active must fail Gate 6
  const armedAccount = { ...account, emergencyStop: true };
  const armResult = LiveGateValidator.validate(inst, armedAccount);
  tests.push({
    name: 'Live Gate blocks live execution when Emergency Stop is ARMED',
    passed: armResult.isPassed === false && armResult.rejectionReasons.some(r => r.includes('Gate 6 Failed')),
    error: 'Emergency stop check did not reject'
  });

  // 3. Daily loss exceeded must fail Gate 5
  const ddAccount = { ...account, dailyDrawdownPct: 6.0 };
  const ddResult = LiveGateValidator.validate(inst, ddAccount);
  tests.push({
    name: 'Live Gate blocks live execution when Daily Drawdown exceeds kill threshold',
    passed: ddResult.isPassed === false && ddResult.rejectionReasons.some(r => r.includes('Gate 5 Failed')),
    error: 'Drawdown limit check did not reject'
  });

  return tests;
}
