import { IncomingMessage, ServerResponse } from 'http';
import * as url from 'url';
import { RiskManager } from '../risk/risk.manager.js';
import { PositionManager } from '../execution/position.manager.js';
import { PersistentScanner } from '../scanner/persistent.scanner.js';
import { AutopilotEngine } from '../scanner/autopilot.js';
import { TradeJournal } from '../execution/journal.js';
import { ExperienceStore } from '../memory/experience.store.js';
import { BaselineTracker } from '../decision/baseline.tracker.js';
import { LearningVersionManager } from '../learning/version.manager.js';
import { ProviderRegistry } from '../providers/provider.registry.js';
import { MarketDiscoveryService } from '../market/discovery.js';
import { SSEManager } from './sse.manager.js';
import { config } from '../config/index.js';

export class ApiRouter {
  private static riskManager = RiskManager.getInstance();
  private static positionManager = PositionManager.getInstance();
  private static scanner = PersistentScanner.getInstance();
  private static autopilot = AutopilotEngine.getInstance();
  private static journal = TradeJournal.getInstance();
  private static experienceStore = ExperienceStore.getInstance();
  private static learningVersionManager = LearningVersionManager.getInstance();
  private static providerRegistry = ProviderRegistry.getInstance();
  private static sseManager = SSEManager.getInstance();

  private static parseJsonBody(req: IncomingMessage): Promise<any> {
    return new Promise((resolve) => {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', () => {
        try {
          resolve(body ? JSON.parse(body) : {});
        } catch {
          resolve({});
        }
      });
    });
  }

  private static sendJson(res: ServerResponse, statusCode: number, data: any): void {
    res.writeHead(statusCode, {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end(JSON.stringify(data));
  }

  public static async handleRequest(req: IncomingMessage, res: ServerResponse): Promise<boolean> {
    const parsedUrl = url.parse(req.url || '', true);
    const pathname = parsedUrl.pathname || '';
    const method = req.method || 'GET';

    if (method === 'OPTIONS') {
      res.writeHead(200, {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
      });
      res.end();
      return true;
    }

    // SSE Stream Endpoint
    if (pathname === '/api/events') {
      this.sseManager.addClient(res);
      return true;
    }

    // Status endpoint
    if (pathname === '/api/status' && method === 'GET') {
      this.sendJson(res, 200, {
        mode: config.systemMode,
        account: this.riskManager.getAccountState(),
        scanner: this.scanner.getState(),
        autopilot: this.autopilot.getStatus(),
        quotas: this.providerRegistry.getAllQuotaStates(),
        openPositionsCount: this.positionManager.getOpenPositions().length,
        timestamp: Date.now()
      });
      return true;
    }

    // Scanner Opportunities
    if (pathname === '/api/scanner/opportunities' && method === 'GET') {
      this.sendJson(res, 200, {
        opportunities: this.scanner.getOpportunities(),
        state: this.scanner.getState()
      });
      return true;
    }

    // Manual Scan Trigger
    if (pathname === '/api/scanner/scan' && method === 'POST') {
      const result = await this.scanner.scanNextBatch();
      this.sseManager.broadcast('SCAN_UPDATE', { scanner: this.scanner.getState() });
      this.sendJson(res, 200, { success: true, ...result });
      return true;
    }

    // Universe Breakdown & All Available Discovery
    if (pathname === '/api/universe' && method === 'GET') {
      const state = this.scanner.getState();
      const allInstruments = MarketDiscoveryService.getUniverse();
      this.sendJson(res, 200, {
        universeMode: config.scanner.universeMode === 'CUSTOM' ? 'CUSTOM' : 'ALL AVAILABLE',
        breakdown: state.universeBreakdown,
        totalInstruments: allInstruments.length,
        instruments: allInstruments
      });
      return true;
    }

    // Dynamic Discovery Trigger
    if (pathname === '/api/universe/discover' && method === 'POST') {
      try {
        const bybitProvider = this.providerRegistry.getProvider('bybit');
        const discovered = await bybitProvider.discoverMarkets();
        MarketDiscoveryService.updateDiscoveredUniverse(discovered);
        this.scanner.resetAllUniverses();
        this.sseManager.broadcast('SCAN_UPDATE', { scanner: this.scanner.getState() });
        this.sendJson(res, 200, {
          success: true,
          message: `Discovered ${discovered.length} live markets from Bybit`,
          state: this.scanner.getState()
        });
      } catch (err: any) {
        this.sendJson(res, 500, { success: false, error: err.message });
      }
      return true;
    }

    // Positions Endpoints
    if (pathname === '/api/positions' && method === 'GET') {
      this.sendJson(res, 200, { positions: this.positionManager.getOpenPositions() });
      return true;
    }

    if (pathname.startsWith('/api/positions/') && pathname.endsWith('/close') && method === 'POST') {
      const posId = pathname.replace('/api/positions/', '').replace('/close', '');
      const pos = this.positionManager.getPosition(posId);
      if (pos) {
        const closed = this.positionManager.closePosition(posId, pos.currentPrice, 'MANUAL_CLOSE');
        this.sendJson(res, 200, { success: true, position: closed });
      } else {
        this.sendJson(res, 404, { success: false, error: 'Position not found' });
      }
      return true;
    }

    if (pathname === '/api/positions/close-all' && method === 'POST') {
      this.positionManager.closeAllPositions('MANUAL_CLOSE');
      this.sendJson(res, 200, { success: true });
      return true;
    }

    // Journal & Analytics
    if (pathname === '/api/journal' && method === 'GET') {
      this.sendJson(res, 200, {
        closedPositions: this.journal.getClosedPositions(),
        performance: this.journal.getPerformanceSummary(),
        baselineComparison: BaselineTracker.compare()
      });
      return true;
    }

    if (pathname === '/api/journal/export' && method === 'GET') {
      const csv = this.journal.exportCsv();
      res.writeHead(200, {
        'Content-Type': 'text/csv',
        'Content-Disposition': 'attachment; filename="trade_journal.csv"',
        'Access-Control-Allow-Origin': '*'
      });
      res.end(csv);
      return true;
    }

    // Autopilot Controls
    if (pathname === '/api/autopilot/start' && method === 'POST') {
      this.autopilot.start();
      this.sendJson(res, 200, { success: true, autopilot: this.autopilot.getStatus() });
      return true;
    }

    if (pathname === '/api/autopilot/stop' && method === 'POST') {
      this.autopilot.stop();
      this.sendJson(res, 200, { success: true, autopilot: this.autopilot.getStatus() });
      return true;
    }

    // Emergency Stop
    if (pathname === '/api/risk/emergency-stop' && method === 'POST') {
      const body = await this.parseJsonBody(req);
      const arm = body.arm !== false;
      this.riskManager.triggerEmergencyStop(arm);
      if (arm) {
        this.positionManager.closeAllPositions('EMERGENCY_STOP');
      }
      this.sendJson(res, 200, { success: true, emergencyStop: arm });
      return true;
    }

    // Reset Paper Account
    if (pathname === '/api/risk/reset-paper' && method === 'POST') {
      this.riskManager.resetPaperAccount(100.0);
      this.positionManager.closeAllPositions('MANUAL_CLOSE');
      this.sendJson(res, 200, { success: true, account: this.riskManager.getAccountState() });
      return true;
    }

    // Learning Versions
    if (pathname === '/api/learning/versions' && method === 'GET') {
      this.sendJson(res, 200, {
        versions: this.learningVersionManager.getAllVersions(),
        baselineComparison: BaselineTracker.compare()
      });
      return true;
    }

    return false;
  }
}
