import { Candle, Timeframe } from '../types/market.js';
import { TechnicalIndicators } from './indicators.js';

export interface MTFAnalysisResult {
  symbol: string;
  higherTimeframe: {
    timeframe: Timeframe;
    trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    ema50: number;
    ema200: number;
    rsi: number;
    adx: number;
  };
  mediumTimeframe: {
    timeframe: Timeframe;
    structure: 'BREAKOUT' | 'PULLBACK' | 'RANGE' | 'EXPANSION' | 'CONSOLIDATION';
    bbPercentB: number;
    macdHistogram: number;
    rsi: number;
    recentSwingHigh: number;
    recentSwingLow: number;
  };
  lowerTimeframe: {
    timeframe: Timeframe;
    trigger: 'CONFIRMED' | 'PENDING' | 'INVALIDATED';
    lastClose: number;
    ema9: number;
    ema21: number;
    rsi: number;
    volumeMultiplier: number;
  };
  alignmentScore: number; // 0 - 100
  overallBias: 'STRONG_BULL' | 'BULL' | 'NEUTRAL' | 'BEAR' | 'STRONG_BEAR';
}

export class MultiTimeframeAnalyzer {
  /**
   * Synthesizes Higher Timeframe Trend, Medium Timeframe Structure, and Lower Timeframe Trigger.
   */
  public static analyze(
    symbol: string,
    higherCandles: Candle[],
    mediumCandles: Candle[],
    lowerCandles: Candle[],
    htfName: Timeframe = '4h',
    mtfName: Timeframe = '1h',
    ltfName: Timeframe = '15m'
  ): MTFAnalysisResult {
    // 1. Higher Timeframe Analysis (Trend)
    const hCloses = higherCandles.map(c => c.close);
    const fastPeriod = Math.min(20, Math.max(5, Math.floor(hCloses.length * 0.3)));
    const slowPeriod = Math.min(50, Math.max(10, Math.floor(hCloses.length * 0.7)));
    const hEma50 = TechnicalIndicators.ema(hCloses, fastPeriod);
    const hEma200 = TechnicalIndicators.ema(hCloses, slowPeriod);
    const hRsi = TechnicalIndicators.rsi(hCloses, 14);
    const { adx: hAdx } = TechnicalIndicators.adx(higherCandles, 14);

    const lastHCloses = hCloses[hCloses.length - 1];
    const lastHEma50 = hEma50[hEma50.length - 1] || lastHCloses;
    const lastHEma200 = hEma200[hEma200.length - 1] || lastHCloses;
    const lastHRsi = hRsi[hRsi.length - 1] || 50;
    const lastHAdx = hAdx[hAdx.length - 1] || 20;

    let higherTrend: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
    if (lastHCloses > lastHEma50 && lastHEma50 >= lastHEma200) {
      higherTrend = 'BULLISH';
    } else if (lastHCloses < lastHEma50 && lastHEma50 <= lastHEma200) {
      higherTrend = 'BEARISH';
    } else if (lastHCloses > lastHEma200 && lastHRsi > 55) {
      higherTrend = 'BULLISH';
    } else if (lastHCloses < lastHEma200 && lastHRsi < 45) {
      higherTrend = 'BEARISH';
    }

    // 2. Medium Timeframe Analysis (Market Structure)
    const mCloses = mediumCandles.map(c => c.close);
    const mRsi = TechnicalIndicators.rsi(mCloses, 14);
    const mBb = TechnicalIndicators.bollingerBands(mCloses, 20, 2.0);
    const mMacd = TechnicalIndicators.macd(mCloses, 12, 26, 9);

    const lastMRsi = mRsi[mRsi.length - 1] || 50;
    const lastMPctB = mBb.percentB[mBb.percentB.length - 1] || 0.5;
    const lastMMacdHist = mMacd.histogram[mMacd.histogram.length - 1] || 0;

    // Find swing high/low in last 20 medium candles
    const recentMCandles = mediumCandles.slice(-20);
    const recentSwingHigh = Math.max(...recentMCandles.map(c => c.high));
    const recentSwingLow = Math.min(...recentMCandles.map(c => c.low));

    let mediumStructure: 'BREAKOUT' | 'PULLBACK' | 'RANGE' | 'EXPANSION' | 'CONSOLIDATION' = 'RANGE';
    if (lastMPctB > 1.0) {
      mediumStructure = 'BREAKOUT';
    } else if (lastMPctB < 0.0) {
      mediumStructure = 'BREAKOUT';
    } else if (higherTrend === 'BULLISH' && lastMRsi >= 40 && lastMRsi <= 55) {
      mediumStructure = 'PULLBACK';
    } else if (higherTrend === 'BEARISH' && lastMRsi >= 45 && lastMRsi <= 60) {
      mediumStructure = 'PULLBACK';
    } else if (mBb.bandwidth[mBb.bandwidth.length - 1] < 1.8) {
      mediumStructure = 'CONSOLIDATION';
    }

    // 3. Lower Timeframe Analysis (Trigger / Execution Confirmation)
    const lCloses = lowerCandles.map(c => c.close);
    const lEma9 = TechnicalIndicators.ema(lCloses, 9);
    const lEma21 = TechnicalIndicators.ema(lCloses, 21);
    const lRsi = TechnicalIndicators.rsi(lCloses, 14);
    const lVolumes = lowerCandles.map(c => c.volume);
    const avgVol = TechnicalIndicators.sma(lVolumes, 20);

    const lastLClose = lCloses[lCloses.length - 1];
    const lastLEma9 = lEma9[lEma9.length - 1] || lastLClose;
    const lastLEma21 = lEma21[lEma21.length - 1] || lastLClose;
    const lastLRsi = lRsi[lRsi.length - 1] || 50;
    const lastVol = lVolumes[lVolumes.length - 1] || 1;
    const lastAvgVol = avgVol[avgVol.length - 1] || lastVol;
    const volumeMultiplier = lastAvgVol > 0 ? lastVol / lastAvgVol : 1.0;

    let lowerTrigger: 'CONFIRMED' | 'PENDING' | 'INVALIDATED' = 'PENDING';
    if (higherTrend === 'BULLISH' && lastLEma9 > lastLEma21 && lastLRsi > 50 && volumeMultiplier >= 0.8) {
      lowerTrigger = 'CONFIRMED';
    } else if (higherTrend === 'BEARISH' && lastLEma9 < lastLEma21 && lastLRsi < 50 && volumeMultiplier >= 0.8) {
      lowerTrigger = 'CONFIRMED';
    } else if ((higherTrend === 'BULLISH' && lastLRsi < 35) || (higherTrend === 'BEARISH' && lastLRsi > 65)) {
      lowerTrigger = 'INVALIDATED';
    }

    // 4. Alignment Scoring
    let alignmentScore = 50;
    if (higherTrend === 'BULLISH') {
      alignmentScore += 20;
      if (mediumStructure === 'PULLBACK' || mediumStructure === 'BREAKOUT') alignmentScore += 15;
      if (lowerTrigger === 'CONFIRMED') alignmentScore += 15;
    } else if (higherTrend === 'BEARISH') {
      alignmentScore += 20;
      if (mediumStructure === 'PULLBACK' || mediumStructure === 'BREAKOUT') alignmentScore += 15;
      if (lowerTrigger === 'CONFIRMED') alignmentScore += 15;
    }
    alignmentScore = Math.min(100, Math.max(0, alignmentScore));

    let overallBias: 'STRONG_BULL' | 'BULL' | 'NEUTRAL' | 'BEAR' | 'STRONG_BEAR' = 'NEUTRAL';
    if (higherTrend === 'BULLISH' && lowerTrigger === 'CONFIRMED') {
      overallBias = alignmentScore >= 85 ? 'STRONG_BULL' : 'BULL';
    } else if (higherTrend === 'BEARISH' && lowerTrigger === 'CONFIRMED') {
      overallBias = alignmentScore >= 85 ? 'STRONG_BEAR' : 'BEAR';
    }

    return {
      symbol,
      higherTimeframe: {
        timeframe: htfName,
        trend: higherTrend,
        ema50: lastHEma50,
        ema200: lastHEma200,
        rsi: lastHRsi,
        adx: lastHAdx
      },
      mediumTimeframe: {
        timeframe: mtfName,
        structure: mediumStructure,
        bbPercentB: lastMPctB,
        macdHistogram: lastMMacdHist,
        rsi: lastMRsi,
        recentSwingHigh,
        recentSwingLow
      },
      lowerTimeframe: {
        timeframe: ltfName,
        trigger: lowerTrigger,
        lastClose: lastLClose,
        ema9: lastLEma9,
        ema21: lastLEma21,
        rsi: lastLRsi,
        volumeMultiplier
      },
      alignmentScore,
      overallBias
    };
  }
}
