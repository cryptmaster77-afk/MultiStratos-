import { Instrument } from '../types/market.js';
import { AccountState, LiveGateValidation } from '../types/risk.js';
import { config } from '../config/index.js';

export class LiveGateValidator {
  /**
   * Verifies all mandatory safety gates before any live order can be transmitted.
   * If any single gate fails, live execution is refused with explicit diagnostic reasons.
   */
  public static validate(instrument: Instrument, account: AccountState): LiveGateValidation {
    const rejectionReasons: string[] = [];

    // Gate 1: Explicit System Mode Check
    const systemModeLive = config.systemMode === 'LIVE';
    if (!systemModeLive) {
      rejectionReasons.push('Gate 1 Failed: SYSTEM_MODE is configured as PAPER. Live orders are blocked.');
    }

    // Gate 2: Explicit Safety Acknowledgement & Confirmation
    const acknowledgementVerified = config.liveGates.acknowledged === true;
    if (!acknowledgementVerified) {
      rejectionReasons.push('Gate 2 Failed: LIVE_SAFETY_ACKNOWLEDGED is not set to true in environment.');
    }

    // Gate 3: Live API Credentials Verification
    let credentialsPresent = false;
    if (instrument.assetClass === 'CRYPTO') {
      credentialsPresent = Boolean(config.providers.bybit.apiKey && config.providers.bybit.apiSecret);
    } else {
      credentialsPresent = Boolean(config.providers.twelvedata.apiKey);
    }
    if (!credentialsPresent) {
      rejectionReasons.push(`Gate 3 Failed: Missing required live API credentials for ${instrument.assetClass} provider (${instrument.provider}).`);
    }

    // Gate 4: Account Funding & Positive Equity Check
    const accountFunded = account.equity > 0 && account.balance > 0;
    if (!accountFunded) {
      rejectionReasons.push(`Gate 4 Failed: Account equity is non-positive ($${account.equity.toFixed(2)}).`);
    }

    // Gate 5: Daily Loss & Drawdown Safety Gate
    const dailyLossWithinLimit = account.dailyDrawdownPct < config.liveGates.maxDrawdownKillPct;
    if (!dailyLossWithinLimit) {
      rejectionReasons.push(`Gate 5 Failed: Daily drawdown (${account.dailyDrawdownPct.toFixed(2)}%) exceeds kill threshold (${config.liveGates.maxDrawdownKillPct}%).`);
    }

    // Gate 6: Emergency Stop Gate
    const emergencyStopDisarmed = !account.emergencyStop;
    if (!emergencyStopDisarmed) {
      rejectionReasons.push('Gate 6 Failed: Emergency Stop switch is currently ARMED.');
    }

    // Gate 7: Venue & Asset Class Live Execution Support Gate
    const venueSupported = instrument.isLiveSupported;
    if (!venueSupported) {
      rejectionReasons.push(`Gate 7 Failed: Live execution is not yet configured for asset class ${instrument.assetClass} (Paper-only mode enabled for safety).`);
    }

    const isPassed = rejectionReasons.length === 0;

    return {
      isPassed,
      gates: {
        systemModeLive,
        acknowledgementVerified,
        credentialsPresent,
        accountFunded,
        dailyLossWithinLimit,
        emergencyStopDisarmed,
        venueSupported
      },
      rejectionReasons
    };
  }
}
