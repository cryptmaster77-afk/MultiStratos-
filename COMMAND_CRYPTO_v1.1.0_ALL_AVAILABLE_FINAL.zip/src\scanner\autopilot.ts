import { PersistentScanner } from './persistent.scanner.js';
import { PositionManager } from '../execution/position.manager.js';
import { ProviderRegistry } from '../providers/provider.registry.js';
import { ExecutionEngine } from '../execution/execution.engine.js';
import { config } from '../config/index.js';

export class AutopilotEngine {
  private static instance: AutopilotEngine;
  private scanner = PersistentScanner.getInstance();
  private positionManager = PositionManager.getInstance();
  private providerRegistry = ProviderRegistry.getInstance();
  private executionEngine = ExecutionEngine.getInstance();
  
  private isRunning: boolean = false;
  private cryptoScanTimer: NodeJS.Timeout | null = null;
  private extendedScanTimer: NodeJS.Timeout | null = null;
  private positionMonitorTimer: NodeJS.Timeout | null = null;

  private constructor() {}

  public static getInstance(): AutopilotEngine {
    if (!this.instance) {
      this.instance = new AutopilotEngine();
    }
    return this.instance;
  }

  public start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    console.log('[AutopilotEngine] Dual-Cadence Autopilot started.');

    // 1. Position Monitor Loop: High-frequency continuous monitor (every 10 seconds)
    this.positionMonitorTimer = setInterval(() => {
      this.monitorActivePositions().catch(err => {
        console.error('[AutopilotEngine] Position monitor error:', err);
      });
    }, 10000);

    // 2. Crypto Scanning Channel: Continuous controlled Bybit scanning
    this.runContinuousCryptoLoop();

    // 3. Extended Assets Scanning Channel: Scheduled quota-aware Twelve Data scanning
    this.runScheduledExtendedLoop();
  }

  public stop(): void {
    this.isRunning = false;
    if (this.cryptoScanTimer) clearTimeout(this.cryptoScanTimer);
    if (this.extendedScanTimer) clearTimeout(this.extendedScanTimer);
    if (this.positionMonitorTimer) clearInterval(this.positionMonitorTimer);
    console.log('[AutopilotEngine] Autopilot stopped.');
  }

  public getStatus(): { isRunning: boolean; scannerState: any } {
    return {
      isRunning: this.isRunning,
      scannerState: this.scanner.getState()
    };
  }

  /**
   * Continuous Controlled Bybit Crypto Loop:
   * Bybit Batch -> controlled delay -> next batch -> delay -> loop seamlessly
   */
  private runContinuousCryptoLoop(): void {
    if (!this.isRunning) return;

    this.cryptoScanTimer = setTimeout(async () => {
      if (!this.isRunning) return;
      try {
        const result = await this.scanner.scanCryptoBatch();
        
        // Auto-execute qualified PAPER trades if decision is TRADE
        for (const opp of result.newOpportunities) {
          if (opp.decision === 'TRADE') {
            const inst = this.scanner.getState().crypto.universe.find(u => u.symbol === opp.symbol);
            if (inst) {
              const quote = await this.providerRegistry.getQuote(inst.symbol, inst.assetClass, inst.provider);
              await this.executionEngine.executeOpportunity(opp, inst, quote);
            }
          }
        }
      } catch (err: any) {
        console.error('[AutopilotEngine] Crypto scan error:', err.message);
      }

      // Schedule next controlled batch
      this.runContinuousCryptoLoop();
    }, config.scanner.cryptoBatchDelayMs || 1500);
  }

  /**
   * Scheduled Quota-Aware Twelve Data Extended Assets Loop:
   * Runs at scheduled interval (e.g., every 30 minutes), checks quota safety reserve & session hours
   */
  private runScheduledExtendedLoop(): void {
    if (!this.isRunning) return;

    const intervalMs = (config.scanner.extendedIntervalMinutes || 30) * 60 * 1000;
    this.extendedScanTimer = setTimeout(async () => {
      if (!this.isRunning) return;
      try {
        console.log('[AutopilotEngine] Triggering scheduled TwelveData extended assets scan...');
        const result = await this.scanner.scanExtendedBatch();
        
        for (const opp of result.newOpportunities) {
          if (opp.decision === 'TRADE') {
            const inst = this.scanner.getState().extended.universe.find(u => u.symbol === opp.symbol);
            if (inst) {
              const quote = await this.providerRegistry.getQuote(inst.symbol, inst.assetClass, inst.provider);
              await this.executionEngine.executeOpportunity(opp, inst, quote);
            }
          }
        }
      } catch (err: any) {
        console.error('[AutopilotEngine] Extended assets scan error:', err.message);
      }

      this.runScheduledExtendedLoop();
    }, intervalMs);
  }

  private async monitorActivePositions(): Promise<void> {
    const openPositions = this.positionManager.getOpenPositions();
    for (const pos of openPositions) {
      try {
        const quote = await this.providerRegistry.getQuote(pos.symbol, pos.assetClass, pos.provider);
        this.positionManager.updatePrice(pos.id, quote);
      } catch (err) {
        // Continue monitoring remaining positions
      }
    }
  }
}
