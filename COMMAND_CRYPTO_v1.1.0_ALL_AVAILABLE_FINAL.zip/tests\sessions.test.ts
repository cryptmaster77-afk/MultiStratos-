import { SessionEngine } from '../src/market/session.engine.js';

export function testSessions(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];

  // 1. Crypto 24/7 test
  const cryptoSession = SessionEngine.getSessionStatus('CRYPTO');
  tests.push({
    name: 'Crypto 24/7 Session is ALWAYS OPEN',
    passed: cryptoSession.isOpen === true && cryptoSession.status === 'OPEN',
    error: cryptoSession.isOpen ? undefined : 'Crypto session failed to evaluate as OPEN'
  });

  // 2. Forex Weekend vs Weekday test
  // Saturday 12:00 UTC (e.g. 2026-09-19 is Saturday)
  const saturdayTs = Date.UTC(2026, 8, 19, 12, 0, 0);
  const forexSatSession = SessionEngine.getSessionStatus('FOREX', undefined, saturdayTs);
  tests.push({
    name: 'Forex Saturday is CLOSED / WEEKEND',
    passed: forexSatSession.isOpen === false && (forexSatSession.status === 'WEEKEND' || forexSatSession.status === 'CLOSED'),
    error: forexSatSession.isOpen ? 'Forex showed open on Saturday' : undefined
  });

  // Wednesday 14:00 UTC
  const wednesdayTs = Date.UTC(2026, 8, 16, 14, 0, 0);
  const forexWedSession = SessionEngine.getSessionStatus('FOREX', undefined, wednesdayTs);
  tests.push({
    name: 'Forex Wednesday 14:00 UTC is OPEN',
    passed: forexWedSession.isOpen === true && forexWedSession.status === 'OPEN',
    error: !forexWedSession.isOpen ? 'Forex showed closed on Wednesday midday' : undefined
  });

  // 3. US Equities Regular vs Pre-Market
  // Wednesday 15:00 UTC (11:00 AM EST) -> OPEN
  const stockOpenTs = Date.UTC(2026, 8, 16, 15, 0, 0);
  const stockOpenSession = SessionEngine.getSessionStatus('STOCKS', undefined, stockOpenTs);
  tests.push({
    name: 'US Equities Wednesday 15:00 UTC is OPEN',
    passed: stockOpenSession.isOpen === true && stockOpenSession.status === 'OPEN',
    error: !stockOpenSession.isOpen ? 'Equities showed closed during regular US hours' : undefined
  });

  // Wednesday 10:00 UTC (06:00 AM EST) -> PRE_MARKET
  const stockPreTs = Date.UTC(2026, 8, 16, 10, 0, 0);
  const stockPreSession = SessionEngine.getSessionStatus('STOCKS', undefined, stockPreTs);
  tests.push({
    name: 'US Equities Wednesday 10:00 UTC is PRE_MARKET',
    passed: stockPreSession.isPreMarket === true && stockPreSession.status === 'PRE_MARKET',
    error: !stockPreSession.isPreMarket ? `Equities failed pre-market check: status was ${stockPreSession.status}` : undefined
  });

  return tests;
}
