import { DecisionAction, MultiFactorScore, QualifiedOpportunity, StrategyReasoning } from '../types/strategy.js';
import { SetupSimilarityResult } from '../types/memory.js';
import { SentimentSnapshot } from '../sentiment/sentiment.types.js';
import { AccountState } from '../types/risk.js';
import { Instrument } from '../types/market.js';
import { DECISION_THRESHOLDS, RISK_LIMITS } from '../config/constants.js';

export class DecisionEngine {
  /**
   * Synthesizes strategy technical setup, historical memory, regime, and risk constraints to form an explainable decision.
   */
  public static evaluateDecision(
    instrument: Instrument,
    reasoning: StrategyReasoning,
    scores: MultiFactorScore,
    similarity: SetupSimilarityResult,
    sentiment: SentimentSnapshot,
    account: AccountState
  ): {
    decision: DecisionAction;
    decisionReason: string;
    baselineDecision: DecisionAction;
    isAdaptiveModified: boolean;
  } {
    // 1. Hard Market & Risk Gates
    if (instrument.sessionStatus !== 'OPEN') {
      return {
        decision: 'REJECT',
        decisionReason: `Market session is currently ${instrument.sessionStatus} (${instrument.notes || 'Closed'})`,
        baselineDecision: 'REJECT',
        isAdaptiveModified: false
      };
    }

    if (account.emergencyStop) {
      return {
        decision: 'REJECT',
        decisionReason: 'Emergency Stop is active on account',
        baselineDecision: 'REJECT',
        isAdaptiveModified: false
      };
    }

    if (account.dailyDrawdownPct >= RISK_LIMITS.MAX_DAILY_LOSS_PCT) {
      return {
        decision: 'REJECT',
        decisionReason: `Daily loss limit reached (${account.dailyDrawdownPct.toFixed(2)}% >= ${RISK_LIMITS.MAX_DAILY_LOSS_PCT}%)`,
        baselineDecision: 'REJECT',
        isAdaptiveModified: false
      };
    }

    if (reasoning.direction === 'NEUTRAL' || reasoning.setupQuality === 'INVALID') {
      return {
        decision: 'REJECT',
        decisionReason: `Technical setup invalid or direction neutral (${reasoning.conditionsFailed.map(c => c.name).join(', ')})`,
        baselineDecision: 'REJECT',
        isAdaptiveModified: false
      };
    }

    if (reasoning.riskReward < RISK_LIMITS.MIN_RR_RATIO) {
      return {
        decision: 'REJECT',
        decisionReason: `Risk-to-reward ratio ${reasoning.riskReward.toFixed(2)} is below minimum required 1:${RISK_LIMITS.MIN_RR_RATIO}`,
        baselineDecision: 'REJECT',
        isAdaptiveModified: false
      };
    }

    // 2. Baseline Decision (Raw strategy + risk, without memory/sentiment)
    let baselineDecision: DecisionAction = 'REJECT';
    if (reasoning.technicalScore >= DECISION_THRESHOLDS.TRADE_MIN_STRATEGY && scores.riskScore >= 50) {
      baselineDecision = 'TRADE';
    } else if (reasoning.technicalScore >= 60) {
      baselineDecision = 'WAIT';
    }

    // 3. Adaptive Layer Decisions
    // A. Repeated failure pattern suppression
    if (similarity.repeatedFailureDetected) {
      return {
        decision: 'WAIT',
        decisionReason: `Technical setup qualifies (Score: ${reasoning.technicalScore}), but adaptive memory detected ${similarity.failurePatternCount} consecutive historical failures under ${reasoning.regimeCompatibility.currentRegime} regime. Waiting for confirmation.`,
        baselineDecision,
        isAdaptiveModified: baselineDecision === 'TRADE'
      };
    }

    // B. Negative historical expectancy under same conditions
    if (similarity.hasSufficientData && similarity.historicalExpectancyR < -0.2) {
      return {
        decision: 'REDUCE_CONFIDENCE',
        decisionReason: `Similar setups historically underperformed (${similarity.historicalWinRate * 100}% win rate, Expectancy: ${similarity.historicalExpectancyR.toFixed(2)}R). Confidence reduced.`,
        baselineDecision,
        isAdaptiveModified: true
      };
    }

    // C. Strategy & Composite Qualification
    if (scores.compositeScore >= DECISION_THRESHOLDS.TRADE_MIN_COMPOSITE && scores.strategyScore >= DECISION_THRESHOLDS.TRADE_MIN_STRATEGY) {
      return {
        decision: 'TRADE',
        decisionReason: `All conditions verified: Technical score ${scores.strategyScore}/100, Composite ${scores.compositeScore}/100, Regime ${reasoning.regimeCompatibility.currentRegime} optimal, Risk score ${scores.riskScore}/100.`,
        baselineDecision,
        isAdaptiveModified: baselineDecision !== 'TRADE'
      };
    }

    if (scores.strategyScore >= DECISION_THRESHOLDS.CONFIRMATION_MIN_STRATEGY && scores.compositeScore >= 65) {
      return {
        decision: 'REQUIRE_CONFIRMATION',
        decisionReason: `Strong technical setup (${scores.strategyScore}/100), but composite score (${scores.compositeScore}/100) indicates pending LTF confirmation or moderate regime alignment.`,
        baselineDecision,
        isAdaptiveModified: baselineDecision === 'TRADE'
      };
    }

    return {
      decision: 'WAIT',
      decisionReason: `Setup is consolidating (Technical Score: ${scores.strategyScore}/100, Composite: ${scores.compositeScore}/100). Waiting for higher conviction trigger.`,
      baselineDecision,
      isAdaptiveModified: false
    };
  }
}
