import { AssetClass, Candle, Instrument, Quote, Timeframe } from '../types/market.js';
import { IMarketDataProvider, ProviderHealthStatus, ProviderQuotaState } from '../types/provider.js';
import { BybitMarketDataProvider } from './bybit.provider.js';
import { TwelveDataMarketDataProvider } from './twelvedata.provider.js';
import { MockMarketDataProvider } from './mock.provider.js';
import { config } from '../config/index.js';
import { QuotaManager } from './quota.manager.js';

export class ProviderRegistry {
  private static instance: ProviderRegistry;
  private providers = new Map<string, IMarketDataProvider>();

  private constructor() {
    this.registerDefaults();
  }

  public static getInstance(): ProviderRegistry {
    if (!this.instance) {
      this.instance = new ProviderRegistry();
    }
    return this.instance;
  }

  private registerDefaults(): void {
    const bybit = new BybitMarketDataProvider(config.providers.bybit.apiKey, config.providers.bybit.apiSecret);
    const twelvedata = new TwelveDataMarketDataProvider(
      config.providers.twelvedata.apiKey,
      config.providers.twelvedata.dailyBudget,
      config.providers.twelvedata.burstPerMinute
    );
    const mock = new MockMarketDataProvider();

    this.providers.set('bybit', bybit);
    this.providers.set('twelvedata', twelvedata);
    this.providers.set('mock', mock);
  }

  public getProvider(name: string): IMarketDataProvider {
    const p = this.providers.get(name);
    if (!p) {
      throw new Error(`Provider ${name} not found in registry.`);
    }
    return p;
  }

  public getProviderForAsset(assetClass: AssetClass): IMarketDataProvider {
    if (assetClass === 'CRYPTO') {
      return this.providers.get('bybit')!;
    }
    return this.providers.get('twelvedata')!;
  }

  public async getQuote(symbol: string, assetClass: AssetClass, preferredProvider?: string): Promise<Quote> {
    const primary = preferredProvider ? this.getProvider(preferredProvider) : this.getProviderForAsset(assetClass);
    // Directly invoke provider without silently falling back to synthetic mock data
    return await primary.getQuote(symbol, assetClass);
  }

  public async getCandles(symbol: string, timeframe: Timeframe, limit: number = 100, assetClass: AssetClass, preferredProvider?: string): Promise<Candle[]> {
    const primary = preferredProvider ? this.getProvider(preferredProvider) : this.getProviderForAsset(assetClass);
    // Directly invoke provider without silently falling back to synthetic mock data
    return await primary.getCandles(symbol, timeframe, limit, assetClass);
  }

  public getAllQuotaStates(): ProviderQuotaState[] {
    return QuotaManager.getAllStates();
  }
}
