import { ExperienceStore } from '../memory/experience.store.js';

export interface BaselineComparisonMetrics {
  totalOpportunities: number;
  baselineTradesCount: number;
  adaptiveTradesCount: number;
  avoidedBadTradesCount: number;  // Baseline took it, Adaptive avoided it, and it resulted in loss
  missedGoodTradesCount: number;   // Baseline took it, Adaptive avoided it, but it resulted in win
  adaptiveWinRatePct: number;
  baselineWinRatePct: number;
  adaptiveExpectancyR: number;
  baselineExpectancyR: number;
  valueAddR: number;               // (Adaptive R - Baseline R)
  recommendation: string;
}

export class BaselineTracker {
  public static compare(): BaselineComparisonMetrics {
    const store = ExperienceStore.getInstance();
    const records = store.getCompletedTrades();

    if (records.length === 0) {
      return {
        totalOpportunities: 0,
        baselineTradesCount: 0,
        adaptiveTradesCount: 0,
        avoidedBadTradesCount: 0,
        missedGoodTradesCount: 0,
        adaptiveWinRatePct: 0,
        baselineWinRatePct: 0,
        adaptiveExpectancyR: 0,
        baselineExpectancyR: 0,
        valueAddR: 0,
        recommendation: 'Accumulating paper trade outcomes for statistically robust comparison'
      };
    }

    let baselineWins = 0;
    let baselineLosses = 0;
    let baselineRTotal = 0;
    let baselineCount = 0;

    let adaptiveWins = 0;
    let adaptiveLosses = 0;
    let adaptiveRTotal = 0;
    let adaptiveCount = 0;

    let avoidedBadTrades = 0;
    let missedGoodTrades = 0;

    for (const rec of records) {
      const isWin = (rec.realizedR || 0) > 0;
      const rVal = rec.realizedR || 0;

      // Check what baseline would have done
      if (rec.baselineDecision === 'TRADE') {
        baselineCount++;
        baselineRTotal += rVal;
        if (isWin) baselineWins++;
        else baselineLosses++;
      }

      // Check what adaptive did
      if (rec.decision === 'TRADE') {
        adaptiveCount++;
        adaptiveRTotal += rVal;
        if (isWin) adaptiveWins++;
        else adaptiveLosses++;
      }

      // Check Divergence
      if (rec.baselineDecision === 'TRADE' && rec.decision !== 'TRADE') {
        if (!isWin) avoidedBadTrades++;
        else missedGoodTrades++;
      }
    }

    const baselineWinRate = baselineCount > 0 ? (baselineWins / baselineCount) * 100 : 0;
    const adaptiveWinRate = adaptiveCount > 0 ? (adaptiveWins / adaptiveCount) * 100 : 0;
    const baselineExpR = baselineCount > 0 ? baselineRTotal / baselineCount : 0;
    const adaptiveExpR = adaptiveCount > 0 ? adaptiveRTotal / adaptiveCount : 0;
    const valueAddR = adaptiveRTotal - baselineRTotal;

    let recommendation = 'Adaptive memory actively filtering false breakouts and bad regimes.';
    if (valueAddR > 0) {
      recommendation = `Adaptive intelligence outperforms baseline by +${valueAddR.toFixed(2)}R. Avoided ${avoidedBadTrades} bad trades.`;
    } else if (valueAddR < 0) {
      recommendation = 'Adaptive filtering was overly conservative on recent wins. Recommend tuning similarity threshold.';
    }

    return {
      totalOpportunities: records.length,
      baselineTradesCount: baselineCount,
      adaptiveTradesCount: adaptiveCount,
      avoidedBadTradesCount: avoidedBadTrades,
      missedGoodTradesCount: missedGoodTrades,
      adaptiveWinRatePct: adaptiveWinRate,
      baselineWinRatePct: baselineWinRate,
      adaptiveExpectancyR: adaptiveExpR,
      baselineExpectancyR: baselineExpR,
      valueAddR,
      recommendation
    };
  }
}
