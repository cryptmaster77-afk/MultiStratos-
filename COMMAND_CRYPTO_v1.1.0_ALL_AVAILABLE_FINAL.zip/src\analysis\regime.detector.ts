import { Candle, MarketRegime, MarketRegimeType } from '../types/market.js';
import { TechnicalIndicators } from './indicators.js';

export class RegimeDetector {
  /**
   * Detects the market regime using ADX, ATR, Bollinger Bandwidth, and EMA trend slope.
   */
  public static detect(candles: Candle[]): MarketRegime {
    if (candles.length < 30) {
      return {
        regime: 'UNCERTAIN',
        confidence: 50,
        adx: 20,
        atr: 0,
        atrPct: 0,
        volatilityState: 'NORMAL',
        trendStrength: 0,
        description: 'Insufficient candle data for reliable regime detection'
      };
    }

    const closes = candles.map(c => c.close);
    const lastClose = closes[closes.length - 1];

    // Compute indicators
    const atrSeries = TechnicalIndicators.atr(candles, 14);
    const currentAtr = atrSeries[atrSeries.length - 1] || (lastClose * 0.01);
    const atrPct = (currentAtr / lastClose) * 100;

    const { adx, plusDi, minusDi } = TechnicalIndicators.adx(candles, 14);
    const currentAdx = adx[adx.length - 1] || 20;
    const currentPlusDi = plusDi[plusDi.length - 1] || 20;
    const currentMinusDi = minusDi[minusDi.length - 1] || 20;

    const ema20 = TechnicalIndicators.ema(closes, 20);
    const ema50 = TechnicalIndicators.ema(closes, 50);
    const currentEma20 = ema20[ema20.length - 1];
    const currentEma50 = ema50[ema50.length - 1];

    const bb = TechnicalIndicators.bollingerBands(closes, 20, 2.0);
    const currentBw = bb.bandwidth[bb.bandwidth.length - 1] || 2.0;
    const prevBw = bb.bandwidth[bb.bandwidth.length - 5] || currentBw;

    // Volatility State
    let volatilityState: 'HIGH' | 'NORMAL' | 'LOW' | 'EXPANDING' | 'COMPRESSING' = 'NORMAL';
    if (currentBw > prevBw * 1.35) {
      volatilityState = 'EXPANDING';
    } else if (currentBw < prevBw * 0.75) {
      volatilityState = 'COMPRESSING';
    } else if (atrPct > 3.0) {
      volatilityState = 'HIGH';
    } else if (atrPct < 0.5) {
      volatilityState = 'LOW';
    }

    // Trend Direction & Strength (-100 to +100)
    let trendStrength = 0;
    const emaSlope = currentEma20 > currentEma50 ? 1 : -1;
    const priceVsEma20 = (lastClose - currentEma20) / currentEma20 * 100;
    
    if (currentAdx > 25) {
      trendStrength = (currentPlusDi > currentMinusDi ? 1 : -1) * Math.min(100, currentAdx * 2);
    } else {
      trendStrength = priceVsEma20 * 10;
    }
    trendStrength = Math.max(-100, Math.min(100, trendStrength));

    // Determine Regime
    let regime: MarketRegimeType = 'UNCERTAIN';
    let confidence = 70;
    let description = '';

    if (currentAdx >= 28 && currentPlusDi > currentMinusDi && lastClose > currentEma20) {
      regime = 'TRENDING_BULL';
      confidence = Math.min(95, 60 + currentAdx);
      description = `Strong Bullish Trend (ADX: ${currentAdx.toFixed(1)}, +DI: ${currentPlusDi.toFixed(1)})`;
    } else if (currentAdx >= 28 && currentMinusDi > currentPlusDi && lastClose < currentEma20) {
      regime = 'TRENDING_BEAR';
      confidence = Math.min(95, 60 + currentAdx);
      description = `Strong Bearish Trend (ADX: ${currentAdx.toFixed(1)}, -DI: ${currentMinusDi.toFixed(1)})`;
    } else if (volatilityState === 'EXPANDING' && currentBw > 4.0) {
      regime = 'EXPANSION';
      confidence = 80;
      description = `Volatility Expansion Breakout (Bandwidth: ${currentBw.toFixed(2)}%)`;
    } else if (volatilityState === 'COMPRESSING' || currentBw < 1.5) {
      regime = 'CONTRACTION';
      confidence = 85;
      description = `Squeeze / Contraction Consolidation (Bandwidth: ${currentBw.toFixed(2)}%)`;
    } else if (currentAdx < 20) {
      regime = 'RANGING';
      confidence = 75;
      description = `Mean-Reverting Range Market (ADX: ${currentAdx.toFixed(1)})`;
    } else if (atrPct > 4.0) {
      regime = 'HIGH_VOLATILITY';
      confidence = 75;
      description = `High Volatility Environment (ATR: ${atrPct.toFixed(2)}%)`;
    } else if (atrPct < 0.4) {
      regime = 'LOW_VOLATILITY';
      confidence = 80;
      description = `Low Volatility / Quiet Market (ATR: ${atrPct.toFixed(2)}%)`;
    } else {
      regime = 'RANGING';
      confidence = 65;
      description = 'Transitional Sideways Market';
    }

    return {
      regime,
      confidence,
      adx: currentAdx,
      atr: currentAtr,
      atrPct,
      volatilityState,
      trendStrength,
      description
    };
  }
}
