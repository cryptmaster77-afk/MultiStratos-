import { AssetClass, Candle, Instrument, Quote, Timeframe } from '../types/market.js';
import { IMarketDataProvider, ProviderCapability, ProviderHealthStatus, ProviderQuotaState } from '../types/provider.js';
import { QuotaManager } from './quota.manager.js';
import { CacheManager } from './cache.manager.js';

export abstract class BaseMarketDataProvider implements IMarketDataProvider {
  public abstract readonly name: string;
  public abstract readonly capabilities: ProviderCapability;
  protected quotaManager!: QuotaManager;
  protected cacheManager = CacheManager.getInstance();

  public getQuotaState(): ProviderQuotaState {
    return this.quotaManager.getState();
  }

  public async checkHealth(): Promise<ProviderHealthStatus> {
    return this.getQuotaState().health;
  }

  public abstract discoverMarkets(assetClasses?: AssetClass[]): Promise<Instrument[]>;
  public abstract getQuote(symbol: string, assetClass: AssetClass): Promise<Quote>;
  public abstract getCandles(symbol: string, timeframe: Timeframe, limit?: number, assetClass?: AssetClass): Promise<Candle[]>;
}
