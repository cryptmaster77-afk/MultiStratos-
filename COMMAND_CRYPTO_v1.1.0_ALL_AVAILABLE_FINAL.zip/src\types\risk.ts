import { AssetClass } from './market.js';
import { SignalDirection } from './strategy.js';

export interface AccountState {
  mode: 'PAPER' | 'LIVE';
  currency: string;
  initialBalance: number;
  balance: number;
  equity: number;
  unrealizedPnl: number;
  realizedPnl: number;
  dailyStartingEquity: number;
  dailyRealizedPnl: number;
  dailyUnrealizedPnl: number;
  dailyDrawdownPct: number;
  maxDrawdownPct: number;
  openPositionsCount: number;
  totalExposure: number;
  totalExposurePct: number;
  emergencyStop: boolean;
  lastUpdated: number;
}

export interface PositionSizeResult {
  allowed: boolean;
  rejectReason?: string;
  sizeUnits: number;
  notionalValue: number;
  riskAmount: number;
  riskPct: number;
  leverage: number;
  marginRequired: number;
  estimatedFee: number;
  estimatedSlippage: number;
}

export interface LiveGateValidation {
  isPassed: boolean;
  gates: {
    systemModeLive: boolean;
    acknowledgementVerified: boolean;
    credentialsPresent: boolean;
    accountFunded: boolean;
    dailyLossWithinLimit: boolean;
    emergencyStopDisarmed: boolean;
    venueSupported: boolean;
  };
  rejectionReasons: string[];
}

export interface Position {
  id: string;
  symbol: string;
  assetClass: AssetClass;
  provider: string;
  direction: SignalDirection;
  mode: 'PAPER' | 'LIVE';
  status: 'OPEN' | 'CLOSED' | 'CLOSING';
  
  // Pricing & sizing
  entryPrice: number;
  currentPrice: number;
  stopLoss: number;
  initialStopLoss: number;
  takeProfit: number;
  takeProfit2?: number;
  sizeUnits: number;
  notionalValue: number;
  leverage: number;
  margin: number;
  
  // P&L & R-metrics
  unrealizedPnl: number;
  unrealizedPnlPct: number;
  unrealizedR: number;
  realizedPnl: number;
  feesPaid: number;
  
  // Trailing Stop state
  trailingStopActive: boolean;
  trailingActivationPrice?: number;
  trailingDistance?: number;
  highestPriceSinceEntry: number;
  lowestPriceSinceEntry: number;
  mae: number;                         // Maximum Adverse Excursion ($ or R)
  mfe: number;                         // Maximum Favorable Excursion ($ or R)
  
  // Metadata
  strategyId: string;
  strategyVersion: string;
  opportunityId: string;
  openedAt: number;
  closedAt?: number;
  exitPrice?: number;
  exitReason?: PositionExitReason;
}

export type PositionExitReason = 
  | 'TAKE_PROFIT'
  | 'TAKE_PROFIT_2'
  | 'STOP_LOSS'
  | 'TRAILING_STOP'
  | 'STRATEGY_INVALIDATION'
  | 'EMERGENCY_STOP'
  | 'DAILY_LOSS_LIMIT'
  | 'SESSION_CLOSE'
  | 'MANUAL_CLOSE'
  | 'PROVIDER_TIMEOUT';
