import { RegimeDetector } from '../src/analysis/regime.detector.js';
import { StrategyRouter } from '../src/strategies/strategy.router.js';
import { MarketDiscoveryService } from '../src/market/discovery.js';
import { MultiTimeframeAnalyzer } from '../src/analysis/mtf.analyzer.js';
import { Candle } from '../src/types/market.js';

export function testRegimeAndStrategies(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];

  // Generate synthetic trending candles
  const trendingCandles: Candle[] = [];
  let p = 100;
  for (let i = 0; i < 60; i++) {
    p += 1.5;
    trendingCandles.push({
      timestamp: i * 60000,
      open: p - 0.5,
      high: p + 1.0,
      low: p - 1.0,
      close: p,
      volume: 2000
    });
  }

  // 1. Regime Detection
  const regime = RegimeDetector.detect(trendingCandles);
  tests.push({
    name: 'Regime Detector identifies trending market',
    passed: regime.regime === 'TRENDING_BULL' || regime.trendStrength > 50,
    error: `Expected TRENDING_BULL or strong trend, got ${regime.regime} (${regime.trendStrength})`
  });

  // 2. MTF Analyzer
  const inst = MarketDiscoveryService.getUniverse()[0];
  const mtf = MultiTimeframeAnalyzer.analyze(inst.symbol, trendingCandles, trendingCandles, trendingCandles);
  tests.push({
    name: 'MTF Analyzer produces bullish bias on uptrend',
    passed: mtf.higherTimeframe.trend === 'BULLISH',
    error: `Expected HTF BULLISH, got ${mtf.higherTimeframe.trend}`
  });

  // 3. Strategy Router Evaluation
  const router = StrategyRouter.getInstance();
  const evalResult = router.evaluateAll(inst, trendingCandles, regime, mtf);
  tests.push({
    name: 'Strategy returns structured reasoning with entry, SL, TP',
    passed: evalResult.bestReasoning.suggestedEntry > 0 &&
            evalResult.bestReasoning.stopLoss > 0 &&
            evalResult.bestReasoning.takeProfit > 0 &&
            evalResult.bestReasoning.riskReward >= 1.5,
    error: `Strategy invalid parameters: Entry=${evalResult.bestReasoning.suggestedEntry}, SL=${evalResult.bestReasoning.stopLoss}, TP=${evalResult.bestReasoning.takeProfit}`
  });

  tests.push({
    name: 'Strategy includes conditions satisfied/failed arrays',
    passed: Array.isArray(evalResult.bestReasoning.conditionsSatisfied) &&
            Array.isArray(evalResult.bestReasoning.conditionsFailed) &&
            evalResult.bestReasoning.conditionsSatisfied.length > 0,
    error: 'Strategy did not expose structured condition arrays'
  });

  return tests;
}
