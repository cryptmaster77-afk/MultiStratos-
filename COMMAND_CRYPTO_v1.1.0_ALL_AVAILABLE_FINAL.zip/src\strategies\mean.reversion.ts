import { Candle, Instrument, MarketRegime } from '../types/market.js';
import { MTFAnalysisResult } from '../analysis/mtf.analyzer.js';
import { StrategyCondition, StrategyReasoning } from '../types/strategy.js';
import { IStrategy } from './base.strategy.js';
import { TechnicalIndicators } from '../analysis/indicators.js';

export class MeanReversionStrategy implements IStrategy {
  public readonly id = 'STRAT_MEAN_REVERSION';
  public readonly name = 'Bollinger & RSI Mean Reversion';
  public readonly version = '1.1.0';
  public readonly description = 'Fades extreme deviations in ranging and low-volatility market regimes back to the mean';

  public evaluate(
    instrument: Instrument,
    candles: Candle[],
    regime: MarketRegime,
    mtf: MTFAnalysisResult
  ): StrategyReasoning {
    const closes = candles.map(c => c.close);
    const lastClose = closes[closes.length - 1];
    const atrSeries = TechnicalIndicators.atr(candles, 14);
    const atr = atrSeries[atrSeries.length - 1] || (lastClose * 0.01);

    const bb = TechnicalIndicators.bollingerBands(closes, 20, 2.0);
    const rsiSeries = TechnicalIndicators.rsi(closes, 14);
    const lastRsi = rsiSeries[rsiSeries.length - 1] || 50;
    const lastPctB = bb.percentB[bb.percentB.length - 1] || 0.5;
    const middleBand = bb.middle[bb.middle.length - 1] || lastClose;
    const lowerBand = bb.lower[bb.lower.length - 1] || lastClose * 0.98;
    const upperBand = bb.upper[bb.upper.length - 1] || lastClose * 1.02;

    const conditionsSatisfied: StrategyCondition[] = [];
    const conditionsFailed: StrategyCondition[] = [];

    // Condition 1: Regime Compatibility (Must be RANGING or LOW_VOLATILITY)
    const isRangingRegime = regime.regime === 'RANGING' || regime.regime === 'LOW_VOLATILITY' || regime.regime === 'CONTRACTION';
    if (isRangingRegime) {
      conditionsSatisfied.push({
        name: 'Market Regime Suitable',
        expected: 'RANGING or LOW_VOLATILITY',
        actual: regime.regime,
        satisfied: true,
        weight: 35
      });
    } else {
      conditionsFailed.push({
        name: 'Market Regime Suitable',
        expected: 'RANGING or LOW_VOLATILITY',
        actual: regime.regime,
        satisfied: false,
        weight: 35
      });
    }

    // Condition 2: Statistical Extremity (Oversold or Overbought)
    const isOversold = lastPctB <= 0.05 && lastRsi <= 35;
    const isOverbought = lastPctB >= 0.95 && lastRsi >= 65;

    if (isOversold || isOverbought) {
      conditionsSatisfied.push({
        name: 'Statistical Price Extremity',
        expected: '%B <= 0.05 or >= 0.95 with RSI exhaustion',
        actual: `%B: ${(lastPctB * 100).toFixed(1)}%, RSI: ${lastRsi.toFixed(1)}`,
        satisfied: true,
        weight: 35
      });
    } else {
      conditionsFailed.push({
        name: 'Statistical Price Extremity',
        expected: '%B <= 0.05 or >= 0.95 with RSI exhaustion',
        actual: `%B: ${(lastPctB * 100).toFixed(1)}%, RSI: ${lastRsi.toFixed(1)}`,
        satisfied: false,
        weight: 35
      });
    }

    // Condition 3: ADX Non-Trending
    const isNonTrending = regime.adx < 25;
    if (isNonTrending) {
      conditionsSatisfied.push({
        name: 'ADX Non-Trending State',
        expected: 'ADX < 25',
        actual: `ADX: ${regime.adx.toFixed(1)}`,
        satisfied: true,
        weight: 30
      });
    } else {
      conditionsFailed.push({
        name: 'ADX Non-Trending State',
        expected: 'ADX < 25',
        actual: `ADX: ${regime.adx.toFixed(1)}`,
        satisfied: false,
        weight: 30
      });
    }

    const direction = isOversold ? 'BUY' : isOverbought ? 'SELL' : 'NEUTRAL';
    const stopDistance = atr * 1.2;
    const targetDistance = Math.abs(lastClose - middleBand);

    const stopLoss = direction === 'BUY' ? lastClose - stopDistance : direction === 'SELL' ? lastClose + stopDistance : lastClose * 0.98;
    const takeProfit = middleBand;
    const invalidationPrice = direction === 'BUY' ? lowerBand - atr * 0.5 : upperBand + atr * 0.5;
    const riskReward = stopDistance > 0 ? targetDistance / stopDistance : 1.5;

    const totalWeightSatisfied = conditionsSatisfied.reduce((acc, c) => acc + c.weight, 0);
    const technicalScore = Math.min(100, Math.max(0, totalWeightSatisfied));

    let setupQuality: 'A+' | 'A' | 'B' | 'C' | 'INVALID' = 'INVALID';
    if (technicalScore >= 90) setupQuality = 'A+';
    else if (technicalScore >= 70) setupQuality = 'A';
    else if (technicalScore >= 50) setupQuality = 'B';
    else if (technicalScore >= 30) setupQuality = 'C';

    const regimeCompatibilityScore = isRangingRegime ? 95 : 20;

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      direction,
      setupQuality,
      technicalScore,
      conditionsSatisfied,
      conditionsFailed,
      suggestedEntry: lastClose,
      stopLoss,
      takeProfit,
      invalidationPrice,
      riskReward,
      timeframeContext: {
        higherTrend: mtf.higherTimeframe.trend,
        mediumStructure: mtf.mediumTimeframe.structure,
        lowerTrigger: mtf.lowerTimeframe.trigger
      },
      regimeCompatibility: {
        currentRegime: regime.regime,
        isCompatible: isRangingRegime,
        compatibilityScore: regimeCompatibilityScore,
        notes: isRangingRegime ? 'Favorable range/mean-reversion conditions' : 'Trending market hazard for mean-reversion'
      }
    };
  }
}
