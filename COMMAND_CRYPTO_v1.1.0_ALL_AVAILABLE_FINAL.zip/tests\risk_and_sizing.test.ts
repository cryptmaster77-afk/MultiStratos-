import { PositionSizer } from '../src/risk/position.sizer.js';
import { PortfolioRiskEngine } from '../src/risk/portfolio.risk.js';
import { MarketDiscoveryService } from '../src/market/discovery.js';
import { AccountState, Position } from '../src/types/risk.js';

export function testRiskAndSizing(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];
  const inst = MarketDiscoveryService.getUniverse().find(u => u.symbol === 'BTC/USDT')!;

  const account: AccountState = {
    mode: 'PAPER',
    currency: 'USD',
    initialBalance: 100,
    balance: 100,
    equity: 100,
    unrealizedPnl: 0,
    realizedPnl: 0,
    dailyStartingEquity: 100,
    dailyRealizedPnl: 0,
    dailyUnrealizedPnl: 0,
    dailyDrawdownPct: 0,
    maxDrawdownPct: 0,
    openPositionsCount: 0,
    totalExposure: 0,
    totalExposurePct: 0,
    emergencyStop: false,
    lastUpdated: Date.now()
  };

  // 1. Position Sizing
  // Entry: $60,000, SL: $59,000 (Distance: $1,000)
  // Max Risk: 0.5% of $100 = $0.50
  // Target units: $0.50 / $1,000 = 0.0005 BTC ($30 notional)
  const sizeResult = PositionSizer.calculateSize(inst, 60000, 59000, account, 1);
  tests.push({
    name: 'Position sizer enforces exact 0.5% risk limit',
    passed: sizeResult.allowed === true && sizeResult.riskAmount <= 0.60 && sizeResult.sizeUnits > 0,
    error: `Sizing error: allowed=${sizeResult.allowed}, risk=$${sizeResult.riskAmount}, units=${sizeResult.sizeUnits}`
  });

  // 2. Portfolio Exposure Cap Check (Max 20%)
  const mockPositions: Position[] = [
    {
      id: 'POS_1',
      symbol: 'ETH/USDT',
      assetClass: 'CRYPTO',
      provider: 'bybit',
      direction: 'BUY',
      mode: 'PAPER',
      status: 'OPEN',
      entryPrice: 3000,
      currentPrice: 3000,
      stopLoss: 2950,
      initialStopLoss: 2950,
      takeProfit: 3150,
      sizeUnits: 0.006,
      notionalValue: 18, // 18% of $100 equity
      leverage: 1,
      margin: 18,
      unrealizedPnl: 0,
      unrealizedPnlPct: 0,
      unrealizedR: 0,
      realizedPnl: 0,
      feesPaid: 0.01,
      trailingStopActive: false,
      highestPriceSinceEntry: 3000,
      lowestPriceSinceEntry: 3000,
      mae: 0,
      mfe: 0,
      strategyId: 'STRAT_TREND_FOLLOWING',
      strategyVersion: '1.2.0',
      opportunityId: 'OPP_1',
      openedAt: Date.now()
    }
  ];

  const overLimitCheck = PortfolioRiskEngine.validatePortfolioCapacity('CRYPTO', 10, mockPositions, account);
  tests.push({
    name: 'Portfolio risk engine blocks new trades exceeding 20% exposure cap',
    passed: overLimitCheck.allowed === false && overLimitCheck.reason?.includes('Total portfolio exposure'),
    error: `Expected rejection for 28% exposure, got allowed=${overLimitCheck.allowed}`
  });

  return tests;
}
