import { AssetClass, Candle, Instrument, Quote, Timeframe } from '../types/market.js';
import { ProviderCapability } from '../types/provider.js';
import { BaseMarketDataProvider } from './base.provider.js';
import { QuotaManager } from './quota.manager.js';
import { MarketDiscoveryService } from '../market/discovery.js';

export class MockMarketDataProvider extends BaseMarketDataProvider {
  public readonly name = 'mock';
  public readonly capabilities: ProviderCapability = {
    supportedAssetClasses: ['CRYPTO', 'FOREX', 'METALS', 'INDICES', 'STOCKS', 'COMMODITIES'],
    supportsWebSockets: true,
    supportsHistoricalCandles: true,
    supportsRealtimeQuotes: true,
    supportsOrderExecution: true,
    maxCandleLimit: 2000
  };

  private customCandles = new Map<string, Candle[]>();

  constructor() {
    super();
    this.quotaManager = QuotaManager.getInstance({
      providerName: this.name,
      dailyBudget: 1000000,
      burstLimitPerMinute: 100000
    });
  }

  public setMockCandles(symbol: string, timeframe: Timeframe, candles: Candle[]): void {
    this.customCandles.set(`${symbol}:${timeframe}`, candles);
  }

  public async discoverMarkets(assetClasses?: AssetClass[]): Promise<Instrument[]> {
    return MarketDiscoveryService.getUniverse(assetClasses);
  }

  public async getQuote(symbol: string, assetClass: AssetClass = 'CRYPTO'): Promise<Quote> {
    this.quotaManager.recordRequest();
    let price = 50000;
    if (assetClass === 'FOREX') price = 1.0850;
    if (assetClass === 'METALS') price = 2400.0;
    if (assetClass === 'INDICES') price = 5500.0;
    if (assetClass === 'STOCKS') price = 180.0;
    if (assetClass === 'COMMODITIES') price = 75.0;

    const spread = price * 0.0002;
    return {
      symbol,
      bid: price - spread / 2,
      ask: price + spread / 2,
      last: price,
      spread,
      spreadBps: 2.0,
      timestamp: Date.now()
    };
  }

  public async getCandles(symbol: string, timeframe: Timeframe, limit: number = 100, assetClass: AssetClass = 'CRYPTO'): Promise<Candle[]> {
    this.quotaManager.recordRequest();
    const key = `${symbol}:${timeframe}`;
    if (this.customCandles.has(key)) {
      return this.customCandles.get(key)!.slice(-limit);
    }

    // Generate clean trending/testing candles
    let price = 50000;
    let step = 50;
    if (assetClass === 'FOREX') { price = 1.0850; step = 0.0003; }
    if (assetClass === 'METALS') { price = 2400.0; step = 1.5; }
    if (assetClass === 'INDICES') { price = 5500.0; step = 4.0; }
    if (assetClass === 'STOCKS') { price = 180.0; step = 0.4; }
    if (assetClass === 'COMMODITIES') { price = 75.0; step = 0.2; }

    const candles: Candle[] = [];
    const intervalMs = 60000;
    const now = Date.now();

    for (let i = limit; i >= 0; i--) {
      const ts = now - i * intervalMs;
      const change = (Math.sin(i * 0.2) + 0.1) * step;
      const open = price;
      const close = open + change;
      const high = Math.max(open, close) + step * 0.5;
      const low = Math.min(open, close) - step * 0.5;
      const volume = 1500 + Math.abs(Math.sin(i * 0.3) * 1000);
      price = close;

      candles.push({ timestamp: ts, open, high, low, close, volume });
    }

    return candles;
  }
}
