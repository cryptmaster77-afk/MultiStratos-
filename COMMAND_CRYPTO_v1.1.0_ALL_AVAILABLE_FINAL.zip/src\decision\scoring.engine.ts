import { MultiFactorScore, StrategyReasoning } from '../types/strategy.js';
import { SetupSimilarityResult } from '../types/memory.js';
import { SentimentSnapshot } from '../sentiment/sentiment.types.js';
import { AccountState } from '../types/risk.js';
import { Quote } from '../types/market.js';
import { SCORING_WEIGHTS } from '../config/constants.js';

export class ScoringEngine {
  /**
   * Computes the 6 distinct, explainable score pillars and synthesizes the weighted composite score.
   */
  public static computeScores(
    reasoning: StrategyReasoning,
    similarity: SetupSimilarityResult,
    sentiment: SentimentSnapshot,
    account: AccountState,
    quote: Quote
  ): MultiFactorScore {
    // 1. Strategy Technical Score (0 - 100)
    const strategyScore = reasoning.technicalScore;

    // 2. Historical Memory Score (0 - 100)
    const memoryScore = similarity.memoryScore;

    // 3. Regime Suitability Score (0 - 100)
    const regimeScore = reasoning.regimeCompatibility.compatibilityScore;

    // 4. Sentiment / Context Score (0 - 100)
    let sentimentScore = 50;
    if (reasoning.direction === 'BUY') {
      sentimentScore = sentiment.sentimentScore; // High greed or bullish context favors Buy
    } else if (reasoning.direction === 'SELL') {
      sentimentScore = 100 - sentiment.sentimentScore; // High fear favors Sell
    }

    // 5. Execution Quality Score (0 - 100)
    let executionScore = 90;
    if (quote.spreadBps > 10) executionScore -= 30;
    else if (quote.spreadBps > 5) executionScore -= 15;
    else if (quote.spreadBps > 2) executionScore -= 5;
    executionScore = Math.max(10, Math.min(100, executionScore));

    // 6. Portfolio Risk Score (0 - 100)
    let riskScore = 100;
    if (account.dailyDrawdownPct > 2.0) riskScore = 20;
    else if (account.dailyDrawdownPct > 1.5) riskScore = 45;
    else if (account.dailyDrawdownPct > 1.0) riskScore = 70;
    
    if (account.totalExposurePct > 15.0) riskScore -= 25;
    if (account.openPositionsCount >= 4) riskScore -= 30;
    riskScore = Math.max(0, Math.min(100, riskScore));

    // Weighted Composite Score
    const compositeScore = Math.round(
      strategyScore * SCORING_WEIGHTS.STRATEGY_WEIGHT +
      memoryScore * SCORING_WEIGHTS.MEMORY_WEIGHT +
      regimeScore * SCORING_WEIGHTS.REGIME_WEIGHT +
      sentimentScore * SCORING_WEIGHTS.SENTIMENT_WEIGHT +
      executionScore * SCORING_WEIGHTS.EXECUTION_WEIGHT +
      riskScore * SCORING_WEIGHTS.RISK_WEIGHT
    );

    // Final Confidence Percentage
    const baseConfidence = compositeScore * similarity.recommendedConfidenceMultiplier;
    const confidencePct = Math.min(99, Math.max(10, Math.round(baseConfidence)));

    return {
      strategyScore,
      memoryScore,
      regimeScore,
      sentimentScore,
      executionScore,
      riskScore,
      compositeScore,
      confidencePct
    };
  }
}
