import { AssetClass, MarketHours } from '../types/market.js';

export const ASSET_CLASS_CONFIG: Record<AssetClass, {
  name: string;
  defaultLeverage: number;
  maxLeverage: number;
  defaultFeeBps: number;
  defaultSlippageBps: number;
  session: MarketHours;
  liveSupported: boolean;
}> = {
  CRYPTO: {
    name: 'Cryptocurrency',
    defaultLeverage: 1,
    maxLeverage: 10,
    defaultFeeBps: 5,     // 0.05%
    defaultSlippageBps: 2,
    session: {
      timezone: 'UTC',
      is24x7: true,
      openUtcHour: 0,
      openUtcMinute: 0,
      closeUtcHour: 23,
      closeUtcMinute: 59,
      tradingDays: [0, 1, 2, 3, 4, 5, 6]
    },
    liveSupported: true // Bybit API live ready
  },
  FOREX: {
    name: 'Foreign Exchange',
    defaultLeverage: 1,
    maxLeverage: 10,
    defaultFeeBps: 2,     // Spread typically covers fee
    defaultSlippageBps: 1,
    session: {
      timezone: 'UTC',
      is24x7: false,
      openUtcHour: 22,    // Sunday 22:00 UTC
      openUtcMinute: 0,
      closeUtcHour: 22,   // Friday 22:00 UTC
      closeUtcMinute: 0,
      tradingDays: [0, 1, 2, 3, 4, 5] // Sunday night to Friday night
    },
    liveSupported: false // Paper only until OANDA/Interactive Brokers live account configured
  },
  METALS: {
    name: 'Precious Metals',
    defaultLeverage: 1,
    maxLeverage: 5,
    defaultFeeBps: 3,
    defaultSlippageBps: 2,
    session: {
      timezone: 'America/New_York',
      is24x7: false,
      openUtcHour: 23,    // Sun 23:00 UTC - Fri 22:00 UTC with 1h daily break 22:00-23:00 UTC
      openUtcMinute: 0,
      closeUtcHour: 22,
      closeUtcMinute: 0,
      tradingDays: [0, 1, 2, 3, 4, 5]
    },
    liveSupported: false
  },
  INDICES: {
    name: 'Equity Indices',
    defaultLeverage: 1,
    maxLeverage: 5,
    defaultFeeBps: 2,
    defaultSlippageBps: 2,
    session: {
      timezone: 'America/New_York',
      is24x7: false,
      openUtcHour: 13,    // 09:30 EST (13:30/14:30 UTC)
      openUtcMinute: 30,
      closeUtcHour: 20,   // 16:00 EST (20:00/21:00 UTC)
      closeUtcMinute: 0,
      tradingDays: [1, 2, 3, 4, 5] // Mon-Fri
    },
    liveSupported: false
  },
  STOCKS: {
    name: 'Equities',
    defaultLeverage: 1,
    maxLeverage: 2,
    defaultFeeBps: 1,
    defaultSlippageBps: 1,
    session: {
      timezone: 'America/New_York',
      is24x7: false,
      openUtcHour: 13,    // 09:30 EST
      openUtcMinute: 30,
      closeUtcHour: 20,   // 16:00 EST
      closeUtcMinute: 0,
      tradingDays: [1, 2, 3, 4, 5]
    },
    liveSupported: false
  },
  COMMODITIES: {
    name: 'Energy & Commodities',
    defaultLeverage: 1,
    maxLeverage: 5,
    defaultFeeBps: 4,
    defaultSlippageBps: 3,
    session: {
      timezone: 'America/New_York',
      is24x7: false,
      openUtcHour: 23,    // Sun 23:00 UTC to Fri 22:00 UTC
      openUtcMinute: 0,
      closeUtcHour: 22,
      closeUtcMinute: 0,
      tradingDays: [0, 1, 2, 3, 4, 5]
    },
    liveSupported: false
  }
};

export const RISK_LIMITS = {
  DEFAULT_INITIAL_PAPER_BALANCE: 100.0,
  MAX_RISK_PER_TRADE_PCT: 0.5,           // 0.5% max risk per trade
  MAX_DAILY_LOSS_PCT: 3.0,               // 3.0% max daily loss halt
  MAX_PORTFOLIO_EXPOSURE_PCT: 20.0,      // 20% max simultaneous open notional
  MAX_CONCURRENT_POSITIONS: 5,
  MAX_CORRELATED_EXPOSURE_PCT: 10.0,
  MIN_RR_RATIO: 1.5,                     // Minimum 1:1.5 Risk-to-Reward
  MAX_ALLOWED_SLIPPAGE_BPS: 25           // Reject trade if estimated spread + slippage > 25 bps
};

export const SCORING_WEIGHTS = {
  STRATEGY_WEIGHT: 0.40,
  MEMORY_WEIGHT: 0.25,
  REGIME_WEIGHT: 0.15,
  SENTIMENT_WEIGHT: 0.05,
  EXECUTION_WEIGHT: 0.05,
  RISK_WEIGHT: 0.10
};

export const DECISION_THRESHOLDS = {
  TRADE_MIN_COMPOSITE: 75,
  TRADE_MIN_STRATEGY: 70,
  CONFIRMATION_MIN_STRATEGY: 80,
  MIN_CONFIDENCE_PCT: 65
};
