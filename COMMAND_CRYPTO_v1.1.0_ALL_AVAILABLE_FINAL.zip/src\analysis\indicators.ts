import { Candle } from '../types/market.js';

export class TechnicalIndicators {
  /**
   * Simple Moving Average
   */
  public static sma(values: number[], period: number): number[] {
    const result: number[] = [];
    for (let i = 0; i < values.length; i++) {
      if (i < period - 1) {
        result.push(NaN);
      } else {
        let sum = 0;
        for (let j = 0; j < period; j++) {
          sum += values[i - j];
        }
        result.push(sum / period);
      }
    }
    return result;
  }

  /**
   * Exponential Moving Average
   */
  public static ema(values: number[], period: number): number[] {
    const result: number[] = [];
    const multiplier = 2 / (period + 1);
    
    // Find initial SMA
    let initialSum = 0;
    for (let i = 0; i < values.length; i++) {
      if (i < period - 1) {
        initialSum += values[i];
        result.push(NaN);
      } else if (i === period - 1) {
        initialSum += values[i];
        result.push(initialSum / period);
      } else {
        const prevEma = result[i - 1];
        const currentEma = (values[i] - prevEma) * multiplier + prevEma;
        result.push(currentEma);
      }
    }
    return result;
  }

  /**
   * Relative Strength Index (RSI)
   */
  public static rsi(values: number[], period: number = 14): number[] {
    const result: number[] = [];
    if (values.length <= period) return values.map(() => 50);

    let gains = 0;
    let losses = 0;

    for (let i = 1; i <= period; i++) {
      const diff = values[i] - values[i - 1];
      if (diff >= 0) gains += diff;
      else losses += Math.abs(diff);
    }

    let avgGain = gains / period;
    let avgLoss = losses / period;

    for (let i = 0; i < period; i++) {
      result.push(NaN);
    }

    if (avgLoss === 0) {
      result.push(100);
    } else {
      const rs = avgGain / avgLoss;
      result.push(100 - 100 / (1 + rs));
    }

    for (let i = period + 1; i < values.length; i++) {
      const diff = values[i] - values[i - 1];
      const gain = diff >= 0 ? diff : 0;
      const loss = diff < 0 ? Math.abs(diff) : 0;

      avgGain = (avgGain * (period - 1) + gain) / period;
      avgLoss = (avgLoss * (period - 1) + loss) / period;

      if (avgLoss === 0) {
        result.push(100);
      } else {
        const rs = avgGain / avgLoss;
        result.push(100 - 100 / (1 + rs));
      }
    }

    return result;
  }

  /**
   * Average True Range (ATR)
   */
  public static atr(candles: Candle[], period: number = 14): number[] {
    const tr: number[] = [];
    for (let i = 0; i < candles.length; i++) {
      if (i === 0) {
        tr.push(candles[i].high - candles[i].low);
      } else {
        const hl = candles[i].high - candles[i].low;
        const hc = Math.abs(candles[i].high - candles[i - 1].close);
        const lc = Math.abs(candles[i].low - candles[i - 1].close);
        tr.push(Math.max(hl, hc, lc));
      }
    }

    const result: number[] = [];
    let initialSum = 0;

    for (let i = 0; i < tr.length; i++) {
      if (i < period - 1) {
        initialSum += tr[i];
        result.push(NaN);
      } else if (i === period - 1) {
        initialSum += tr[i];
        result.push(initialSum / period);
      } else {
        const prevAtr = result[i - 1];
        const currentAtr = (prevAtr * (period - 1) + tr[i]) / period;
        result.push(currentAtr);
      }
    }

    return result;
  }

  /**
   * Bollinger Bands
   */
  public static bollingerBands(values: number[], period: number = 20, stdDevMultiplier: number = 2.0): {
    upper: number[];
    middle: number[];
    lower: number[];
    bandwidth: number[];
    percentB: number[];
  } {
    const middle = this.sma(values, period);
    const upper: number[] = [];
    const lower: number[] = [];
    const bandwidth: number[] = [];
    const percentB: number[] = [];

    for (let i = 0; i < values.length; i++) {
      if (i < period - 1 || isNaN(middle[i])) {
        upper.push(NaN);
        lower.push(NaN);
        bandwidth.push(NaN);
        percentB.push(NaN);
      } else {
        let sumSquaredDiff = 0;
        for (let j = 0; j < period; j++) {
          const diff = values[i - j] - middle[i];
          sumSquaredDiff += diff * diff;
        }
        const stdDev = Math.sqrt(sumSquaredDiff / period);
        const up = middle[i] + stdDevMultiplier * stdDev;
        const low = middle[i] - stdDevMultiplier * stdDev;
        const bw = middle[i] > 0 ? (up - low) / middle[i] * 100 : 0;
        const pb = up !== low ? (values[i] - low) / (up - low) : 0.5;

        upper.push(up);
        lower.push(low);
        bandwidth.push(bw);
        percentB.push(pb);
      }
    }

    return { upper, middle, lower, bandwidth, percentB };
  }

  /**
   * Moving Average Convergence Divergence (MACD)
   */
  public static macd(values: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9): {
    macdLine: number[];
    signalLine: number[];
    histogram: number[];
  } {
    const fastEma = this.ema(values, fastPeriod);
    const slowEma = this.ema(values, slowPeriod);
    const macdLine: number[] = [];

    for (let i = 0; i < values.length; i++) {
      if (isNaN(fastEma[i]) || isNaN(slowEma[i])) {
        macdLine.push(NaN);
      } else {
        macdLine.push(fastEma[i] - slowEma[i]);
      }
    }

    // Filter valid MACD values to compute Signal line
    const firstValidIdx = macdLine.findIndex(v => !isNaN(v));
    const signalLine: number[] = values.map(() => NaN);
    const histogram: number[] = values.map(() => NaN);

    if (firstValidIdx !== -1) {
      const validMacd = macdLine.slice(firstValidIdx);
      const computedSignal = this.ema(validMacd, signalPeriod);
      for (let j = 0; j < computedSignal.length; j++) {
        const fullIdx = firstValidIdx + j;
        signalLine[fullIdx] = computedSignal[j];
        if (!isNaN(macdLine[fullIdx]) && !isNaN(signalLine[fullIdx])) {
          histogram[fullIdx] = macdLine[fullIdx] - signalLine[fullIdx];
        }
      }
    }

    return { macdLine, signalLine, histogram };
  }

  /**
   * Average Directional Index (ADX)
   */
  public static adx(candles: Candle[], period: number = 14): {
    adx: number[];
    plusDi: number[];
    minusDi: number[];
  } {
    if (candles.length < period * 2) {
      const empty = candles.map(() => 20);
      return { adx: empty, plusDi: empty, minusDi: empty };
    }

    const tr: number[] = [];
    const plusDm: number[] = [];
    const minusDm: number[] = [];

    for (let i = 0; i < candles.length; i++) {
      if (i === 0) {
        tr.push(candles[i].high - candles[i].low);
        plusDm.push(0);
        minusDm.push(0);
      } else {
        const hl = candles[i].high - candles[i].low;
        const hc = Math.abs(candles[i].high - candles[i - 1].close);
        const lc = Math.abs(candles[i].low - candles[i - 1].close);
        tr.push(Math.max(hl, hc, lc));

        const upMove = candles[i].high - candles[i - 1].high;
        const downMove = candles[i - 1].low - candles[i].low;

        if (upMove > downMove && upMove > 0) {
          plusDm.push(upMove);
        } else {
          plusDm.push(0);
        }

        if (downMove > upMove && downMove > 0) {
          minusDm.push(downMove);
        } else {
          minusDm.push(0);
        }
      }
    }

    const smoothedTr = this.ema(tr, period);
    const smoothedPlusDm = this.ema(plusDm, period);
    const smoothedMinusDm = this.ema(minusDm, period);

    const plusDi: number[] = [];
    const minusDi: number[] = [];
    const dx: number[] = [];

    for (let i = 0; i < candles.length; i++) {
      if (isNaN(smoothedTr[i]) || smoothedTr[i] === 0) {
        plusDi.push(NaN);
        minusDi.push(NaN);
        dx.push(NaN);
      } else {
        const pDi = (smoothedPlusDm[i] / smoothedTr[i]) * 100;
        const mDi = (smoothedMinusDm[i] / smoothedTr[i]) * 100;
        plusDi.push(pDi);
        minusDi.push(mDi);

        const diSum = pDi + mDi;
        if (diSum === 0) {
          dx.push(0);
        } else {
          dx.push((Math.abs(pDi - mDi) / diSum) * 100);
        }
      }
    }

    const firstValidDx = dx.findIndex(v => !isNaN(v));
    const adx: number[] = candles.map(() => NaN);

    if (firstValidDx !== -1) {
      const validDx = dx.slice(firstValidDx);
      const computedAdx = this.ema(validDx, period);
      for (let j = 0; j < computedAdx.length; j++) {
        adx[firstValidDx + j] = isNaN(computedAdx[j]) ? 20 : computedAdx[j];
      }
    }

    return { adx, plusDi, minusDi };
  }
}
