import { AssetClass } from '../types/market.js';

export interface SentimentSnapshot {
  source: string;
  assetClass: AssetClass;
  symbol?: string;
  sentimentScore: number;       // 0 - 100 (0 = Extreme Fear / Bearish, 50 = Neutral, 100 = Extreme Greed / Bullish)
  sentimentLabel: 'EXTREME_FEAR' | 'FEAR' | 'NEUTRAL' | 'GREED' | 'EXTREME_GREED';
  fundingRate?: number;         // For crypto perpetuals (e.g., +0.01% / 8h)
  confidence: number;
  timestamp: number;
  ttlMs: number;
  isStale: boolean;
  notes: string;
}
