import { PositionManager } from '../src/execution/position.manager.js';
import { Position } from '../src/types/risk.js';
import { Quote } from '../src/types/market.js';

export function testExecutionAndTrailing(): { name: string; passed: boolean; error?: string }[] {
  const tests: { name: string; passed: boolean; error?: string }[] = [];
  const manager = PositionManager.getInstance();

  const posId = `POS_TEST_${Date.now()}`;
  const pos: Position = {
    id: posId,
    symbol: 'BTC/USDT',
    assetClass: 'CRYPTO',
    provider: 'binance',
    direction: 'BUY',
    mode: 'PAPER',
    status: 'OPEN',
    entryPrice: 50000,
    currentPrice: 50000,
    stopLoss: 49000, // 1R = $1000
    initialStopLoss: 49000,
    takeProfit: 53000,
    sizeUnits: 0.001,
    notionalValue: 50,
    leverage: 1,
    margin: 50,
    unrealizedPnl: 0,
    unrealizedPnlPct: 0,
    unrealizedR: 0,
    realizedPnl: 0,
    feesPaid: 0.05,
    trailingStopActive: false,
    highestPriceSinceEntry: 50000,
    lowestPriceSinceEntry: 50000,
    mae: 0,
    mfe: 0,
    strategyId: 'STRAT_TREND_FOLLOWING',
    strategyVersion: '1.2.0',
    opportunityId: 'OPP_TEST_1',
    openedAt: Date.now()
  };

  manager.addPosition(pos);

  // 1. Move price up to +1.2R ($51,200) -> Trailing stop should activate
  const quoteUp: Quote = {
    symbol: 'BTC/USDT',
    bid: 51200,
    ask: 51202,
    last: 51200,
    spread: 2,
    spreadBps: 0.4,
    timestamp: Date.now()
  };

  const update1 = manager.updatePrice(posId, quoteUp);
  const updatedPos = manager.getPosition(posId);

  tests.push({
    name: 'Trailing stop activates when position reaches >= 1.0R gain',
    passed: updatedPos?.trailingStopActive === true && (updatedPos?.stopLoss || 0) >= 50000,
    error: `Trailing stop failed: active=${updatedPos?.trailingStopActive}, SL=${updatedPos?.stopLoss}`
  });

  // 2. Move price up to Take Profit ($53,000) -> Should trigger TAKE_PROFIT exit
  const quoteTp: Quote = {
    symbol: 'BTC/USDT',
    bid: 53000,
    ask: 53002,
    last: 53000,
    spread: 2,
    spreadBps: 0.4,
    timestamp: Date.now()
  };

  const update2 = manager.updatePrice(posId, quoteTp);
  tests.push({
    name: 'Position manager triggers TAKE_PROFIT exit when target is reached',
    passed: update2.closed === true && update2.exitReason === 'TAKE_PROFIT',
    error: `Expected TAKE_PROFIT exit, got closed=${update2.closed}, reason=${update2.exitReason}`
  });

  return tests;
}
