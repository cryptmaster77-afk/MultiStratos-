import { SetupSimilarityResult, SimilarityMatch, TradeExperienceRecord } from '../types/memory.js';
import { AssetClass, MarketRegimeType, Timeframe } from '../types/market.js';
import { SignalDirection } from '../types/strategy.js';
import { ExperienceStore } from './experience.store.js';
import { config } from '../config/index.js';

export interface SetupQuery {
  symbol: string;
  assetClass: AssetClass;
  strategyId: string;
  strategyVersion: string;
  direction: SignalDirection;
  regime: MarketRegimeType;
  session: string;
  timeframe: Timeframe;
  strategyScore: number;
  atrPct: number;
  riskReward: number;
}

export class SimilarityEngine {
  private static instance: SimilarityEngine;
  private store = ExperienceStore.getInstance();

  private constructor() {}

  public static getInstance(): SimilarityEngine {
    if (!this.instance) {
      this.instance = new SimilarityEngine();
    }
    return this.instance;
  }

  /**
   * Calculates similarity between candidate setup and a historical record across 10 dimensions.
   */
  private calculateSimilarity(query: SetupQuery, record: TradeExperienceRecord): SimilarityMatch {
    // 1. Strategy Match (0 or 1)
    const strategySim = query.strategyId === record.strategyId ? 1.0 : 0.2;

    // 2. Direction Match (0 or 1)
    const directionSim = query.direction === record.direction ? 1.0 : 0.0;

    // 3. Asset Class & Symbol Match
    let assetClassSim = 0.5;
    if (query.symbol === record.symbol) assetClassSim = 1.0;
    else if (query.assetClass === record.assetClass) assetClassSim = 0.8;

    // 4. Regime Match
    const regimeSim = query.regime === record.regime ? 1.0 : 0.2;

    // 5. Volatility / ATR% Match
    const atrDiff = Math.abs(query.atrPct - record.atrPct);
    const volatilitySim = Math.max(0, 1.0 - (atrDiff / Math.max(0.5, query.atrPct)));

    // 6. Score Bucket Match
    const scoreDiff = Math.abs(query.strategyScore - record.strategyScore);
    const scoreSim = Math.max(0, 1.0 - (scoreDiff / 50));

    // 7. Session Match
    const sessionSim = query.session === record.session ? 1.0 : 0.6;

    // 8. Recency Weighting: Exponential decay based on half-life (30 days)
    const ageDays = (Date.now() - record.timestamp) / (1000 * 3600 * 24);
    const halfLifeDays = config.memory.recencyHalfLifeDays || 30;
    const recencyWeight = Math.pow(0.5, ageDays / halfLifeDays);

    // Weighted composite similarity
    const weights = {
      strategy: 0.25,
      direction: 0.20,
      regime: 0.20,
      assetClass: 0.15,
      volatility: 0.10,
      score: 0.05,
      session: 0.05
    };

    const rawSimilarity = 
      strategySim * weights.strategy +
      directionSim * weights.direction +
      regimeSim * weights.regime +
      assetClassSim * weights.assetClass +
      volatilitySim * weights.volatility +
      scoreSim * weights.score +
      sessionSim * weights.session;

    const weightedSimilarity = rawSimilarity * (0.5 + 0.5 * recencyWeight);

    return {
      record,
      similarityScore: weightedSimilarity,
      dimensionBreakdown: {
        strategySimilarity: strategySim,
        regimeSimilarity: regimeSim,
        assetClassSimilarity: assetClassSim,
        volatilitySimilarity: volatilitySim,
        scoreSimilarity: scoreSim,
        sessionSimilarity: sessionSim,
        recencyWeight
      }
    };
  }

  /**
   * Evaluates memory similarity against historical trade experience.
   */
  public evaluateSimilarity(query: SetupQuery): SetupSimilarityResult {
    const minSamples = config.memory.minSamplesForMemory || 5;
    const simThreshold = config.memory.similarityThreshold || 0.70;

    const allRecords = this.store.getCompletedTrades();

    if (allRecords.length === 0) {
      return {
        hasSufficientData: false,
        sampleCount: 0,
        averageSimilarity: 0,
        historicalWinRate: 0.5,
        historicalExpectancyR: 0,
        historicalProfitFactor: 1.0,
        historicalAvgMae: 0,
        historicalAvgMfe: 0,
        repeatedFailureDetected: false,
        failurePatternCount: 0,
        recommendedConfidenceMultiplier: 1.0,
        memoryScore: 50,
        notes: 'Insufficient historical evidence (no completed trades in database) — default neutral memory score',
        topMatches: []
      };
    }

    const matches: SimilarityMatch[] = allRecords
      .map(rec => this.calculateSimilarity(query, rec))
      .filter(m => m.similarityScore >= simThreshold)
      .sort((a, b) => b.similarityScore - a.similarityScore);

    if (matches.length < minSamples) {
      return {
        hasSufficientData: false,
        sampleCount: matches.length,
        averageSimilarity: matches.length > 0 ? matches.reduce((s, m) => s + m.similarityScore, 0) / matches.length : 0,
        historicalWinRate: 0.5,
        historicalExpectancyR: 0,
        historicalProfitFactor: 1.0,
        historicalAvgMae: 0,
        historicalAvgMfe: 0,
        repeatedFailureDetected: false,
        failurePatternCount: 0,
        recommendedConfidenceMultiplier: 1.0,
        memoryScore: 50,
        notes: `Insufficient historical sample size (${matches.length}/${minSamples} similar setups) — preserving baseline strategy confidence`,
        topMatches: matches.slice(0, 5)
      };
    }

    // Statistical aggregation of similar trades
    const wins = matches.filter(m => (m.record.realizedR || 0) > 0);
    const losses = matches.filter(m => (m.record.realizedR || 0) <= 0);
    const winRate = wins.length / matches.length;

    const totalR = matches.reduce((acc, m) => acc + (m.record.realizedR || 0), 0);
    const expectancyR = totalR / matches.length;

    const grossGain = wins.reduce((acc, m) => acc + (m.record.realizedR || 0), 0);
    const grossLoss = Math.abs(losses.reduce((acc, m) => acc + (m.record.realizedR || 0), 0));
    const profitFactor = grossLoss > 0 ? grossGain / grossLoss : (grossGain > 0 ? 5.0 : 1.0);

    const avgMae = matches.reduce((acc, m) => acc + (m.record.mae || 0), 0) / matches.length;
    const avgMfe = matches.reduce((acc, m) => acc + (m.record.mfe || 0), 0) / matches.length;

    // Detect repeated consecutive failures in recent similar setups
    let recentConsecutiveLosses = 0;
    for (let i = 0; i < Math.min(5, matches.length); i++) {
      if ((matches[i].record.realizedR || 0) < 0) {
        recentConsecutiveLosses++;
      } else {
        break;
      }
    }

    const repeatedFailureDetected = recentConsecutiveLosses >= (config.memory.repeatedFailureThreshold || 3);

    // Compute explainable Memory Score (0 - 100)
    let memoryScore = 50;
    if (expectancyR > 0.5) memoryScore = 85;
    else if (expectancyR > 0.2) memoryScore = 75;
    else if (expectancyR > 0) memoryScore = 60;
    else if (expectancyR > -0.2) memoryScore = 40;
    else memoryScore = 20;

    let confidenceMultiplier = 1.0;
    if (repeatedFailureDetected) {
      confidenceMultiplier = 0.5; // Dampen confidence by 50%
      memoryScore = Math.min(memoryScore, 30);
    } else if (winRate >= 0.65 && expectancyR > 0.5) {
      confidenceMultiplier = 1.2;
    } else if (winRate < 0.40 || expectancyR < -0.2) {
      confidenceMultiplier = 0.7;
    }

    const avgSim = matches.reduce((s, m) => s + m.similarityScore, 0) / matches.length;
    const notes = repeatedFailureDetected
      ? `Repeated failure pattern: ${recentConsecutiveLosses} consecutive losses in similar ${query.strategyId} setups under ${query.regime}`
      : `Historical performance: ${(winRate * 100).toFixed(1)}% win rate across ${matches.length} similar setups (Expectancy: ${expectancyR.toFixed(2)}R, PF: ${profitFactor.toFixed(2)})`;

    return {
      hasSufficientData: true,
      sampleCount: matches.length,
      averageSimilarity: avgSim,
      historicalWinRate: winRate,
      historicalExpectancyR: expectancyR,
      historicalProfitFactor: profitFactor,
      historicalAvgMae: avgMae,
      historicalAvgMfe: avgMfe,
      repeatedFailureDetected,
      failurePatternCount: recentConsecutiveLosses,
      recommendedConfidenceMultiplier: confidenceMultiplier,
      memoryScore,
      notes,
      topMatches: matches.slice(0, 5)
    };
  }
}
