﻿import { AssetClass } from '../types/market.js';

export interface RawInstrumentSeed {
  raw: string;
  provider: 'bybit' | 'twelvedata';
  exchange: string;
  minNotional: number;
  tick: number;
  lot: number;
}

/**
 * Baseline Multi-Asset Catalog containing verified tradable instruments across all 6 asset classes.
 * Augmented dynamically by provider discovery endpoints (Bybit /instruments-info, TwelveData /forex_pairs, etc.).
 */
export const BASELINE_UNIVERSE_CATALOG: RawInstrumentSeed[] = [
  // ==========================================
  // 1. CRYPTO (Bybit Spot Pairs)
  // ==========================================
  { raw: 'BTCUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 10, tick: 0.1, lot: 0.0001 },
  { raw: 'ETHUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 10, tick: 0.01, lot: 0.001 },
  { raw: 'SOLUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.01, lot: 0.01 },
  { raw: 'BNBUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.01, lot: 0.01 },
  { raw: 'XRPUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'DOGEUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.00001, lot: 1 },
  { raw: 'ADAUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'AVAXUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.01, lot: 0.1 },
  { raw: 'LINKUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'NEARUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'SUIUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'TAOUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 10, tick: 0.1, lot: 0.001 },
  { raw: 'PEPEUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.00000001, lot: 1000 },
  { raw: 'SHIBUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.00000001, lot: 1000 },
  { raw: 'APTUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'ARBUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'OPUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'POLUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'LTCUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.01, lot: 0.01 },
  { raw: 'DOTUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'ATOMUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'UNIUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'INJUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'TIAUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'RENDERUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'FETUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'KASUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'STXUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'FILUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'AAVEUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.01, lot: 0.01 },
  { raw: 'ICPUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'FTMUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'RUNEUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.001, lot: 0.1 },
  { raw: 'SEIUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'WIFUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'BONKUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.00000001, lot: 1000 },
  { raw: 'FLOKIUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.00000001, lot: 1000 },
  { raw: 'JUPUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'PYTHUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },
  { raw: 'ONDOUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 5, tick: 0.0001, lot: 1 },

  // ==========================================
  // 2. FOREX (Twelve Data / Interbank Currency Pairs)
  // ==========================================
  { raw: 'EUR/USD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'GBP/USD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'USD/JPY', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.001, lot: 1000 },
  { raw: 'AUD/USD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'USD/CAD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'USD/CHF', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'NZD/USD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'EUR/GBP', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'EUR/JPY', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.001, lot: 1000 },
  { raw: 'GBP/JPY', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.001, lot: 1000 },
  { raw: 'AUD/JPY', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.001, lot: 1000 },
  { raw: 'CAD/JPY', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.001, lot: 1000 },
  { raw: 'CHF/JPY', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.001, lot: 1000 },
  { raw: 'NZD/JPY', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.001, lot: 1000 },
  { raw: 'EUR/AUD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'EUR/CAD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'EUR/CHF', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'EUR/NZD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'GBP/AUD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'GBP/CAD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'GBP/CHF', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'GBP/NZD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'AUD/CAD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'AUD/CHF', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'AUD/NZD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'CAD/CHF', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'NZD/CAD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'NZD/CHF', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'USD/SGD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'USD/HKD', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.00001, lot: 1000 },
  { raw: 'USD/SEK', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.0001, lot: 1000 },
  { raw: 'USD/NOK', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.0001, lot: 1000 },
  { raw: 'USD/TRY', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.0001, lot: 1000 },
  { raw: 'USD/ZAR', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.0001, lot: 1000 },
  { raw: 'USD/MXN', provider: 'twelvedata', exchange: 'Forex', minNotional: 100, tick: 0.0001, lot: 1000 },

  // ==========================================
  // 3. METALS (Twelve Data / Precious Metals)
  // ==========================================
  { raw: 'XAU/USD', provider: 'twelvedata', exchange: 'Spot Commodities', minNotional: 50, tick: 0.01, lot: 0.01 },
  { raw: 'XAG/USD', provider: 'twelvedata', exchange: 'Spot Commodities', minNotional: 20, tick: 0.001, lot: 1 },
  { raw: 'XPT/USD', provider: 'twelvedata', exchange: 'Spot Commodities', minNotional: 50, tick: 0.01, lot: 0.01 },
  { raw: 'XPD/USD', provider: 'twelvedata', exchange: 'Spot Commodities', minNotional: 50, tick: 0.01, lot: 0.01 },
  { raw: 'PAXGUSDT', provider: 'bybit', exchange: 'Bybit', minNotional: 10, tick: 0.1, lot: 0.001 },

  // ==========================================
  // 4. INDICES (Twelve Data / Global Equities Indices)
  // ==========================================
  { raw: 'SPX', provider: 'twelvedata', exchange: 'S&P Dow Jones', minNotional: 100, tick: 0.1, lot: 0.1 },
  { raw: 'NDX', provider: 'twelvedata', exchange: 'Nasdaq', minNotional: 100, tick: 0.1, lot: 0.1 },
  { raw: 'DJI', provider: 'twelvedata', exchange: 'S&P Dow Jones', minNotional: 100, tick: 1.0, lot: 0.1 },
  { raw: 'DAX', provider: 'twelvedata', exchange: 'Deutsche Boerse', minNotional: 100, tick: 0.5, lot: 0.1 },
  { raw: 'FTSE', provider: 'twelvedata', exchange: 'FTSE Russell', minNotional: 100, tick: 0.5, lot: 0.1 },
  { raw: 'NIKKEI', provider: 'twelvedata', exchange: 'Tokyo Stock Exchange', minNotional: 100, tick: 1.0, lot: 0.1 },
  { raw: 'CAC', provider: 'twelvedata', exchange: 'Euronext', minNotional: 100, tick: 0.5, lot: 0.1 },
  { raw: 'ASX', provider: 'twelvedata', exchange: 'Australian Securities Exchange', minNotional: 100, tick: 0.5, lot: 0.1 },
  { raw: 'STOXX', provider: 'twelvedata', exchange: 'STOXX Ltd', minNotional: 100, tick: 0.5, lot: 0.1 },
  { raw: 'RUT', provider: 'twelvedata', exchange: 'FTSE Russell', minNotional: 100, tick: 0.1, lot: 0.1 },

  // ==========================================
  // 5. STOCKS (Twelve Data / US Equities)
  // ==========================================
  { raw: 'AAPL', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'NVDA', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'MSFT', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'TSLA', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'AMZN', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'GOOGL', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'META', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'AMD', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'NFLX', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'INTC', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'DIS', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'JPM', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'V', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'MA', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'PG', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'JNJ', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'WMT', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'UNH', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'HD', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'BAC', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'XOM', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'CVX', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'LLY', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'ABBV', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'MRK', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'COST', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'PEP', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'KO', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'ADBE', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'CRM', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'AVGO', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'CSCO', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'TXN', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'QCOM', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'ORCL', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'IBM', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'INTU', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'PYPL', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'UBER', provider: 'twelvedata', exchange: 'NYSE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'COIN', provider: 'twelvedata', exchange: 'NASDAQ', minNotional: 50, tick: 0.01, lot: 1 },

  // ==========================================
  // 6. COMMODITIES (Twelve Data / Energy & Agriculture)
  // ==========================================
  { raw: 'USOIL', provider: 'twelvedata', exchange: 'NYMEX', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'UKOIL', provider: 'twelvedata', exchange: 'ICE', minNotional: 50, tick: 0.01, lot: 1 },
  { raw: 'NATGAS', provider: 'twelvedata', exchange: 'NYMEX', minNotional: 50, tick: 0.001, lot: 1 },
  { raw: 'COPPER', provider: 'twelvedata', exchange: 'COMEX', minNotional: 50, tick: 0.0005, lot: 1 },
  { raw: 'WHEAT', provider: 'twelvedata', exchange: 'CBOT', minNotional: 50, tick: 0.25, lot: 1 },
  { raw: 'CORN', provider: 'twelvedata', exchange: 'CBOT', minNotional: 50, tick: 0.25, lot: 1 },
  { raw: 'SOYBEAN', provider: 'twelvedata', exchange: 'CBOT', minNotional: 50, tick: 0.25, lot: 1 }
];
