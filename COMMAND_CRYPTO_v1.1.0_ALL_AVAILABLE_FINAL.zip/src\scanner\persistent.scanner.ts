import * as fs from 'fs';
import * as path from 'path';
import { Instrument, Timeframe } from '../types/market.js';
import { QualifiedOpportunity } from '../types/strategy.js';
import { MarketDiscoveryService } from '../market/discovery.js';
import { SessionEngine } from '../market/session.engine.js';
import { ProviderRegistry } from '../providers/provider.registry.js';
import { MultiTimeframeAnalyzer } from '../analysis/mtf.analyzer.js';
import { RegimeDetector } from '../analysis/regime.detector.js';
import { StrategyRouter } from '../strategies/strategy.router.js';
import { SentimentEngine } from '../sentiment/sentiment.engine.js';
import { SimilarityEngine } from '../memory/similarity.engine.js';
import { ScoringEngine } from '../decision/scoring.engine.js';
import { DecisionEngine } from '../decision/decision.engine.js';
import { RiskManager } from '../risk/risk.manager.js';
import { ExperienceStore } from '../memory/experience.store.js';
import { QuotaManager } from '../providers/quota.manager.js';
import { config } from '../config/index.js';

import { UniverseBreakdown } from '../market/discovery.js';

export interface ChannelScanState {
  universe: Instrument[];
  currentIndex: number;
  totalMarkets: number;
  completedCycles: number;
  lastScannedSymbol?: string;
  lastScannedAt: number;
  status: 'IDLE' | 'SCANNING' | 'PAUSED' | 'COMPLETED' | 'ERROR';
  lastError?: string;
  processedSymbols?: string[];
  skippedSymbols?: string[];
}

export interface DualScannerState {
  sessionId: string;
  universeMode?: 'ALL AVAILABLE' | 'CUSTOM';
  crypto: ChannelScanState;
  extended: ChannelScanState;
  totalOpportunitiesDiscovered: number;
  qualifiedCount: number;
  rejectedCount: number;
  lastSavedAt: number;
  universeBreakdown?: UniverseBreakdown;
}

export class PersistentScanner {
  private static instance: PersistentScanner;
  private checkpointPath: string;
  private state: DualScannerState;
  private providerRegistry = ProviderRegistry.getInstance();
  private strategyRouter = StrategyRouter.getInstance();
  private sentimentEngine = SentimentEngine.getInstance();
  private similarityEngine = SimilarityEngine.getInstance();
  private riskManager = RiskManager.getInstance();
  private experienceStore = ExperienceStore.getInstance();
  private opportunities: QualifiedOpportunity[] = [];

  private constructor() {
    this.checkpointPath = path.join(config.paths.checkpointsDir, 'scanner_checkpoint.json');
    this.ensureDirectory();
    this.state = this.loadCheckpoint();
  }

  public static getInstance(): PersistentScanner {
    if (!this.instance) {
      this.instance = new PersistentScanner();
    }
    return this.instance;
  }

  private ensureDirectory(): void {
    if (!fs.existsSync(config.paths.checkpointsDir)) {
      fs.mkdirSync(config.paths.checkpointsDir, { recursive: true });
    }
  }

  private loadCheckpoint(): DualScannerState {
    try {
      if (fs.existsSync(this.checkpointPath)) {
        const raw = fs.readFileSync(this.checkpointPath, 'utf-8');
        const parsed = JSON.parse(raw) as DualScannerState;
        if (parsed.crypto && parsed.extended) {
          // Merge with current full discovered universe
          const allUniverse = MarketDiscoveryService.getUniverse();
          const cryptoUni = allUniverse.filter(u => u.assetClass === 'CRYPTO');
          const extendedUni = allUniverse.filter(u => u.assetClass !== 'CRYPTO');

          parsed.crypto.universe = cryptoUni;
          parsed.crypto.totalMarkets = cryptoUni.length;
          parsed.extended.universe = extendedUni;
          parsed.extended.totalMarkets = extendedUni.length;

          if (!parsed.crypto.processedSymbols) parsed.crypto.processedSymbols = [];
          if (!parsed.extended.processedSymbols) parsed.extended.processedSymbols = [];
          return parsed;
        }
      }
    } catch (err) {
      console.warn('[PersistentScanner] Fresh checkpoint initialized.');
    }

    const allUniverse = MarketDiscoveryService.getUniverse();
    const cryptoUni = allUniverse.filter(u => u.assetClass === 'CRYPTO');
    const extendedUni = allUniverse.filter(u => u.assetClass !== 'CRYPTO');

    return {
      sessionId: `SCAN_DUAL_${Date.now()}`,
      universeMode: config.scanner.universeMode === 'CUSTOM' ? 'CUSTOM' : 'ALL AVAILABLE',
      crypto: {
        universe: cryptoUni,
        currentIndex: 0,
        totalMarkets: cryptoUni.length,
        completedCycles: 0,
        lastScannedAt: 0,
        status: 'IDLE',
        processedSymbols: [],
        skippedSymbols: []
      },
      extended: {
        universe: extendedUni,
        currentIndex: 0,
        totalMarkets: extendedUni.length,
        completedCycles: 0,
        lastScannedAt: 0,
        status: 'IDLE',
        processedSymbols: [],
        skippedSymbols: []
      },
      totalOpportunitiesDiscovered: 0,
      qualifiedCount: 0,
      rejectedCount: 0,
      lastSavedAt: Date.now()
    };
  }

  private saveCheckpoint(): void {
    try {
      this.ensureDirectory();
      this.state.lastSavedAt = Date.now();
      const tempPath = `${this.checkpointPath}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(this.state, null, 2), 'utf-8');
      fs.renameSync(tempPath, this.checkpointPath);
    } catch (err) {
      console.error('[PersistentScanner] Checkpoint save error:', err);
    }
  }

  public getState(): DualScannerState {
    const processedSet = new Set<string>([
      ...(this.state.crypto.processedSymbols || []),
      ...(this.state.extended.processedSymbols || [])
    ]);
    const breakdown = MarketDiscoveryService.getUniverseBreakdown(processedSet);
    return {
      ...this.state,
      universeMode: config.scanner.universeMode === 'CUSTOM' ? 'CUSTOM' : 'ALL AVAILABLE',
      universeBreakdown: breakdown
    };
  }

  public getOpportunities(): QualifiedOpportunity[] {
    return [...this.opportunities];
  }

  public resetAllUniverses(): void {
    const allUniverse = MarketDiscoveryService.getUniverse();
    const cryptoUni = allUniverse.filter(u => u.assetClass === 'CRYPTO');
    const extendedUni = allUniverse.filter(u => u.assetClass !== 'CRYPTO');

    this.state.crypto = {
      universe: cryptoUni,
      currentIndex: 0,
      totalMarkets: cryptoUni.length,
      completedCycles: 0,
      lastScannedAt: 0,
      status: 'IDLE',
      processedSymbols: [],
      skippedSymbols: []
    };
    this.state.extended = {
      universe: extendedUni,
      currentIndex: 0,
      totalMarkets: extendedUni.length,
      completedCycles: 0,
      lastScannedAt: 0,
      status: 'IDLE',
      processedSymbols: [],
      skippedSymbols: []
    };
    this.opportunities = [];
    this.saveCheckpoint();
  }

  /**
   * Continuous Controlled Bybit Crypto Scan Batch
   */
  public async scanCryptoBatch(batchSize: number = config.scanner.cryptoBatchSize): Promise<{
    processed: number;
    newOpportunities: QualifiedOpportunity[];
    cycleCompleted: boolean;
  }> {
    const channel = this.state.crypto;
    if (channel.universe.length === 0) {
      return { processed: 0, newOpportunities: [], cycleCompleted: false };
    }

    if (!channel.processedSymbols) channel.processedSymbols = [];
    channel.status = 'SCANNING';
    const newOpps: QualifiedOpportunity[] = [];
    const startIndex = channel.currentIndex;
    const endIndex = Math.min(startIndex + batchSize, channel.universe.length);

    for (let i = startIndex; i < endIndex; i++) {
      const instrument = channel.universe[i];
      channel.lastScannedSymbol = instrument.symbol;
      channel.lastScannedAt = Date.now();
      if (!channel.processedSymbols.includes(instrument.symbol)) {
        channel.processedSymbols.push(instrument.symbol);
      }

      try {
        const opp = await this.analyzeInstrument(instrument);
        if (opp) {
          newOpps.push(opp);
          this.opportunities.unshift(opp);
          this.state.totalOpportunitiesDiscovered++;
          if (opp.decision === 'TRADE' || opp.decision === 'REQUIRE_CONFIRMATION') {
            this.state.qualifiedCount++;
          } else {
            this.state.rejectedCount++;
          }
        }
      } catch (err: any) {
        channel.lastError = `Error on ${instrument.symbol}: ${err.message}`;
      }

      channel.currentIndex = i + 1;
      this.saveCheckpoint();

      if (config.scanner.cryptoBatchDelayMs > 0) {
        await new Promise(r => setTimeout(r, Math.min(500, config.scanner.cryptoBatchDelayMs / batchSize)));
      }
    }

    let cycleCompleted = false;
    if (channel.currentIndex >= channel.universe.length) {
      channel.currentIndex = 0; // Seamless loop for continuous crypto scanning
      channel.completedCycles++;
      channel.processedSymbols = []; // Reset processed tracker for next cycle
      channel.status = 'IDLE';
      cycleCompleted = true;
    }

    this.saveCheckpoint();
    return {
      processed: endIndex - startIndex,
      newOpportunities: newOpps,
      cycleCompleted
    };
  }

  /**
   * Scheduled Quota-Aware Twelve Data Extended Assets Scan Batch
   */
  public async scanExtendedBatch(batchSize: number = config.scanner.extendedBatchSize): Promise<{
    processed: number;
    newOpportunities: QualifiedOpportunity[];
    cycleCompleted: boolean;
    deferredByQuota?: boolean;
  }> {
    const channel = this.state.extended;
    if (channel.universe.length === 0) {
      return { processed: 0, newOpportunities: [], cycleCompleted: false };
    }

    // Check TwelveData quota budget and reserved safety margin
    const twelvedataProvider = this.providerRegistry.getProvider('twelvedata');
    const quotaState = twelvedataProvider.getQuotaState();
    if (quotaState.availableScanBudget <= 0) {
      console.warn(`[PersistentScanner] TwelveData quota safety preservation: available scan budget is ${quotaState.availableScanBudget}. Deferring extended scan.`);
      return { processed: 0, newOpportunities: [], cycleCompleted: false, deferredByQuota: true };
    }

    if (!channel.processedSymbols) channel.processedSymbols = [];
    if (!channel.skippedSymbols) channel.skippedSymbols = [];
    channel.status = 'SCANNING';
    const newOpps: QualifiedOpportunity[] = [];
    const startIndex = channel.currentIndex;
    const endIndex = Math.min(startIndex + batchSize, channel.universe.length);

    for (let i = startIndex; i < endIndex; i++) {
      const instrument = channel.universe[i];
      channel.lastScannedSymbol = instrument.symbol;
      channel.lastScannedAt = Date.now();

      // Check session: Skip API calls entirely for closed/weekend traditional markets!
      const session = SessionEngine.getSessionStatus(instrument.assetClass);
      instrument.sessionStatus = session.status;
      instrument.notes = session.sessionDescription;

      if (!session.isOpen && !session.isPreMarket) {
        // Market closed -> skip external API call to preserve TwelveData quota
        if (!channel.skippedSymbols.includes(instrument.symbol)) {
          channel.skippedSymbols.push(instrument.symbol);
        }
        channel.currentIndex = i + 1;
        this.saveCheckpoint();
        continue;
      }

      if (!channel.processedSymbols.includes(instrument.symbol)) {
        channel.processedSymbols.push(instrument.symbol);
      }

      try {
        const opp = await this.analyzeInstrument(instrument);
        if (opp) {
          newOpps.push(opp);
          this.opportunities.unshift(opp);
          this.state.totalOpportunitiesDiscovered++;
          if (opp.decision === 'TRADE' || opp.decision === 'REQUIRE_CONFIRMATION') {
            this.state.qualifiedCount++;
          } else {
            this.state.rejectedCount++;
          }
        }
      } catch (err: any) {
        channel.lastError = `Error on ${instrument.symbol}: ${err.message}`;
      }

      channel.currentIndex = i + 1;
      this.saveCheckpoint();

      if (config.scanner.extendedRequestDelayMs > 0) {
        await new Promise(r => setTimeout(r, config.scanner.extendedRequestDelayMs));
      }
    }

    let cycleCompleted = false;
    if (channel.currentIndex >= channel.universe.length) {
      channel.currentIndex = 0;
      channel.completedCycles++;
      channel.processedSymbols = [];
      channel.skippedSymbols = [];
      channel.status = 'COMPLETED';
      cycleCompleted = true;
    }

    this.saveCheckpoint();
    return {
      processed: endIndex - startIndex,
      newOpportunities: newOpps,
      cycleCompleted
    };
  }

  /**
   * Unified single batch scan method (for manual dashboard trigger)
   */
  public async scanNextBatch(batchSize: number = 4): Promise<{
    processed: number;
    newOpportunities: QualifiedOpportunity[];
    completed: boolean;
  }> {
    const cryptoResult = await this.scanCryptoBatch(batchSize);
    return {
      processed: cryptoResult.processed,
      newOpportunities: cryptoResult.newOpportunities,
      completed: cryptoResult.cycleCompleted
    };
  }

  /**
   * Full pipeline analysis for a single instrument.
   */
  public async analyzeInstrument(instrument: Instrument): Promise<QualifiedOpportunity | null> {
    const session = SessionEngine.getSessionStatus(instrument.assetClass);
    instrument.sessionStatus = session.status;
    instrument.notes = session.sessionDescription;

    // Fetch Candles & Quote
    const [higherCandles, mediumCandles, lowerCandles, quote] = await Promise.all([
      this.providerRegistry.getCandles(instrument.symbol, '4h', 60, instrument.assetClass, instrument.provider),
      this.providerRegistry.getCandles(instrument.symbol, '1h', 60, instrument.assetClass, instrument.provider),
      this.providerRegistry.getCandles(instrument.symbol, '15m', 60, instrument.assetClass, instrument.provider),
      this.providerRegistry.getQuote(instrument.symbol, instrument.assetClass, instrument.provider)
    ]);

    if (!lowerCandles || lowerCandles.length < 20) {
      return null;
    }

    const regime = RegimeDetector.detect(mediumCandles);
    const mtf = MultiTimeframeAnalyzer.analyze(instrument.symbol, higherCandles, mediumCandles, lowerCandles, '4h', '1h', '15m');

    const { bestReasoning } = this.strategyRouter.evaluateAll(instrument, lowerCandles, regime, mtf);
    const sentiment = await this.sentimentEngine.getSentiment(instrument.symbol, instrument.assetClass);

    const similarity = this.similarityEngine.evaluateSimilarity({
      symbol: instrument.symbol,
      assetClass: instrument.assetClass,
      strategyId: bestReasoning.strategyId,
      strategyVersion: bestReasoning.strategyVersion,
      direction: bestReasoning.direction,
      regime: regime.regime,
      session: session.status,
      timeframe: '15m',
      strategyScore: bestReasoning.technicalScore,
      atrPct: regime.atrPct,
      riskReward: bestReasoning.riskReward
    });

    const account = this.riskManager.getAccountState();
    const scores = ScoringEngine.computeScores(bestReasoning, similarity, sentiment, account, quote);
    const decisionResult = DecisionEngine.evaluateDecision(instrument, bestReasoning, scores, similarity, sentiment, account);

    const opportunityId = `OPP_${Date.now()}_${instrument.symbol.replace(/[\/\-_]/g, '')}`;

    const opp: QualifiedOpportunity = {
      id: opportunityId,
      timestamp: Date.now(),
      symbol: instrument.symbol,
      assetClass: instrument.assetClass,
      provider: instrument.provider,
      direction: bestReasoning.direction,
      entryPrice: bestReasoning.suggestedEntry,
      stopLoss: bestReasoning.stopLoss,
      takeProfit: bestReasoning.takeProfit,
      takeProfit2: bestReasoning.takeProfit2,
      riskReward: bestReasoning.riskReward,
      timeframe: '15m',
      reasoning: bestReasoning,
      scores,
      decision: decisionResult.decision,
      decisionReason: decisionResult.decisionReason,
      memoryReason: similarity.notes,
      sentimentReason: sentiment.notes,
      baselineDecision: decisionResult.baselineDecision,
      isAdaptiveModified: decisionResult.isAdaptiveModified
    };

    this.experienceStore.recordOpportunity({
      id: opp.id,
      timestamp: opp.timestamp,
      symbol: opp.symbol,
      assetClass: opp.assetClass,
      provider: opp.provider,
      strategyId: opp.reasoning.strategyId,
      strategyVersion: opp.reasoning.strategyVersion,
      direction: opp.direction,
      regime: regime.regime,
      session: session.status,
      timeframe: opp.timeframe,
      strategyScore: scores.strategyScore,
      memoryScore: scores.memoryScore,
      regimeScore: scores.regimeScore,
      sentimentScore: scores.sentimentScore,
      executionScore: scores.executionScore,
      riskScore: scores.riskScore,
      compositeScore: scores.compositeScore,
      entryPrice: opp.entryPrice,
      stopLoss: opp.stopLoss,
      takeProfit: opp.takeProfit,
      plannedRiskReward: opp.riskReward,
      slMethod: 'ATR',
      tpMethod: 'TRAILING',
      atr: regime.atr,
      atrPct: regime.atrPct,
      spreadBps: quote.spreadBps,
      fundingRate: sentiment.fundingRate,
      sentimentValue: sentiment.sentimentScore,
      decision: opp.decision,
      baselineDecision: opp.baselineDecision,
      lifecycleStatus: opp.decision === 'TRADE' ? 'TRADED' : 'REJECTED_BY_SCORE',
      outcomePopulated: false
    });

    return opp;
  }
}
