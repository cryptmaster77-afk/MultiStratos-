import * as http from 'http';
import * as fs from 'fs';
import * as path from 'path';
import * as url from 'url';
import { ApiRouter } from './api.router.js';
import { config } from '../config/index.js';

export class WebServer {
  private server: http.Server;
  private publicDir: string;

  constructor() {
    this.publicDir = path.join(config.paths.rootDir, 'public');
    this.server = http.createServer(async (req, res) => {
      try {
        // 1. Try API Router
        const handled = await ApiRouter.handleRequest(req, res);
        if (handled) return;

        // 2. Serve Static Frontend files
        this.serveStatic(req, res);
      } catch (err: any) {
        console.error('[WebServer] Request error:', err);
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
      }
    });
  }

  private serveStatic(req: http.IncomingMessage, res: http.ServerResponse): void {
    const parsed = url.parse(req.url || '/', true);
    let pathname = parsed.pathname || '/';
    if (pathname === '/') pathname = '/index.html';

    const safePath = path.normalize(path.join(this.publicDir, pathname));
    if (!safePath.startsWith(this.publicDir)) {
      res.writeHead(403);
      res.end('Forbidden');
      return;
    }

    if (!fs.existsSync(safePath)) {
      // Fallback to index.html for SPA
      const indexPath = path.join(this.publicDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        fs.createReadStream(indexPath).pipe(res);
        return;
      }
      res.writeHead(404);
      res.end('Not Found');
      return;
    }

    const ext = path.extname(safePath).toLowerCase();
    const mimeTypes: Record<string, string> = {
      '.html': 'text/html',
      '.css': 'text/css',
      '.js': 'application/javascript',
      '.json': 'application/json',
      '.png': 'image/png',
      '.svg': 'image/svg+xml'
    };

    res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'text/plain' });
    fs.createReadStream(safePath).pipe(res);
  }

  public start(): Promise<void> {
    return new Promise((resolve) => {
      this.server.listen(config.server.port, config.server.host, () => {
        console.log(`\n======================================================`);
        console.log(`🚀 MULTI-ASSET TRADING COMMAND CENTER`);
        console.log(`🌐 Dashboard: http://localhost:${config.server.port}`);
        console.log(`🛡️  Mode:      ${config.systemMode} (Paper Equity: $${config.paper.initialBalance.toFixed(2)})`);
        console.log(`======================================================\n`);
        resolve();
      });
    });
  }

  public stop(): Promise<void> {
    return new Promise((resolve) => {
      this.server.close(() => resolve());
    });
  }
}
