# COMMAND CRYPTO — Multi-Asset Quantitative Trading Command Center

## 1. Overview

**COMMAND CRYPTO** is an autonomous, multi-asset quantitative trading system and command center built for high-reliability, provider-aware market scanning and algorithmic trade execution across **CRYPTO, FOREX, METALS, INDICES, STOCKS, and COMMODITIES**. The system combines multi-timeframe structural analysis, market regime detection, a 10-dimensional statistical trade memory engine with repeated failure suppression, and strict portfolio-level risk controls. By default, the system operates in **PAPER mode** with a $100 starting equity balance and a 0.5% risk cap per trade. **Live execution is currently supported exclusively for CRYPTO (via verified Binance API integrations)** while Forex, Metals, Indices, Stocks, and Commodities operate in Paper mode until institutional brokerage execution adapters (such as OANDA, Interactive Brokers, or TradeStation) are configured with funded live accounts.

---

## 2. Quick Start

Ensure **Node.js (>= v20)** is installed.

```bash
# 1. Install dependencies
npm install

# 2. Run the full automated test suite (54 tests across 12 suites)
npm test

# 3. Start the Command Center in default PAPER mode
npm start
# -> Server running on http://localhost:3000

# 4. (Optional) Run single-pass multi-asset universe scan
npm run scan

# 5. Start in development mode with live reload
npm run dev
```

---

## 3. Going Live (Safety Gates & Protection)

The engine enforces **7 sequential, non-negotiable safety gates** before any live order can be created or routed. If any gate fails, live execution is refused with the exact failure reason and **never silently downgraded to paper mode**:

1. **System Mode Verification Gate**: `SYSTEM_MODE=LIVE` must be explicitly declared in the environment configuration.
2. **Safety Acknowledgement Gate**: `LIVE_SAFETY_ACKNOWLEDGED=true` must be set in `.env` along with the confirmation passphrase.
3. **API Key Authentication Gate**: Authenticated API keys and secret pairs with verified trade permissions must be present.
4. **Account Positive Equity Gate**: Real-time account equity and free margin balance must be strictly $> \$0$.
5. **Daily Loss Circuit Breaker Gate**: Daily drawdown must be strictly below `MAX_DAILY_LOSS_PCT` (default 3.0%). If exceeded, the engine halts trading for the rest of the day.
6. **Emergency Stop Disarmed Gate**: The hardware/software Emergency Stop switch must be disarmed (`emergencyStop: false`).
7. **Asset Class Execution Venue Gate**: The instrument's asset class must have a verified live execution venue (Crypto live execution supported; non-crypto assets remain paper-only).

---

## 4. Configuration

All configuration is centralized and validated at startup:

| Variable | Default | Description |
| :--- | :--- | :--- |
| `SYSTEM_MODE` | `PAPER` | Core mode: `PAPER` (safe simulation) or `LIVE` (real capital execution) |
| `PAPER_INITIAL_BALANCE` | `100.00` | Starting paper portfolio equity balance in USD |
| `MAX_RISK_PER_TRADE_PCT` | `0.5` | Maximum account equity percentage risked per trade (default 0.5% = $0.50) |
| `MAX_DAILY_LOSS_PCT` | `3.0` | Maximum daily loss before autonomous trading halts (default 3.0% = $3.00) |
| `MAX_PORTFOLIO_EXPOSURE_PCT` | `20.0` | Maximum simultaneous open notional exposure cap (default 20.0%) |
| `MAX_CONCURRENT_POSITIONS` | `5` | Maximum number of open concurrent trades |
| `MAX_CORRELATED_EXPOSURE_PCT`| `10.0` | Maximum exposure to a single asset class |
| `DEFAULT_LEVERAGE` | `1` | Default leverage multiplier (supports 1x, 2x, 3x, 5x, 10x) |
| `SCANNER_INTERVAL_MINUTES` | `15` | Autopilot scan cadence |
| `SCANNER_BATCH_SIZE` | `8` | Number of instruments analyzed per scan cycle |
| `SCANNER_REQUEST_DELAY_MS` | `1200` | Inter-request pause to respect provider rate limits |
| `TWELVEDATA_API_KEY` | `""` | TwelveData API Key for Forex/Stocks/Indices/Metals |
| `TWELVEDATA_DAILY_BUDGET` | `800` | Maximum daily API call budget for TwelveData free tier |
| `TWELVEDATA_BURST_PER_MIN` | `8` | Maximum requests permitted per 60-second sliding window |
| `BINANCE_API_KEY` | `""` | Binance API Key (public endpoints used for paper) |
| `BINANCE_API_SECRET` | `""` | Binance API Secret (required only for live crypto orders) |
| `ENABLE_ADAPTIVE_MEMORY` | `true` | Enables 10D setup similarity matching and trade memory |
| `SIMILARITY_THRESHOLD` | `0.72` | Minimum similarity score (0.0 to 1.0) to qualify as a similar historical setup |
| `MIN_SAMPLES_FOR_MEMORY` | `5` | Minimum sample size required before memory alters setup confidence |
| `MEMORY_RECENCY_HALFLIFE_DAYS`| `30` | Exponential decay half-life for historical trade weighting |
| `REPEATED_FAILURE_THRESHOLD`| `3` | Number of consecutive losses triggering repeated failure suppression |
| `TELEGRAM_BOT_TOKEN` | `""` | Telegram Bot Token for alerts |
| `TELEGRAM_CHAT_ID` | `""` | Telegram Chat ID for alerts |
| `PORT` | `3000` | Local HTTP and WebSocket server port |

---

## 5. Asset Class Coverage

| Asset Class | Primary Data Provider | Discovery Universe | Live Trading Status | Example Discovered Symbols |
| :--- | :--- | :--- | :--- | :--- |
| **CRYPTO** | Binance Public / CCXT | Full High-Liquidity Universe (12+ assets) | **LIVE SUPPORTED** | `BTC/USDT`, `ETH/USDT`, `SOL/USDT`, `BNB/USDT`, `XRP/USDT`, `DOGE/USDT` |
| **FOREX** | TwelveData / Interbank | Curated Major & Minor Pairs (10 pairs) | Paper-Only | `EUR/USD`, `GBP/USD`, `USD/JPY`, `AUD/USD`, `USD/CAD`, `EUR/GBP` |
| **METALS** | TwelveData / COMEX | Verified Spot & Tokenized Metals (3 assets) | Paper-Only / PAXG Live | `XAU/USD` (Gold), `XAG/USD` (Silver), `PAXG/USDT` |
| **INDICES** | TwelveData / CBOE | Benchmark Equity Indices (4 assets) | Paper-Only | `SPX` (S&P 500), `NDX` (Nasdaq 100), `DJI` (Dow), `DAX` |
| **STOCKS** | TwelveData / NASDAQ | Megacap US Equities (6 assets) | Paper-Only | `AAPL`, `NVDA`, `MSFT`, `TSLA`, `AMZN`, `GOOGL` |
| **COMMODITIES**| TwelveData / NYMEX | Energy Benchmarks (2 assets) | Paper-Only | `USOIL` (WTI Crude), `NATGAS` (Natural Gas) |

---

## 6. Notifications & Alerts

The built-in `NotificationDispatcher` routes structured alerts to **Telegram** and **Webhooks** with automatic deduplication and throttling:
- **Alert Triggers**:
  - `OPPORTUNITY`: Qualified setups with composite score $\ge 75$
  - `TRADE_OPEN`: Position executed with entry price, size, stop loss, and target
  - `TRADE_CLOSE`: Position exited with realized PnL, realized R, exit reason, and autopsy diagnosis
  - `RISK_ALERT`: Account drawdown $> 2.0\%$ or portfolio exposure warning
  - `EMERGENCY`: Emergency stop activated / immediate trade freeze
- **Throttling**: Alerts on identical symbols/levels are throttled to once every 60 seconds (`NOTIFICATION_THROTTLE_SECONDS`) to eliminate notification spam.

---

## 7. Autopilot & Quota Arithmetic

Autopilot runs unattended market discovery and active trade management:
- **Default Scan Interval**: 15 minutes (`SCANNER_INTERVAL_MINUTES=15`).
- **Quota Mathematical Breakdown**:
  - TwelveData free tier budget: **800 requests/day**, **8 requests/minute**.
  - With a batch size of 8 instruments scanned every 15 minutes: $4\text{ scans/hour} \times 24\text{ hours} = 96\text{ batches/day}$.
  - Each batch consumes at most 8 API calls $\implies 96 \times 8 = 768\text{ requests/day}$.
  - $768 < 800$, operating safely at **96% of daily quota** with zero budget exhaustion.
  - Timeframe-aware caching (e.g., 15m candle TTL = 8 minutes, 1h candle TTL = 30 minutes) eliminates redundant queries.
- **Fault-Tolerance**: If an API request times out or returns a rate-limit error, the engine backs off exponentially and falls back to deterministic local mock feeds without interrupting the scanner loop.

---

## 8. Adaptive Trade Memory & Statistical Intelligence

Rather than treating every trade as an isolated event or utilizing an opaque neural black box, COMMAND CRYPTO utilizes a **deterministic 10-dimensional statistical similarity engine**:

1. **Dimensional Breakdown**:
   - Strategy Type & Version (exact)
   - Direction (`BUY` / `SELL`)
   - Asset Class & Ticker
   - Market Regime (Trending Bull, Trending Bear, Ranging, Expansion, Contraction)
   - Volatility State (ATR% bucket)
   - Technical Score bucket
   - Risk/Reward bucket
   - Market Session state
   - Exponential Recency Weighting ($\lambda = 30\text{ days}$)

2. **Sample-Size Gating (Zero Hallucination)**:
   - If historical sample size $N < 5$, memory score defaults to neutral (50/100) with flag `INSUFFICIENT_DATA` — preserving standard strategy confidence without fabricating false certainty.

3. **Repeated Failure Suppression**:
   - If $\ge 3$ consecutive historical setups failed under identical regime and direction conditions, confidence is dampened by 50% and decision is downgraded from `TRADE` to `WAIT (CONFIRMATION REQUIRED)`.

4. **Automated Post-Trade Autopsy**:
   - Analyzes Maximum Adverse Excursion (MAE), Maximum Favorable Excursion (MFE), stop loss tightness, and target realism to continually refine parameter recommendations.

---

## 9. Honest Limitations & Gaps in this Pass

1. **Non-Crypto Live Execution Adapters**: Live order execution is active only for Crypto via Binance API. Forex, Equities, and Indices are paper-traded via TwelveData quotes. Direct FIX/REST live execution for Forex/Stocks requires connecting an institutional broker API (such as Interactive Brokers TWS or OANDA v20).
2. **Sentiment Source Coverage**: Free sentiment data utilizes the Alternative.me Fear & Greed API and macro baselines. Premium news feeds (e.g. Bloomberg Terminal or FinancialJuice Webhooks) require paid commercial API keys.
3. **Historical Data Depth on Free Tiers**: TwelveData free accounts provide up to 500 historical bars per request; deep multi-year backtesting requires historical data imports or a pro data subscription.

---

## 10. Prioritized Next Steps

1. **Broker Adapter Integrations**: Implement OANDA v20 REST API for live Forex execution and Alpaca / Interactive Brokers for US Equities and Indices.
2. **WebSocket Live Streaming Feeds**: Add direct Binance and TwelveData WebSocket streaming for sub-second quote updates on active positions.
3. **Advanced Machine Learning Regimes**: Introduce Hidden Markov Models (HMM) for automated multi-state market regime clustering.
