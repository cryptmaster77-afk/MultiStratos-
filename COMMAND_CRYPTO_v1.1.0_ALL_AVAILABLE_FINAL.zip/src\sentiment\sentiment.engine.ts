import { AssetClass } from '../types/market.js';
import { SentimentSnapshot } from './sentiment.types.js';

export { SentimentSnapshot };

export class SentimentEngine {
  private static instance: SentimentEngine;
  private cache = new Map<string, SentimentSnapshot>();

  private constructor() {}

  public static getInstance(): SentimentEngine {
    if (!this.instance) {
      this.instance = new SentimentEngine();
    }
    return this.instance;
  }

  public async getSentiment(symbol: string, assetClass: AssetClass): Promise<SentimentSnapshot> {
    const key = `${assetClass}:${symbol}`;
    const cached = this.cache.get(key);

    if (cached && (Date.now() - cached.timestamp) < cached.ttlMs) {
      return cached;
    }

    try {
      if (assetClass === 'CRYPTO') {
        // Fetch Fear & Greed index from alternative.me (public, free)
        const res = await fetch('https://api.alternative.me/fng/?limit=1');
        if (res.ok) {
          const data = await res.json() as any;
          const val = parseInt(data.data[0].value, 10);
          const classification = data.data[0].value_classification.toUpperCase();
          
          let label: 'EXTREME_FEAR' | 'FEAR' | 'NEUTRAL' | 'GREED' | 'EXTREME_GREED' = 'NEUTRAL';
          if (val <= 25) label = 'EXTREME_FEAR';
          else if (val <= 45) label = 'FEAR';
          else if (val <= 55) label = 'NEUTRAL';
          else if (val <= 75) label = 'GREED';
          else label = 'EXTREME_GREED';

          const snapshot: SentimentSnapshot = {
            source: 'Alternative.me Fear & Greed API',
            assetClass: 'CRYPTO',
            symbol,
            sentimentScore: val,
            sentimentLabel: label,
            fundingRate: 0.0001, // Neutral default
            confidence: 85,
            timestamp: Date.now(),
            ttlMs: 30 * 60 * 1000, // 30 min cache
            isStale: false,
            notes: `Crypto sentiment index: ${val}/100 (${classification})`
          };

          this.cache.set(key, snapshot);
          return snapshot;
        }
      }
    } catch (err) {
      // Graceful fallback to neutral sentiment
    }

    // Default neutral context snapshot
    const fallback: SentimentSnapshot = {
      source: 'Macro Neutral Context Baseline',
      assetClass,
      symbol,
      sentimentScore: 50,
      sentimentLabel: 'NEUTRAL',
      fundingRate: 0,
      confidence: 70,
      timestamp: Date.now(),
      ttlMs: 30 * 60 * 1000,
      isStale: false,
      notes: 'Balanced macro sentiment'
    };

    this.cache.set(key, fallback);
    return fallback;
  }
}
