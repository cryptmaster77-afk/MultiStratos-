import { AssetClass, MarketRegimeType, Timeframe } from './market.js';

export type SignalDirection = 'BUY' | 'SELL' | 'NEUTRAL';

export type DecisionAction = 
  | 'TRADE'
  | 'WAIT'
  | 'REQUIRE_CONFIRMATION'
  | 'REDUCE_CONFIDENCE'
  | 'REJECT';

export interface StrategyCondition {
  name: string;
  expected: string;
  actual: string;
  satisfied: boolean;
  weight: number;
}

export interface StrategyReasoning {
  strategyId: string;
  strategyName: string;
  strategyVersion: string;
  direction: SignalDirection;
  setupQuality: 'A+' | 'A' | 'B' | 'C' | 'INVALID';
  technicalScore: number;           // 0 - 100
  conditionsSatisfied: StrategyCondition[];
  conditionsFailed: StrategyCondition[];
  suggestedEntry: number;
  stopLoss: number;
  takeProfit: number;
  takeProfit2?: number;
  invalidationPrice: number;
  riskReward: number;
  timeframeContext: {
    higherTrend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    mediumStructure: 'BREAKOUT' | 'PULLBACK' | 'RANGE' | 'EXPANSION' | 'CONSOLIDATION';
    lowerTrigger: 'CONFIRMED' | 'PENDING' | 'INVALIDATED';
  };
  regimeCompatibility: {
    currentRegime: MarketRegimeType;
    isCompatible: boolean;
    compatibilityScore: number;     // 0 - 100
    notes: string;
  };
}

export interface MultiFactorScore {
  strategyScore: number;       // 0 - 100: Raw technical signal quality
  memoryScore: number;         // 0 - 100: Historical similarity performance
  regimeScore: number;         // 0 - 100: Regime suitability
  sentimentScore: number;      // 0 - 100: Contextual sentiment confirmation
  executionScore: number;      // 0 - 100: Spread, liquidity, estimated slippage
  riskScore: number;           // 0 - 100: Portfolio risk headroom & drawdown health
  compositeScore: number;      // 0 - 100: Weighted synthesis
  confidencePct: number;       // Final confidence percentage
}

export interface QualifiedOpportunity {
  id: string;
  timestamp: number;
  symbol: string;
  assetClass: AssetClass;
  provider: string;
  direction: SignalDirection;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  takeProfit2?: number;
  riskReward: number;
  timeframe: Timeframe;
  reasoning: StrategyReasoning;
  scores: MultiFactorScore;
  decision: DecisionAction;
  decisionReason: string;
  memoryReason?: string;
  sentimentReason?: string;
  riskReason?: string;
  baselineDecision: DecisionAction; // What raw strategy would have done
  isAdaptiveModified: boolean;
}
