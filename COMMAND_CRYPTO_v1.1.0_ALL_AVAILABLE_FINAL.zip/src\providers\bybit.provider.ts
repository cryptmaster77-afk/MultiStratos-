import { AssetClass, Candle, Instrument, Quote, Timeframe } from '../types/market.js';
import { ProviderCapability } from '../types/provider.js';
import { BaseMarketDataProvider } from './base.provider.js';
import { QuotaManager } from './quota.manager.js';
import { MarketDiscoveryService } from '../market/discovery.js';

export class BybitMarketDataProvider extends BaseMarketDataProvider {
  public readonly name = 'bybit';
  public readonly capabilities: ProviderCapability = {
    supportedAssetClasses: ['CRYPTO'],
    supportsWebSockets: true,
    supportsHistoricalCandles: true,
    supportsRealtimeQuotes: true,
    supportsOrderExecution: true,
    maxCandleLimit: 1000
  };

  private baseUrl = 'https://api.bybit.com/v5';
  private apiKey?: string;
  private apiSecret?: string;

  constructor(apiKey?: string, apiSecret?: string) {
    super();
    this.apiKey = apiKey;
    this.apiSecret = apiSecret;
    this.quotaManager = QuotaManager.getInstance({
      providerName: this.name,
      dailyBudget: 100000,          // Bybit public rate limit (120 req/sec)
      burstLimitPerMinute: 600
    });
  }

  private normalizeInterval(timeframe: Timeframe): string {
    switch (timeframe) {
      case '1m': return '1';
      case '5m': return '5';
      case '15m': return '15';
      case '30m': return '30';
      case '1h': return '60';
      case '4h': return '240';
      case '1d': return 'D';
      case '1w': return 'W';
      default: return '15';
    }
  }

  private formatSymbol(symbol: string): string {
    return symbol.replace(/[\/\-_]/g, '').toUpperCase();
  }

  public async discoverMarkets(assetClasses?: AssetClass[]): Promise<Instrument[]> {
    if (assetClasses && !assetClasses.includes('CRYPTO') && !assetClasses.includes('METALS')) {
      return [];
    }

    try {
      const res = await fetch(`${this.baseUrl}/market/instruments-info?category=spot`);
      if (res.ok) {
        const data = await res.json() as any;
        if (data.retCode === 0 && Array.isArray(data.result?.list) && data.result.list.length > 0) {
          const discovered: Instrument[] = [];
          for (const item of data.result.list) {
            if (item.status !== 'Trading') continue;
            // Focus on liquid USDT / USDC pairs
            const quote = item.quoteCoin?.toUpperCase();
            if (quote !== 'USDT' && quote !== 'USDC') continue;

            const base = item.baseCoin?.toUpperCase();
            const rawSymbol = item.symbol;
            const isMetal = base === 'PAXG' || base === 'XAUT';
            const assetClass: AssetClass = isMetal ? 'METALS' : 'CRYPTO';

            if (assetClasses && !assetClasses.includes(assetClass)) continue;

            const tick = parseFloat(item.priceFilter?.tickSize || '0.01');
            const lot = parseFloat(item.lotSizeFilter?.minOrderQty || '0.001');
            const minAmt = parseFloat(item.lotSizeFilter?.minOrderAmt || '5.0');

            discovered.push({
              symbol: `${base}/${quote}`,
              rawSymbol,
              displayName: `${base}/${quote} (Bybit ${assetClass})`,
              assetClass,
              provider: 'bybit',
              exchange: 'Bybit',
              baseAsset: base,
              quoteAsset: quote,
              tickSize: isNaN(tick) ? 0.01 : tick,
              lotSize: isNaN(lot) ? 0.001 : lot,
              minNotional: isNaN(minAmt) ? 5.0 : minAmt,
              supportedTimeframes: ['5m', '15m', '1h', '4h', '1d'],
              marketHours: {
                timezone: 'UTC',
                is24x7: true,
                openUtcHour: 0,
                openUtcMinute: 0,
                closeUtcHour: 23,
                closeUtcMinute: 59,
                tradingDays: [0, 1, 2, 3, 4, 5, 6]
              },
              sessionStatus: 'OPEN',
              dataQuality: 'EXCELLENT',
              lastUpdated: Date.now(),
              isLiveSupported: true,
              notes: 'Continuous 24/7 Spot Market Feeds'
            });
          }

          if (discovered.length > 0) {
            return discovered;
          }
        }
      }
    } catch (err: any) {
      console.warn(`[BybitProvider] Live dynamic discovery failed (${err.message}). Using catalog baseline.`);
    }

    // Resilient fallback to catalog universe
    const universe = MarketDiscoveryService.getUniverse(assetClasses);
    return universe.filter(inst => inst.provider === 'bybit');
  }

  public async getQuote(symbol: string, assetClass: AssetClass = 'CRYPTO'): Promise<Quote> {
    const cleanSymbol = this.formatSymbol(symbol);

    // Check Cache
    const cached = this.cacheManager.getQuote(this.name, cleanSymbol);
    if (cached) return cached;

    // Check Quota
    const quotaCheck = this.quotaManager.canMakeRequest('STANDARD_SCAN');
    if (!quotaCheck.allowed) {
      throw new Error(`Bybit quota limit reached: ${quotaCheck.reason}`);
    }

    try {
      this.quotaManager.recordRequest();
      const res = await fetch(`${this.baseUrl}/market/tickers?category=spot&symbol=${cleanSymbol}`);
      if (!res.ok) {
        throw new Error(`Bybit API HTTP ${res.status}: ${res.statusText}`);
      }

      const data = await res.json() as any;
      if (data.retCode !== 0 || !data.result?.list?.[0]) {
        throw new Error(`Bybit API error: ${data.retMsg || 'No ticker data'}`);
      }

      const ticker = data.result.list[0];
      const bid = parseFloat(ticker.bid1Price || ticker.lastPrice);
      const ask = parseFloat(ticker.ask1Price || ticker.lastPrice);
      const last = parseFloat(ticker.lastPrice);
      const spread = Math.max(0, ask - bid);
      const spreadBps = last > 0 ? (spread / last) * 10000 : 0;

      const quote: Quote = {
        symbol,
        bid,
        ask,
        last,
        spread,
        spreadBps,
        timestamp: Date.now()
      };

      this.cacheManager.setQuote(this.name, cleanSymbol, quote, 15000);
      return quote;
    } catch (err: any) {
      this.quotaManager.recordError(err.message || 'Bybit quote fetch failed');
      throw new Error(`Bybit quote failed for ${symbol}: ${err.message}`);
    }
  }

  public async getCandles(symbol: string, timeframe: Timeframe, limit: number = 100, assetClass: AssetClass = 'CRYPTO'): Promise<Candle[]> {
    const cleanSymbol = this.formatSymbol(symbol);

    // Check Cache
    const cached = this.cacheManager.getCandles(this.name, cleanSymbol, timeframe);
    if (cached && cached.length >= limit) {
      return cached.slice(-limit);
    }

    // Check Quota
    const quotaCheck = this.quotaManager.canMakeRequest('STANDARD_SCAN');
    if (!quotaCheck.allowed) {
      if (cached) return cached;
      throw new Error(`Bybit quota limit reached: ${quotaCheck.reason}`);
    }

    try {
      this.quotaManager.recordRequest();
      const interval = this.normalizeInterval(timeframe);
      const res = await fetch(`${this.baseUrl}/market/kline?category=spot&symbol=${cleanSymbol}&interval=${interval}&limit=${Math.min(limit, 200)}`);
      
      if (!res.ok) {
        throw new Error(`Bybit klines HTTP ${res.status}: ${res.statusText}`);
      }

      const data = await res.json() as any;
      if (data.retCode !== 0 || !data.result?.list) {
        throw new Error(`Bybit API error: ${data.retMsg || 'No klines returned'}`);
      }

      // Bybit returns list formatted as: [startTime, openPrice, highPrice, lowPrice, closePrice, volume, turnover]
      // List is returned with newest first, so we reverse it to chronological order (oldest first)
      const rawList: any[] = data.result.list;
      const candles: Candle[] = rawList.map(item => ({
        timestamp: parseInt(item[0], 10),
        open: parseFloat(item[1]),
        high: parseFloat(item[2]),
        low: parseFloat(item[3]),
        close: parseFloat(item[4]),
        volume: parseFloat(item[5])
      })).reverse();

      this.cacheManager.setCandles(this.name, cleanSymbol, timeframe, candles);
      return candles;
    } catch (err: any) {
      this.quotaManager.recordError(err.message || 'Bybit candles fetch failed');
      if (cached) return cached;
      throw new Error(`Bybit candles failed for ${symbol} (${timeframe}): ${err.message}`);
    }
  }
}
