import { Candle } from '../types/market.js';
import { TrendFollowingStrategy } from '../strategies/trend.following.js';
import { RegimeDetector } from '../analysis/regime.detector.js';
import { MultiTimeframeAnalyzer } from '../analysis/mtf.analyzer.js';
import { MarketDiscoveryService } from '../market/discovery.js';

export interface WalkForwardResult {
  inSampleTrades: number;
  inSampleWinRate: number;
  inSampleExpectancyR: number;
  outOfSampleTrades: number;
  outOfSampleWinRate: number;
  outOfSampleExpectancyR: number;
  antiLeakageVerified: boolean;
  recommendationValid: boolean;
  notes: string;
}

export class ChronologicalWalkForwardEngine {
  /**
   * Executes chronological validation without data leakage.
   * Splits candles strictly in temporal order: First 70% = In-Sample Training, Last 30% = Out-of-Sample Validation.
   */
  public static validate(candles: Candle[], strategyName: string = 'TrendFollowing'): WalkForwardResult {
    if (candles.length < 50) {
      return {
        inSampleTrades: 0,
        inSampleWinRate: 0,
        inSampleExpectancyR: 0,
        outOfSampleTrades: 0,
        outOfSampleWinRate: 0,
        outOfSampleExpectancyR: 0,
        antiLeakageVerified: true,
        recommendationValid: false,
        notes: 'Insufficient candle series for walk-forward validation'
      };
    }

    // Strict chronological split
    const splitIndex = Math.floor(candles.length * 0.70);
    const inSampleCandles = candles.slice(0, splitIndex);
    const outOfSampleCandles = candles.slice(splitIndex);

    // Verify chronological integrity (no timestamps in out-of-sample <= in-sample)
    const maxInSampleTime = inSampleCandles[inSampleCandles.length - 1].timestamp;
    const minOutOfSampleTime = outOfSampleCandles[0].timestamp;
    const antiLeakageVerified = minOutOfSampleTime > maxInSampleTime;

    const runSimulation = (sample: Candle[]) => {
      let trades = 0;
      let wins = 0;
      let totalR = 0;
      const strategy = new TrendFollowingStrategy();
      const inst = MarketDiscoveryService.getUniverse()[0];

      for (let i = 30; i < sample.length - 5; i++) {
        const window = sample.slice(0, i + 1);
        const regime = RegimeDetector.detect(window);
        const mtf = MultiTimeframeAnalyzer.analyze(inst.symbol, window, window, window);
        const reasoning = strategy.evaluate(inst, window, regime, mtf);

        if (reasoning.direction !== 'NEUTRAL' && reasoning.setupQuality !== 'INVALID') {
          trades++;
          // Simulate trade outcome over next 5 candles
          const futureCandles = sample.slice(i + 1, i + 6);
          let exited = false;
          let r = -1.0; // Default SL

          for (const fc of futureCandles) {
            if (reasoning.direction === 'BUY') {
              if (fc.high >= reasoning.takeProfit) {
                r = reasoning.riskReward;
                exited = true;
                break;
              } else if (fc.low <= reasoning.stopLoss) {
                r = -1.0;
                exited = true;
                break;
              }
            } else {
              if (fc.low <= reasoning.takeProfit) {
                r = reasoning.riskReward;
                exited = true;
                break;
              } else if (fc.high >= reasoning.stopLoss) {
                r = -1.0;
                exited = true;
                break;
              }
            }
          }

          if (r > 0) wins++;
          totalR += r;
        }
      }

      return {
        trades,
        winRate: trades > 0 ? (wins / trades) * 100 : 0,
        expectancyR: trades > 0 ? totalR / trades : 0
      };
    };

    const inSample = runSimulation(inSampleCandles);
    const outOfSample = runSimulation(outOfSampleCandles);

    const recommendationValid = antiLeakageVerified && outOfSample.expectancyR > 0;

    return {
      inSampleTrades: inSample.trades,
      inSampleWinRate: inSample.winRate,
      inSampleExpectancyR: inSample.expectancyR,
      outOfSampleTrades: outOfSample.trades,
      outOfSampleWinRate: outOfSample.winRate,
      outOfSampleExpectancyR: outOfSample.expectancyR,
      antiLeakageVerified,
      recommendationValid,
      notes: recommendationValid 
        ? 'Walk-forward test passed out-of-sample positive expectancy.'
        : 'Out-of-sample performance failed threshold or insufficient trades.'
    };
  }
}
