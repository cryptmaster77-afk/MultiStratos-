import { Instrument, Quote } from '../types/market.js';
import { QualifiedOpportunity } from '../types/strategy.js';
import { Position } from '../types/risk.js';
import { RiskManager } from '../risk/risk.manager.js';
import { PositionManager } from './position.manager.js';
import { PositionSizer } from '../risk/position.sizer.js';
import { PortfolioRiskEngine } from '../risk/portfolio.risk.js';
import { LiveGateValidator } from '../risk/live.gate.js';
import { config } from '../config/index.js';
import { ASSET_CLASS_CONFIG } from '../config/constants.js';

export class ExecutionEngine {
  private static instance: ExecutionEngine;
  private riskManager = RiskManager.getInstance();
  private positionManager = PositionManager.getInstance();

  private constructor() {}

  public static getInstance(): ExecutionEngine {
    if (!this.instance) {
      this.instance = new ExecutionEngine();
    }
    return this.instance;
  }

  /**
   * Executes a qualified trade opportunity under strict risk controls and simulated/live safety gates.
   */
  public async executeOpportunity(
    opportunity: QualifiedOpportunity,
    instrument: Instrument,
    quote: Quote
  ): Promise<{
    success: boolean;
    position?: Position;
    error?: string;
  }> {
    const account = this.riskManager.getAccountState();

    // 1. Check Opportunity Decision
    if (opportunity.decision !== 'TRADE') {
      return {
        success: false,
        error: `Cannot execute opportunity: Decision is ${opportunity.decision} (${opportunity.decisionReason})`
      };
    }

    // 2. LIVE Mode Safety Gate Check
    if (config.systemMode === 'LIVE') {
      const gateValidation = LiveGateValidator.validate(instrument, account);
      if (!gateValidation.isPassed) {
        return {
          success: false,
          error: `Live Execution Refused by Safety Gates: ${gateValidation.rejectionReasons.join(' | ')}`
        };
      }
    }

    // 3. Position Sizing
    const sizeResult = PositionSizer.calculateSize(
      instrument,
      opportunity.entryPrice,
      opportunity.stopLoss,
      account,
      config.risk.defaultLeverage
    );

    if (!sizeResult.allowed) {
      return {
        success: false,
        error: `Position sizing rejected: ${sizeResult.rejectReason}`
      };
    }

    // 4. Portfolio Capacity & Correlated Exposure Check
    const openPositions = this.positionManager.getOpenPositions();
    const capacityCheck = PortfolioRiskEngine.validatePortfolioCapacity(
      opportunity.assetClass,
      sizeResult.notionalValue,
      openPositions,
      account
    );

    if (!capacityCheck.allowed) {
      return {
        success: false,
        error: `Portfolio risk limit reached: ${capacityCheck.reason}`
      };
    }

    // 5. Simulate Realistic Execution Pricing (Slippage + Fees)
    const slippageBps = config.paper.slippageBps || 3;
    const slippageMultiplier = opportunity.direction === 'BUY' ? (1 + slippageBps / 10000) : (1 - slippageBps / 10000);
    const executedEntryPrice = opportunity.entryPrice * slippageMultiplier;
    const feeBps = config.paper.feeBps || 5;
    const initialFee = sizeResult.notionalValue * (feeBps / 10000);

    const positionId = `POS_${Date.now()}_${instrument.symbol.replace(/[\/\-_]/g, '')}`;

    const position: Position = {
      id: positionId,
      symbol: instrument.symbol,
      assetClass: opportunity.assetClass,
      provider: opportunity.provider,
      direction: opportunity.direction,
      mode: config.systemMode,
      status: 'OPEN',
      entryPrice: executedEntryPrice,
      currentPrice: executedEntryPrice,
      stopLoss: opportunity.stopLoss,
      initialStopLoss: opportunity.stopLoss,
      takeProfit: opportunity.takeProfit,
      takeProfit2: opportunity.takeProfit2,
      sizeUnits: sizeResult.sizeUnits,
      notionalValue: sizeResult.notionalValue,
      leverage: sizeResult.leverage,
      margin: sizeResult.marginRequired,
      unrealizedPnl: -initialFee,
      unrealizedPnlPct: -(initialFee / sizeResult.notionalValue) * 100,
      unrealizedR: 0,
      realizedPnl: 0,
      feesPaid: initialFee,
      trailingStopActive: false,
      highestPriceSinceEntry: executedEntryPrice,
      lowestPriceSinceEntry: executedEntryPrice,
      mae: 0,
      mfe: 0,
      strategyId: opportunity.reasoning.strategyId,
      strategyVersion: opportunity.reasoning.strategyVersion,
      opportunityId: opportunity.id,
      openedAt: Date.now()
    };

    this.positionManager.addPosition(position);

    return {
      success: true,
      position
    };
  }
}
