import { Candle, Instrument, MarketRegime } from '../types/market.js';
import { MTFAnalysisResult } from '../analysis/mtf.analyzer.js';
import { StrategyReasoning } from '../types/strategy.js';

export interface IStrategy {
  readonly id: string;
  readonly name: string;
  readonly version: string;
  readonly description: string;
  
  evaluate(
    instrument: Instrument,
    candles: Candle[],
    regime: MarketRegime,
    mtf: MTFAnalysisResult
  ): StrategyReasoning;
}
