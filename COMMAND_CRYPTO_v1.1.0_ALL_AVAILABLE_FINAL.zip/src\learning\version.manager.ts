import * as fs from 'fs';
import * as path from 'path';
import { config } from '../config/index.js';

export interface LearningVersion {
  versionId: string;
  strategyId: string;
  parameterName: string;
  baselineValue: number | string;
  proposedValue: number | string;
  justification: string;
  walkForwardExpectancyR: number;
  status: 'PROPOSED' | 'APPROVED' | 'DEPLOYED' | 'ROLLED_BACK';
  createdAt: number;
  deployedAt?: number;
}

export class LearningVersionManager {
  private static instance: LearningVersionManager;
  private filePath: string;
  private versions: LearningVersion[] = [];

  private constructor() {
    this.filePath = path.join(config.paths.learningDir, 'learning_versions.json');
    this.ensureDirectory();
    this.load();
  }

  public static getInstance(): LearningVersionManager {
    if (!this.instance) {
      this.instance = new LearningVersionManager();
    }
    return this.instance;
  }

  private ensureDirectory(): void {
    if (!fs.existsSync(config.paths.learningDir)) {
      fs.mkdirSync(config.paths.learningDir, { recursive: true });
    }
  }

  private load(): void {
    try {
      if (fs.existsSync(this.filePath)) {
        this.versions = JSON.parse(fs.readFileSync(this.filePath, 'utf-8'));
      }
    } catch (err) {
      console.warn('[LearningVersionManager] Fresh learning versions store created.');
    }
  }

  private save(): void {
    try {
      this.ensureDirectory();
      const temp = `${this.filePath}.tmp`;
      fs.writeFileSync(temp, JSON.stringify(this.versions, null, 2), 'utf-8');
      fs.renameSync(temp, this.filePath);
    } catch (err) {
      console.error('[LearningVersionManager] Error saving versions:', err);
    }
  }

  public proposeVersion(proposal: Omit<LearningVersion, 'versionId' | 'status' | 'createdAt'>): LearningVersion {
    const version: LearningVersion = {
      ...proposal,
      versionId: `V_${Date.now()}`,
      status: 'PROPOSED',
      createdAt: Date.now()
    };
    this.versions.unshift(version);
    this.save();
    return version;
  }

  public approveAndDeploy(versionId: string): boolean {
    const v = this.versions.find(ver => ver.versionId === versionId);
    if (v) {
      v.status = 'DEPLOYED';
      v.deployedAt = Date.now();
      this.save();
      return true;
    }
    return false;
  }

  public rollback(versionId: string): boolean {
    const v = this.versions.find(ver => ver.versionId === versionId);
    if (v) {
      v.status = 'ROLLED_BACK';
      this.save();
      return true;
    }
    return false;
  }

  public getAllVersions(): LearningVersion[] {
    return [...this.versions];
  }
}
