import { Candle, Instrument, MarketRegime } from '../types/market.js';
import { MTFAnalysisResult } from '../analysis/mtf.analyzer.js';
import { StrategyCondition, StrategyReasoning } from '../types/strategy.js';
import { IStrategy } from './base.strategy.js';
import { TechnicalIndicators } from '../analysis/indicators.js';

export class VolatilityBreakoutStrategy implements IStrategy {
  public readonly id = 'STRAT_BREAKOUT';
  public readonly name = 'Volatility Squeeze & ATR Breakout';
  public readonly version = '1.1.0';
  public readonly description = 'Captures explosive breakouts following Bollinger Band compression / squeeze';

  public evaluate(
    instrument: Instrument,
    candles: Candle[],
    regime: MarketRegime,
    mtf: MTFAnalysisResult
  ): StrategyReasoning {
    const closes = candles.map(c => c.close);
    const lastClose = closes[closes.length - 1];
    const atrSeries = TechnicalIndicators.atr(candles, 14);
    const atr = atrSeries[atrSeries.length - 1] || (lastClose * 0.01);

    const bb = TechnicalIndicators.bollingerBands(closes, 20, 2.0);
    const lastBw = bb.bandwidth[bb.bandwidth.length - 1] || 2.0;
    const lastUpper = bb.upper[bb.upper.length - 1] || lastClose;
    const lastLower = bb.lower[bb.lower.length - 1] || lastClose;

    const conditionsSatisfied: StrategyCondition[] = [];
    const conditionsFailed: StrategyCondition[] = [];

    // Condition 1: Expansion or Contraction Regime
    const isExpanding = regime.regime === 'EXPANSION' || regime.volatilityState === 'EXPANDING' || regime.regime === 'CONTRACTION';
    if (isExpanding) {
      conditionsSatisfied.push({
        name: 'Volatility Regime Alignment',
        expected: 'EXPANSION or CONTRACTION',
        actual: regime.regime,
        satisfied: true,
        weight: 35
      });
    } else {
      conditionsFailed.push({
        name: 'Volatility Regime Alignment',
        expected: 'EXPANSION or CONTRACTION',
        actual: regime.regime,
        satisfied: false,
        weight: 35
      });
    }

    // Condition 2: Breakout of Bollinger Band Boundary
    const isBullBreakout = lastClose > lastUpper && mtf.lowerTimeframe.volumeMultiplier >= 1.2;
    const isBearBreakout = lastClose < lastLower && mtf.lowerTimeframe.volumeMultiplier >= 1.2;

    if (isBullBreakout || isBearBreakout) {
      conditionsSatisfied.push({
        name: 'Price & Volume Breakout',
        expected: 'Close outside 2.0-stddev band with volume >= 1.2x',
        actual: `Vol: ${mtf.lowerTimeframe.volumeMultiplier.toFixed(2)}x, %B: ${(bb.percentB[bb.percentB.length - 1] * 100).toFixed(1)}%`,
        satisfied: true,
        weight: 40
      });
    } else {
      conditionsFailed.push({
        name: 'Price & Volume Breakout',
        expected: 'Close outside 2.0-stddev band with volume >= 1.2x',
        actual: `Vol: ${mtf.lowerTimeframe.volumeMultiplier.toFixed(2)}x`,
        satisfied: false,
        weight: 40
      });
    }

    // Condition 3: Multi-Timeframe Alignment
    const isAligned = (isBullBreakout && mtf.higherTimeframe.trend !== 'BEARISH') || (isBearBreakout && mtf.higherTimeframe.trend !== 'BULLISH');
    if (isAligned) {
      conditionsSatisfied.push({
        name: 'HTF Trend Non-Conflict',
        expected: 'No direct HTF counter-trend',
        actual: mtf.higherTimeframe.trend,
        satisfied: true,
        weight: 25
      });
    } else {
      conditionsFailed.push({
        name: 'HTF Trend Non-Conflict',
        expected: 'No direct HTF counter-trend',
        actual: mtf.higherTimeframe.trend,
        satisfied: false,
        weight: 25
      });
    }

    const direction = isBullBreakout ? 'BUY' : isBearBreakout ? 'SELL' : 'NEUTRAL';
    const stopDistance = atr * 1.5;
    const targetDistance = atr * 3.5; // 1:2.33 R:R for breakouts

    const stopLoss = direction === 'BUY' ? lastClose - stopDistance : direction === 'SELL' ? lastClose + stopDistance : lastClose * 0.98;
    const takeProfit = direction === 'BUY' ? lastClose + targetDistance : direction === 'SELL' ? lastClose - targetDistance : lastClose * 1.05;
    const invalidationPrice = direction === 'BUY' ? lastClose - stopDistance * 1.2 : lastClose + stopDistance * 1.2;
    const riskReward = stopDistance > 0 ? targetDistance / stopDistance : 2.33;

    const totalWeightSatisfied = conditionsSatisfied.reduce((acc, c) => acc + c.weight, 0);
    const technicalScore = Math.min(100, Math.max(0, totalWeightSatisfied));

    let setupQuality: 'A+' | 'A' | 'B' | 'C' | 'INVALID' = 'INVALID';
    if (technicalScore >= 90) setupQuality = 'A+';
    else if (technicalScore >= 75) setupQuality = 'A';
    else if (technicalScore >= 55) setupQuality = 'B';
    else if (technicalScore >= 35) setupQuality = 'C';

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      direction,
      setupQuality,
      technicalScore,
      conditionsSatisfied,
      conditionsFailed,
      suggestedEntry: lastClose,
      stopLoss,
      takeProfit,
      invalidationPrice,
      riskReward,
      timeframeContext: {
        higherTrend: mtf.higherTimeframe.trend,
        mediumStructure: mtf.mediumTimeframe.structure,
        lowerTrigger: mtf.lowerTimeframe.trigger
      },
      regimeCompatibility: {
        currentRegime: regime.regime,
        isCompatible: isExpanding,
        compatibilityScore: isExpanding ? 95 : 30,
        notes: isExpanding ? 'High momentum expansion regime' : 'Low breakout follow-through regime'
      }
    };
  }
}
