import { AccountState, Position, PositionExitReason } from '../types/risk.js';
import { config } from '../config/index.js';
import { RISK_LIMITS } from '../config/constants.js';

export class RiskManager {
  private static instance: RiskManager;
  private account: AccountState;
  private lastResetDay: number = new Date().getUTCDate();

  private constructor() {
    const initialBal = config.paper.initialBalance;
    this.account = {
      mode: config.systemMode,
      currency: 'USD',
      initialBalance: initialBal,
      balance: initialBal,
      equity: initialBal,
      unrealizedPnl: 0,
      realizedPnl: 0,
      dailyStartingEquity: initialBal,
      dailyRealizedPnl: 0,
      dailyUnrealizedPnl: 0,
      dailyDrawdownPct: 0,
      maxDrawdownPct: 0,
      openPositionsCount: 0,
      totalExposure: 0,
      totalExposurePct: 0,
      emergencyStop: false,
      lastUpdated: Date.now()
    };
  }

  public static getInstance(): RiskManager {
    if (!this.instance) {
      this.instance = new RiskManager();
    }
    return this.instance;
  }

  private checkDailyReset(): void {
    const currentDay = new Date().getUTCDate();
    if (currentDay !== this.lastResetDay) {
      this.account.dailyStartingEquity = this.account.equity;
      this.account.dailyRealizedPnl = 0;
      this.account.dailyUnrealizedPnl = 0;
      this.account.dailyDrawdownPct = 0;
      this.lastResetDay = currentDay;
    }
  }

  public updatePositions(openPositions: Position[]): void {
    this.checkDailyReset();

    const totalUnrealizedPnl = openPositions.reduce((sum, p) => sum + p.unrealizedPnl, 0);
    const totalExposure = openPositions.reduce((sum, p) => sum + p.notionalValue, 0);

    this.account.openPositionsCount = openPositions.length;
    this.account.unrealizedPnl = totalUnrealizedPnl;
    this.account.equity = this.account.balance + totalUnrealizedPnl;
    this.account.totalExposure = totalExposure;
    this.account.totalExposurePct = this.account.equity > 0 ? (totalExposure / this.account.equity) * 100 : 0;

    // Daily Drawdown Calculation
    const dailyLoss = Math.max(0, this.account.dailyStartingEquity - this.account.equity);
    this.account.dailyDrawdownPct = this.account.dailyStartingEquity > 0 ? (dailyLoss / this.account.dailyStartingEquity) * 100 : 0;

    // Peak-to-Trough Max Drawdown
    const peakEquity = Math.max(this.account.initialBalance, this.account.equity);
    const overallLoss = Math.max(0, peakEquity - this.account.equity);
    this.account.maxDrawdownPct = peakEquity > 0 ? (overallLoss / peakEquity) * 100 : 0;

    this.account.lastUpdated = Date.now();
  }

  public recordRealizedTrade(pnl: number, fee: number): void {
    this.checkDailyReset();
    const netPnl = pnl - fee;
    this.account.balance += netPnl;
    this.account.realizedPnl += netPnl;
    this.account.dailyRealizedPnl += netPnl;
    this.account.equity = this.account.balance + this.account.unrealizedPnl;
    this.account.lastUpdated = Date.now();
  }

  public triggerEmergencyStop(arm: boolean = true): void {
    this.account.emergencyStop = arm;
    this.account.lastUpdated = Date.now();
  }

  public getAccountState(): AccountState {
    this.checkDailyReset();
    return { ...this.account };
  }

  public resetPaperAccount(newBalance: number = 100.0): void {
    this.account.balance = newBalance;
    this.account.initialBalance = newBalance;
    this.account.equity = newBalance;
    this.account.unrealizedPnl = 0;
    this.account.realizedPnl = 0;
    this.account.dailyStartingEquity = newBalance;
    this.account.dailyRealizedPnl = 0;
    this.account.dailyDrawdownPct = 0;
    this.account.maxDrawdownPct = 0;
    this.account.openPositionsCount = 0;
    this.account.totalExposure = 0;
    this.account.totalExposurePct = 0;
    this.account.emergencyStop = false;
    this.account.lastUpdated = Date.now();
  }
}
