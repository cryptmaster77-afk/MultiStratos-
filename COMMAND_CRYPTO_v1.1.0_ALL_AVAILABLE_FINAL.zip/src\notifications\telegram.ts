import { config } from '../config/index.js';

export interface AlertPayload {
  level: 'INFO' | 'OPPORTUNITY' | 'TRADE_OPEN' | 'TRADE_CLOSE' | 'RISK_ALERT' | 'EMERGENCY';
  title: string;
  message: string;
  timestamp: number;
}

export class NotificationDispatcher {
  private static instance: NotificationDispatcher;
  private recentAlerts: Map<string, number> = new Map();
  private throttleMs: number;

  private constructor() {
    this.throttleMs = (config.notifications.throttleSeconds || 60) * 1000;
  }

  public static getInstance(): NotificationDispatcher {
    if (!this.instance) {
      this.instance = new NotificationDispatcher();
    }
    return this.instance;
  }

  public async dispatch(alert: AlertPayload): Promise<boolean> {
    const key = `${alert.level}:${alert.title}`;
    const lastSent = this.recentAlerts.get(key) || 0;

    // Deduplicate/throttle identical alerts within window
    if (Date.now() - lastSent < this.throttleMs && alert.level !== 'EMERGENCY') {
      return false;
    }

    this.recentAlerts.set(key, Date.now());

    const formatted = `[${alert.level}] ${alert.title}\n${alert.message}\nTime: ${new Date(alert.timestamp).toISOString()}`;
    console.log(`\n📢 NOTIFICATION DISPATCH:\n${formatted}\n`);

    // If Telegram credentials provided
    if (config.notifications.telegramBotToken && config.notifications.telegramChatId) {
      try {
        await fetch(`https://api.telegram.org/bot${config.notifications.telegramBotToken}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: config.notifications.telegramChatId,
            text: formatted,
            parse_mode: 'Markdown'
          })
        });
      } catch (err) {
        console.warn('[NotificationDispatcher] Telegram delivery error:', (err as Error).message);
      }
    }

    // If Webhook provided
    if (config.notifications.webhookUrl) {
      try {
        await fetch(config.notifications.webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(alert)
        });
      } catch (err) {
        console.warn('[NotificationDispatcher] Webhook delivery error:', (err as Error).message);
      }
    }

    return true;
  }
}
