import { ProviderHealthStatus, ProviderQuotaState } from '../types/provider.js';

export interface QuotaConfig {
  providerName: string;
  dailyBudget: number;
  burstLimitPerMinute: number;
  reservedSafetyBuffer?: number;
}

export class QuotaManager {
  private static instances = new Map<string, QuotaManager>();
  
  private providerName: string;
  private dailyBudget: number;
  private burstLimitPerMinute: number;
  private reservedSafetyBuffer: number;
  private requestsUsedToday: number = 0;
  private requestsThisMinute: number[] = []; // Timestamps of requests in the last 60s
  private totalErrorsToday: number = 0;
  private lastError?: string;
  private lastResetDay: number = new Date().getUTCDate();
  private lastRequestTimestamp: number = 0;

  private constructor(config: QuotaConfig) {
    this.providerName = config.providerName;
    this.dailyBudget = config.dailyBudget;
    this.burstLimitPerMinute = config.burstLimitPerMinute;
    this.reservedSafetyBuffer = config.reservedSafetyBuffer ?? Math.max(10, Math.floor(config.dailyBudget * 0.10));
  }

  public static getInstance(config: QuotaConfig): QuotaManager {
    if (!this.instances.has(config.providerName)) {
      this.instances.set(config.providerName, new QuotaManager(config));
    }
    return this.instances.get(config.providerName)!;
  }

  public static getAllStates(): ProviderQuotaState[] {
    return Array.from(this.instances.values()).map(m => m.getState());
  }

  private checkDailyReset(): void {
    const currentDay = new Date().getUTCDate();
    if (currentDay !== this.lastResetDay) {
      this.requestsUsedToday = 0;
      this.totalErrorsToday = 0;
      this.lastResetDay = currentDay;
    }
  }

  private cleanMinuteWindow(): void {
    const oneMinuteAgo = Date.now() - 60000;
    this.requestsThisMinute = this.requestsThisMinute.filter(ts => ts > oneMinuteAgo);
  }

  public canMakeRequest(priority: 'HIGH_PRIORITY_POSITION' | 'STANDARD_SCAN' = 'STANDARD_SCAN'): {
    allowed: boolean;
    waitMs: number;
    reason?: string;
  } {
    this.checkDailyReset();
    this.cleanMinuteWindow();

    const remainingBudget = Math.max(0, this.dailyBudget - this.requestsUsedToday);

    // 1. Daily budget and reserved safety margin check
    if (priority === 'STANDARD_SCAN') {
      if (remainingBudget <= this.reservedSafetyBuffer) {
        return {
          allowed: false,
          waitMs: 3600000,
          reason: `Daily quota preservation: remaining budget (${remainingBudget}) within safety reserve (${this.reservedSafetyBuffer})`
        };
      }
    } else if (priority === 'HIGH_PRIORITY_POSITION') {
      if (remainingBudget <= 0) {
        return {
          allowed: false,
          waitMs: 3600000,
          reason: `Daily quota strictly exhausted (${this.requestsUsedToday}/${this.dailyBudget})`
        };
      }
    }

    // 2. Burst / Minute limit check
    if (this.requestsThisMinute.length >= this.burstLimitPerMinute) {
      const oldestInWindow = this.requestsThisMinute[0];
      const waitMs = Math.max(100, 60000 - (Date.now() - oldestInWindow) + 100);
      return {
        allowed: false,
        waitMs,
        reason: `Minute burst limit reached (${this.requestsThisMinute.length}/${this.burstLimitPerMinute})`
      };
    }

    return { allowed: true, waitMs: 0 };
  }

  public recordRequest(): void {
    this.checkDailyReset();
    this.cleanMinuteWindow();
    const now = Date.now();
    this.requestsUsedToday++;
    this.requestsThisMinute.push(now);
    this.lastRequestTimestamp = now;
  }

  public recordError(errorMessage: string): void {
    this.totalErrorsToday++;
    this.lastError = errorMessage;
  }

  public getState(): ProviderQuotaState {
    this.checkDailyReset();
    this.cleanMinuteWindow();

    const remainingDailyBudget = Math.max(0, this.dailyBudget - this.requestsUsedToday);
    const availableScanBudget = Math.max(0, remainingDailyBudget - this.reservedSafetyBuffer);

    let health: ProviderHealthStatus = 'HEALTHY';
    if (remainingDailyBudget === 0 || this.requestsThisMinute.length >= this.burstLimitPerMinute) {
      health = 'RATE_LIMITED';
    } else if (this.totalErrorsToday > 10) {
      health = 'DEGRADED';
    }

    return {
      providerName: this.providerName,
      requestsUsedToday: this.requestsUsedToday,
      dailyBudget: this.dailyBudget,
      remainingDailyBudget,
      reservedSafetyBuffer: this.reservedSafetyBuffer,
      availableScanBudget,
      requestsLastMinute: this.requestsThisMinute.length,
      burstLimitPerMinute: this.burstLimitPerMinute,
      lastRequestTimestamp: this.lastRequestTimestamp,
      totalErrorsToday: this.totalErrorsToday,
      lastError: this.lastError,
      health
    };
  }
}
