import { Candle, Instrument, MarketRegime } from '../types/market.js';
import { MTFAnalysisResult } from '../analysis/mtf.analyzer.js';
import { StrategyCondition, StrategyReasoning } from '../types/strategy.js';
import { IStrategy } from './base.strategy.js';
import { TechnicalIndicators } from '../analysis/indicators.js';

export class MomentumSupportResistanceStrategy implements IStrategy {
  public readonly id = 'STRAT_MOMENTUM_SR';
  public readonly name = 'Key Support/Resistance Momentum Bounce';
  public readonly version = '1.0.0';
  public readonly description = 'Trades institutional order flow bounces off key swing high/low levels';

  public evaluate(
    instrument: Instrument,
    candles: Candle[],
    regime: MarketRegime,
    mtf: MTFAnalysisResult
  ): StrategyReasoning {
    const closes = candles.map(c => c.close);
    const lastClose = closes[closes.length - 1];
    const atrSeries = TechnicalIndicators.atr(candles, 14);
    const atr = atrSeries[atrSeries.length - 1] || (lastClose * 0.01);

    const swingHigh = mtf.mediumTimeframe.recentSwingHigh;
    const swingLow = mtf.mediumTimeframe.recentSwingLow;
    const distToHigh = Math.abs(lastClose - swingHigh) / lastClose * 100;
    const distToLow = Math.abs(lastClose - swingLow) / lastClose * 100;

    const isNearSupport = distToLow < 1.0;
    const isNearResistance = distToHigh < 1.0;

    const conditionsSatisfied: StrategyCondition[] = [];
    const conditionsFailed: StrategyCondition[] = [];

    // Condition 1: Proximity to key S/R level
    if (isNearSupport || isNearResistance) {
      conditionsSatisfied.push({
        name: 'Key S/R Level Proximity',
        expected: 'Within 1.0% of Swing High/Low',
        actual: isNearSupport ? `Near Support (${distToLow.toFixed(2)}%)` : `Near Resistance (${distToHigh.toFixed(2)}%)`,
        satisfied: true,
        weight: 40
      });
    } else {
      conditionsFailed.push({
        name: 'Key S/R Level Proximity',
        expected: 'Within 1.0% of Swing High/Low',
        actual: `Dist: ${Math.min(distToHigh, distToLow).toFixed(2)}%`,
        satisfied: false,
        weight: 40
      });
    }

    // Condition 2: Lower Timeframe Rejection
    const isConfirmedBounce = mtf.lowerTimeframe.trigger === 'CONFIRMED';
    if (isConfirmedBounce) {
      conditionsSatisfied.push({
        name: 'Price Action Rejection Candle',
        expected: 'Confirmed LTF reversal trigger',
        actual: 'Confirmed',
        satisfied: true,
        weight: 35
      });
    } else {
      conditionsFailed.push({
        name: 'Price Action Rejection Candle',
        expected: 'Confirmed LTF reversal trigger',
        actual: 'Pending',
        satisfied: false,
        weight: 35
      });
    }

    // Condition 3: Volume Participation
    const hasVolume = mtf.lowerTimeframe.volumeMultiplier >= 0.9;
    if (hasVolume) {
      conditionsSatisfied.push({
        name: 'Volume Spike at Level',
        expected: 'Volume >= 0.9x average',
        actual: `${mtf.lowerTimeframe.volumeMultiplier.toFixed(2)}x`,
        satisfied: true,
        weight: 25
      });
    } else {
      conditionsFailed.push({
        name: 'Volume Spike at Level',
        expected: 'Volume >= 0.9x average',
        actual: `${mtf.lowerTimeframe.volumeMultiplier.toFixed(2)}x`,
        satisfied: false,
        weight: 25
      });
    }

    const direction = (isNearSupport && isConfirmedBounce) ? 'BUY' : (isNearResistance && isConfirmedBounce) ? 'SELL' : 'NEUTRAL';
    const stopDistance = atr * 1.3;
    const targetDistance = (isNearSupport ? swingHigh - lastClose : lastClose - swingLow);
    const validTargetDistance = Math.max(targetDistance, atr * 2.5);

    const stopLoss = direction === 'BUY' ? lastClose - stopDistance : direction === 'SELL' ? lastClose + stopDistance : lastClose * 0.98;
    const takeProfit = direction === 'BUY' ? lastClose + validTargetDistance : direction === 'SELL' ? lastClose - validTargetDistance : lastClose * 1.04;
    const invalidationPrice = direction === 'BUY' ? swingLow - atr * 0.5 : swingHigh + atr * 0.5;
    const riskReward = stopDistance > 0 ? validTargetDistance / stopDistance : 2.0;

    const totalWeightSatisfied = conditionsSatisfied.reduce((acc, c) => acc + c.weight, 0);
    const technicalScore = Math.min(100, Math.max(0, totalWeightSatisfied));

    let setupQuality: 'A+' | 'A' | 'B' | 'C' | 'INVALID' = 'INVALID';
    if (technicalScore >= 90) setupQuality = 'A+';
    else if (technicalScore >= 75) setupQuality = 'A';
    else if (technicalScore >= 55) setupQuality = 'B';
    else if (technicalScore >= 35) setupQuality = 'C';

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      direction,
      setupQuality,
      technicalScore,
      conditionsSatisfied,
      conditionsFailed,
      suggestedEntry: lastClose,
      stopLoss,
      takeProfit,
      invalidationPrice,
      riskReward,
      timeframeContext: {
        higherTrend: mtf.higherTimeframe.trend,
        mediumStructure: mtf.mediumTimeframe.structure,
        lowerTrigger: mtf.lowerTimeframe.trigger
      },
      regimeCompatibility: {
        currentRegime: regime.regime,
        isCompatible: true,
        compatibilityScore: 85,
        notes: 'S/R bounce effective across multiple regimes with clean levels'
      }
    };
  }
}
