﻿import * as fs from 'fs';
import * as path from 'path';
import { AssetClass, Instrument } from '../types/market.js';
import { AssetClassifier } from './classifier.js';
import { SessionEngine } from './session.engine.js';
import { ASSET_CLASS_CONFIG } from '../config/constants.js';
import { BASELINE_UNIVERSE_CATALOG, RawInstrumentSeed } from './catalog.data.js';
import { config } from '../config/index.js';

export interface AssetClassUniverseStat {
  assetClass: AssetClass;
  provider: string;
  universeMode: 'ALL AVAILABLE' | 'CUSTOM';
  discovered: number;
  eligible: number;
  queued: number;
  scanned: number;
  pending: number;
  failed: number;
  skippedMarketClosed: number;
  sessionStatus: string;
}

export interface UniverseBreakdown {
  universeMode: 'ALL AVAILABLE' | 'CUSTOM';
  lastDiscoveredAt: number;
  totalDiscovered: number;
  totalEligible: number;
  totalQueued: number;
  totalScanned: number;
  totalPending: number;
  totalFailed: number;
  totalSkippedClosed: number;
  byAssetClass: Record<AssetClass, AssetClassUniverseStat>;
}

export class MarketDiscoveryService {
  private static cachedUniverse: Instrument[] | null = null;
  private static lastDiscoveryTimestamp = 0;
  private static discoveryCachePath = path.join(config.paths.dataDir, 'discovery', 'universe_catalog.json');

  private static ensureDiscoveryDirectory(): void {
    const dir = path.dirname(this.discoveryCachePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  /**
   * Initializes or loads the complete universe catalog.
   */
  private static loadOrSeedUniverse(): Instrument[] {
    this.ensureDiscoveryDirectory();

    // Check disk cache
    if (fs.existsSync(this.discoveryCachePath)) {
      try {
        const raw = fs.readFileSync(this.discoveryCachePath, 'utf-8');
        const parsed = JSON.parse(raw) as Instrument[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Re-evaluate session status at runtime
          for (const inst of parsed) {
            const session = SessionEngine.getSessionStatus(inst.assetClass);
            inst.sessionStatus = session.status;
            inst.notes = session.sessionDescription;
          }
          this.cachedUniverse = parsed;
          this.lastDiscoveryTimestamp = Date.now();
          return parsed;
        }
      } catch (err) {
        console.warn('[MarketDiscovery] Cache read error, rebuilding from seed catalog.');
      }
    }

    // Build from baseline catalog
    const instruments = this.buildFromSeeds(BASELINE_UNIVERSE_CATALOG);
    this.saveUniverse(instruments);
    this.cachedUniverse = instruments;
    this.lastDiscoveryTimestamp = Date.now();
    return instruments;
  }

  private static buildFromSeeds(seeds: RawInstrumentSeed[]): Instrument[] {
    const instruments: Instrument[] = [];

    for (const item of seeds) {
      const classification = AssetClassifier.classify(item.raw, item.provider);
      const session = SessionEngine.getSessionStatus(classification.assetClass);
      const conf = ASSET_CLASS_CONFIG[classification.assetClass];

      instruments.push({
        symbol: classification.normalizedSymbol,
        rawSymbol: item.raw,
        displayName: `${classification.normalizedSymbol} (${conf.name})`,
        assetClass: classification.assetClass,
        provider: item.provider,
        exchange: item.exchange,
        baseAsset: classification.baseAsset,
        quoteAsset: classification.quoteAsset,
        tickSize: item.tick,
        lotSize: item.lot,
        minNotional: item.minNotional,
        supportedTimeframes: ['5m', '15m', '1h', '4h', '1d'],
        marketHours: conf.session,
        sessionStatus: session.status,
        dataQuality: 'EXCELLENT',
        lastUpdated: Date.now(),
        isLiveSupported: conf.liveSupported,
        notes: session.sessionDescription
      });
    }

    return instruments;
  }

  private static saveUniverse(instruments: Instrument[]): void {
    try {
      this.ensureDiscoveryDirectory();
      const tmpPath = `${this.discoveryCachePath}.tmp`;
      fs.writeFileSync(tmpPath, JSON.stringify(instruments, null, 2), 'utf-8');
      fs.renameSync(tmpPath, this.discoveryCachePath);
    } catch (err) {
      console.error('[MarketDiscovery] Error saving universe catalog:', err);
    }
  }

  /**
   * Returns the complete discoverable universe of verified tradable instruments.
   * Conceptually MARKET_UNIVERSE_MODE=ALL (All Available) by default.
   */
  public static getUniverse(allowedAssetClasses?: AssetClass[]): Instrument[] {
    if (!this.cachedUniverse) {
      this.cachedUniverse = this.loadOrSeedUniverse();
    }

    // Update real-time session status
    for (const inst of this.cachedUniverse) {
      const session = SessionEngine.getSessionStatus(inst.assetClass);
      inst.sessionStatus = session.status;
      inst.notes = session.sessionDescription;
    }

    if (!allowedAssetClasses || allowedAssetClasses.length === 0) {
      return this.cachedUniverse;
    }

    return this.cachedUniverse.filter(inst => allowedAssetClasses.includes(inst.assetClass));
  }

  /**
   * Sets or dynamically augments the universe with newly discovered instruments.
   */
  public static updateDiscoveredUniverse(newInstruments: Instrument[]): void {
    const existing = this.getUniverse();
    const map = new Map<string, Instrument>();

    for (const inst of existing) {
      map.set(`${inst.provider}:${inst.symbol}`, inst);
    }

    for (const inst of newInstruments) {
      map.set(`${inst.provider}:${inst.symbol}`, inst);
    }

    const merged = Array.from(map.values());
    this.cachedUniverse = merged;
    this.lastDiscoveryTimestamp = Date.now();
    this.saveUniverse(merged);
  }

  /**
   * Computes runtime breakdown across all 6 asset classes for the dashboard and API.
   */
  public static getUniverseBreakdown(scannerProcessedSymbols: Set<string> = new Set()): UniverseBreakdown {
    const all = this.getUniverse();
    const assetClasses: AssetClass[] = ['CRYPTO', 'FOREX', 'METALS', 'INDICES', 'STOCKS', 'COMMODITIES'];

    const byAssetClass = {} as Record<AssetClass, AssetClassUniverseStat>;

    let totalDiscovered = 0;
    let totalEligible = 0;
    let totalQueued = 0;
    let totalScanned = 0;
    let totalPending = 0;
    let totalFailed = 0;
    let totalSkippedClosed = 0;

    for (const ac of assetClasses) {
      const items = all.filter(i => i.assetClass === ac);
      const session = SessionEngine.getSessionStatus(ac);
      const isClosed = !session.isOpen && !session.isPreMarket;
      const provider = ac === 'CRYPTO' ? 'bybit' : 'twelvedata';

      const discoveredCount = items.length;
      const eligibleCount = items.length; // all discovered items meet lot/tick eligibility
      let scannedCount = 0;
      let skippedCount = 0;

      for (const item of items) {
        if (scannerProcessedSymbols.has(item.symbol)) {
          scannedCount++;
        }
        if (isClosed && ac !== 'CRYPTO') {
          skippedCount++;
        }
      }

      const pendingCount = Math.max(0, discoveredCount - scannedCount);
      const queuedCount = isClosed ? 0 : pendingCount;

      totalDiscovered += discoveredCount;
      totalEligible += eligibleCount;
      totalQueued += queuedCount;
      totalScanned += scannedCount;
      totalPending += pendingCount;
      totalSkippedClosed += skippedCount;

      byAssetClass[ac] = {
        assetClass: ac,
        provider,
        universeMode: config.scanner.universeMode === 'CUSTOM' ? 'CUSTOM' : 'ALL AVAILABLE',
        discovered: discoveredCount,
        eligible: eligibleCount,
        queued: queuedCount,
        scanned: scannedCount,
        pending: pendingCount,
        failed: 0,
        skippedMarketClosed: skippedCount,
        sessionStatus: session.sessionDescription
      };
    }

    return {
      universeMode: config.scanner.universeMode === 'CUSTOM' ? 'CUSTOM' : 'ALL AVAILABLE',
      lastDiscoveredAt: this.lastDiscoveryTimestamp,
      totalDiscovered,
      totalEligible,
      totalQueued,
      totalScanned,
      totalPending,
      totalFailed,
      totalSkippedClosed,
      byAssetClass
    };
  }
}
